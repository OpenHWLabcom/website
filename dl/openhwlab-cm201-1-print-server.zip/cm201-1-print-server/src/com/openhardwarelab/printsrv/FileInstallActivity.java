package com.openhardwarelab.printsrv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

/** U盘 / 本地文件浏览: 插上 U盘自动显示内容, 可进目录, 选中 .ppd 直接安装。
 *  自绘 D-pad 导航(dispatchKeyEvent), 不依赖焦点系统, 遥控器稳。 */
public class FileInstallActivity extends Activity {
    private ArrayAdapter<String> ad;
    private ArrayList<String> labels = new ArrayList<String>();
    private ArrayList<String> paths = new ArrayList<String>();
    private ArrayList<Boolean> isdirs = new ArrayList<Boolean>();
    private String curPath = "";
    private String parentPath = "";
    private String usbUri = "";
    private int sel = 0;
    private String lastKey = "";
    private ListView list;
    private TextView infoTv;
    private final Handler h = new Handler();
    private boolean alive = true;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout L = new LinearLayout(this);
        L.setOrientation(LinearLayout.VERTICAL);
        L.setBackgroundColor(0xFF0F172A);
        L.setPadding(44, 30, 44, 30);

        TextView t = new TextView(this); t.setText("\uD83D\uDCC2 U盘 / 本地文件");
        t.setTextSize(26); t.setTextColor(0xFFFFFFFF); L.addView(t);
        infoTv = new TextView(this); infoTv.setTextSize(16); infoTv.setTextColor(0xFF9FD0FF);
        infoTv.setPadding(0, 6, 0, 6); L.addView(infoTv);
        TextView hint = new TextView(this);
        hint.setText("遥控器：↑↓ 选择 · OK 进入/安装 · 返回键退出");
        hint.setTextSize(13); hint.setTextColor(0xFF7F93B3); hint.setPadding(0, 0, 0, 6); L.addView(hint);

        list = new ListView(this); list.setBackgroundColor(0xFF0E1830);
        ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels);
        list.setAdapter(ad);
        list.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) { click(pos); } });
        L.addView(list);

        setContentView(L, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        list.requestFocus();

        load();
        h.postDelayed(new Runnable() { public void run() {
            if (!alive) return; load(); h.postDelayed(this, 3000); } }, 3000);
    }

    @Override protected void onDestroy() { super.onDestroy(); alive = false; }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int kc = e.getKeyCode();
            if (kc == KeyEvent.KEYCODE_DPAD_DOWN) { move(1); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_UP) { move(-1); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER
                    || kc == KeyEvent.KEYCODE_NUMPAD_ENTER) { click(sel); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    private void move(int d) {
        if (paths.isEmpty()) return;
        sel += d;
        if (sel < 0) sel = 0;
        if (sel > paths.size() - 1) sel = paths.size() - 1;
        list.setSelection(sel);
    }

    private static String sz(long b) {
        if (b <= 0) return "0";
        if (b >= 1073741824L) return String.format("%.1fG", b / 1073741824.0);
        if (b >= 1048576L) return String.format("%.0fM", b / 1048576.0);
        return String.format("%dK", b / 1024);
    }

    private void load() {
        new Thread(new Runnable() { public void run() {
            final String det = Http.get("/api/detect");
            final String s = Http.get("/api/ls?path=" + Http.enc(curPath));
            runOnUiThread(new Runnable() { public void run() { apply(det, s); } });
        } }).start();
    }

    private void apply(String det, String s) {
        try {
            JSONObject o = new JSONObject(det);
            JSONArray ps = o.optJSONArray("printers");
            if (ps != null && ps.length() > 0) usbUri = ps.getJSONArray(0).optString(1);
        } catch (Exception e) { }

        try {
            JSONObject o = new JSONObject(s);
            if (o.has("roots")) {
                JSONArray rs = o.optJSONArray("roots");
                String auto = null;
                ArrayList<String> lv = new ArrayList<String>(), pv = new ArrayList<String>();
                ArrayList<Boolean> dv = new ArrayList<Boolean>();
                for (int i = 0; i < rs.length(); i++) {
                    JSONObject r = rs.getJSONObject(i);
                    boolean rem = r.optBoolean("removable");
                    String nm = r.optString("disp", r.optString("name"));
                    lv.add((rem ? "\uD83D\uDCBE U盘: " : "\uD83D\uDCC1 盒内: ") + nm
                            + "   " + sz(r.optLong("free")) + " 可用 / " + sz(r.optLong("total")));
                    pv.add(r.optString("path")); dv.add(true);
                    if (rem) auto = r.optString("path");
                }
                if (auto != null) { curPath = auto; sel = 0; load(); return; }   // 有U盘 -> 直接显示内容
                parentPath = "";
                setList(lv, pv, dv, "roots:" + s.length());
                infoTv.setText("未检测到 U盘。插入 U盘后会自动显示内容。");
                return;
            }
            parentPath = o.optString("parent", "");
            JSONArray es = o.optJSONArray("entries");
            ArrayList<String> lv = new ArrayList<String>(), pv = new ArrayList<String>();
            ArrayList<Boolean> dv = new ArrayList<Boolean>();
            if (parentPath != null && parentPath.length() > 0) {   // 目录内: 首项=上级
                lv.add("\u2B06 上级目录"); pv.add("__UP__"); dv.add(true);
            } else {
                lv.add("\u2B06 返回存储列表"); pv.add("__UP__"); dv.add(true);
            }
            if (es != null) for (int i = 0; i < es.length(); i++) {
                JSONObject e = es.getJSONObject(i);
                boolean d = e.optBoolean("isdir");
                lv.add((d ? "\uD83D\uDCC1 " : "\uD83D\uDCC4 ") + e.optString("name")
                        + (d ? "" : "   " + sz(e.optLong("size"))));
                pv.add(e.optString("path")); dv.add(d);
            }
            setList(lv, pv, dv, curPath + ":" + pv.size() + ":" + s.length());
            infoTv.setText(curPath.replace("/proc/1/root", "") + "    (" + (pv.size() - 1) + " 项)");
        } catch (Exception e) {
            infoTv.setText("读取失败（服务未就绪？）");
        }
    }

    private void setList(ArrayList<String> lv, ArrayList<String> pv, ArrayList<Boolean> dv, String key) {
        if (key.equals(lastKey)) return;   // 无变化不刷新(避免打断选中)
        lastKey = key;
        labels.clear(); labels.addAll(lv);
        paths.clear(); paths.addAll(pv);
        isdirs.clear(); isdirs.addAll(dv);
        ad.notifyDataSetChanged();
        if (sel > pv.size() - 1) sel = Math.max(0, pv.size() - 1);
        list.setSelection(sel);
    }

    private void click(int pos) {
        Log.i("psrv", "click " + pos);
        if (pos < 0 || pos >= paths.size()) return;
        String p = paths.get(pos);
        if ("__UP__".equals(p)) {
            curPath = (parentPath != null && parentPath.length() > 0) ? parentPath : "";
            sel = 0; lastKey = ""; load();
            return;
        }
        if (isdirs.get(pos)) { curPath = p; sel = 0; lastKey = ""; load(); return; }
        String lp = p.toLowerCase();
        if (lp.endsWith(".ppd") || lp.endsWith(".ppd.gz")) {
            confirmInstall(p);
        } else {
            toast("不是驱动文件(.ppd): " + p.substring(p.lastIndexOf('/') + 1));
        }
    }

    private void confirmInstall(final String path) {
        final String base = path.substring(path.lastIndexOf('/') + 1).replaceAll("(?i)\\.ppd(\\.gz)?$", "");
        final String pname = base.replaceAll("[^A-Za-z0-9._-]", "");
        new AlertDialog.Builder(this)
            .setTitle("安装驱动文件")
            .setMessage("文件：\n" + base + "\n\n队列名：" + pname + "\n\n安装后请去管理页打张测试页验证。")
            .setPositiveButton("安装", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { doInstall(path, pname); } })
            .setNegativeButton("取消", null)
            .show();
    }

    private void doInstall(final String path, final String pname) {
        toast("安装中…");
        new Thread(new Runnable() { public void run() {
            final String s = Http.post("/api/installfile",
                    "path=" + Http.enc(path) + "&uri=" + Http.enc(usbUri) + "&pname=" + Http.enc(pname));
            runOnUiThread(new Runnable() { public void run() {
                try {
                    JSONObject o = new JSONObject(s);
                    if (o.optBoolean("ok")) { toast("安装成功 ✓"); finish(); }
                    else toast("失败: " + o.optString("msg"));
                } catch (Exception e) { toast("失败：服务无响应"); }
            } });
        } }).start();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
