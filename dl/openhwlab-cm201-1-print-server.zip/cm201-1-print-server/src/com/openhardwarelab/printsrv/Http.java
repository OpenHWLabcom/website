package com.openhardwarelab.printsrv;

import java.io.*;
import java.net.*;

/** 极小 HTTP 客户端: 跟本机 printd(:8080) 说话。 */
public class Http {
    static final String BASE = "http://127.0.0.1:8080";

    static String get(String path) { return req("GET", path, null); }
    static String post(String path, String body) { return req("POST", path, body); }

    static String req(String method, String path, String body) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(4000);
            c.setReadTimeout(25000);
            c.setUseCaches(false);
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                OutputStream o = c.getOutputStream();
                o.write(body.getBytes("UTF-8"));
                o.close();
            }
            int code = c.getResponseCode();
            InputStream in = (code >= 400) ? c.getErrorStream() : c.getInputStream();
            if (in == null) return "";
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096]; int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            in.close();
            return new String(bo.toByteArray(), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    static byte[] getBytes(String path) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
            c.setConnectTimeout(4000); c.setReadTimeout(15000); c.setUseCaches(false);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            in.close();
            return bo.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }
}
