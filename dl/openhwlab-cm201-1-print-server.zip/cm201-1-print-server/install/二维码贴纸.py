#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 生成 A4 二维码贴纸版: 2列x3行 = 6 张, 每张二维码上方标注文字。
# 用法: qrsheet.py <url> <out.pdf> [caption]
import sys, os, subprocess
from PIL import Image, ImageDraw, ImageFont

url = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8080/"
out = sys.argv[2] if len(sys.argv) > 2 else "/tmp/qrsheet.pdf"
caption = sys.argv[3] if len(sys.argv) > 3 else "扫码传文件打印"

DPI = 300
W, H = int(round(8.27 * DPI)), int(round(11.69 * DPI))   # A4 portrait px
cols, rows = 2, 3
cw, ch = W // cols, H // rows
FONT = "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf"

qpng = "/tmp/qrsheet_qr.png"
subprocess.run(["qrencode", "-t", "PNG", "-s", "16", "-m", "2", "-o", qpng, url], check=True)

img = Image.new("RGB", (W, H), "white")
d = ImageDraw.Draw(img)
qr = Image.open(qpng).convert("RGB")

fs = int(cw * 0.10)
try:
    font = ImageFont.truetype(FONT, fs)
except Exception:
    font = ImageFont.load_default()

tw, th = d.textsize(caption, font=font)
qr_side = max(120, min(cw - int(cw * 0.12), ch - th - int(ch * 0.12)))
qr_r = qr.resize((qr_side, qr_side), Image.NEAREST)

for r in range(rows):
    for c in range(cols):
        x0, y0 = c * cw, r * ch
        tx = x0 + (cw - tw) // 2
        ty = y0 + int(ch * 0.05)
        d.text((tx, ty), caption, fill="black", font=font)
        qx = x0 + (cw - qr_side) // 2
        qy = ty + th + int(ch * 0.04)
        img.paste(qr_r, (qx, qy))
        # 浅色裁切框
        d.rectangle([x0 + 3, y0 + 3, x0 + cw - 3, y0 + ch - 3], outline=(205, 205, 205))

img.save(out, "PDF", resolution=DPI)
# 同时存一张预览 png
img.save(out.rsplit(".", 1)[0] + ".png")
print("OK %s %dx%d qr=%d" % (out, W, H, qr_side))
