========================================
  安装文件 · 说明
  OpenHW Lab · 魔百和 CM201-1 改打印机服务器
========================================

先读「安装教程.pdf / docs/安装教程.md」（图文），照着做即可。

本目录文件：

  一键安装.sh            ← 电脑上跑：./一键安装.sh <盒子IP>
                            （推服务脚本/固件 + 装桌面 + 装开机脚本，一步到位）
  桌面.apk               ← 打印服务器桌面（开机即进：内嵌网页打印界面 + 菜单 + 二维码）
                            → pm install -r 后设为盒子 HOME
  打印服务.py            ← 网页打印门户/管理/驱动向导/二维码 → 子系统 /root/printd.py（:8080）
  printerwatch.py        ← 打印机守护：插上 HP LaserJet(1018/1020/1022/1022n) 自动
                            灌固件 + 建队列 + 设为默认 → /root/printerwatch.py
  二维码贴纸.py          ← A4 一版 6 张二维码贴纸生成 → /root/qrsheet.py
  firmware/              ← HP 原厂固件 hp1018/1020/1022/1022n.img
                            → 子系统 /lib/firmware/hp/sihp<型号>.img
  开机自启-子系统.sh     ← 子系统启动脚本（dbus/cupsd/printd/printerwatch）→ /root/printstart.sh
  开机自启-盒子.sh       ← 盒子开机脚本（挂子系统/起服务/延时起打印桌面）→ /data/printstart.sh

端口一览：
  8080  网页打印门户（手机扫码传文件打印 / 管理 / 驱动向导）
  631   CUPS 打印服务（电脑按 IPP 加打印机 ipp://<盒子IP>:631/printers/<队列>）

怎么用：
  A) 省事：连好 adb，跑  ./一键安装.sh <盒子IP>
  B) 手动：按「安装教程」一步步复制文件、执行命令（可照抄）

依赖（在 Linux 子系统里装；本 ROM 禁 chroot 内 apt，
      需先在电脑上下载 armhf 的 .deb 再 dpkg -i，详见教程第 3 步）：
  cups cups-filters dbus
  printer-driver-gutenprint printer-driver-brlaser printer-driver-foo2zjs printer-driver-cups-pdf
  qrencode python3-usb(pyusb)
  （python3-pil + fonts-droid-fallback 只在用「二维码贴纸」时需要，顺带让中文能打印）

支持机型（即插即用）：HP LaserJet 1018 / 1020 / 1022 / 1022n
（其它打印机也能用网页「设置向导」自动识别型号并装驱动）

—— OpenHW Lab · 智能硬件开放实验室 · hi@openhwlab.com
