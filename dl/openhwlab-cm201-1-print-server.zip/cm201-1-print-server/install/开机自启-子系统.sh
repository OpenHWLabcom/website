#!/bin/bash
# ============================================================
#  OpenHW Lab · 魔百和 CM201-1 改打印机服务器
#  子系统(/data/linux) 开机启动脚本  ->  /root/printstart.sh
#  作用：拉起 dbus + CUPS + 网页打印门户(printd) + 打印机守护(printerwatch)
#  由盒子侧 /data/printstart.sh chroot 进来执行（开机自启）。
# ============================================================
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
mkdir -p /run/dbus /var/run/dbus /var/spool/cups /var/cache/cups /var/spool/printd /var/log 2>/dev/null

# dbus（有些 chroot 起不来，不影响 CUPS/printd）
pgrep -x dbus-daemon >/dev/null 2>&1 || dbus-daemon --system --fork 2>/dev/null

# CUPS 打印服务
pgrep -x cupsd >/dev/null 2>&1 || /usr/sbin/cupsd 2>/dev/null
sleep 1

# 网页打印门户 :8080
pgrep -f printd.py >/dev/null 2>&1 || setsid python3 /root/printd.py >/var/log/printd.log 2>&1 </dev/null &

# 打印机守护：插上 HP LaserJet(1018/1020/1022/1022n) 自动灌固件 + 建队列 + 设为默认
pgrep -f '[p]rinterwatch.py' >/dev/null 2>&1 || setsid python3 /root/printerwatch.py >/var/log/printerwatch.log 2>&1 </dev/null &

sleep 1
echo "printstart done: cupsd=$(pgrep -c -x cupsd) printd=$(pgrep -c -f printd.py) printerwatch=$(pgrep -c -f printerwatch.py) $(date)"
