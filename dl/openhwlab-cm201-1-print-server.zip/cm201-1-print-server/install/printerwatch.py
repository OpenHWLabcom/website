#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""printerwatch — HP LaserJet 主机型(ZJS) 打印机「插上即用」守护。

本机内核无 usblp，固件走 libusb(pyusb)。
插上 HP LaserJet 1018/1020/1022/1022n 后自动：
  1) 灌固件 sihp<型号>.img (每台设备只灌一次；拔掉重插/power-cycle 会重灌)
  2) 建 CUPS 队列(用 foo2zjs 默认驱动) 并设为系统默认打印机
"""
import os, subprocess, time, urllib.parse

FWDIR = "/lib/firmware/hp"
# 注意顺序：1022n 必须在 1022 之前
ZJS = [
    ("1022n", "sihp1022n.img", "foo2zjs:0/ppd/foo2zjs/HP-LaserJet_1022n.ppd", "HP-LaserJet-1022n"),
    ("1022",  "sihp1022.img",  "foo2zjs:0/ppd/foo2zjs/HP-LaserJet_1022.ppd",  "HP-LaserJet-1022"),
    ("1018",  "sihp1018.img",  "foo2zjs:0/ppd/foo2zjs/HP-LaserJet_1018.ppd",  "HP-LaserJet-1018"),
    ("1020",  "sihp1020.img",  "foo2zjs:0/ppd/foo2zjs/HP-LaserJet_1020.ppd",  "HP-LaserJet-1020"),
]

FLASHED = set()          # 本进程内已处理过的设备键 (bus:addr)，防重复灌


def log(m):
    print(time.strftime("%F %T") + " " + str(m), flush=True)


def run(cmd, t=90):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=t)
        return r.returncode, (r.stdout + r.stderr).decode("utf-8", "ignore").strip()
    except Exception as e:
        return 1, str(e)


def usb_uris():
    out = []
    rc, s = run(["lpinfo", "-v"], 30)
    if rc == 0:
        for ln in s.splitlines():
            ln = ln.strip()
            if ln.startswith("direct usb://"):
                out.append(ln.split(None, 1)[1])
    return out


def match_model(uri):
    u = urllib.parse.unquote(uri)
    for key, fw, ppd, name in ZJS:
        if key in u:
            return key, fw, ppd, name
    return None


def ensure_queue(uri, ppd, name):
    rc, s = run(["lpstat", "-p", name], 20)
    if ("printer " + name + " is") in s:
        return False
    rc, s = run(["lpadmin", "-p", name, "-E", "-v", uri, "-m", ppd], 90)
    run(["cupsenable", name])
    run(["cupsaccept", name])
    run(["lpadmin", "-d", name])           # 设为默认
    log("已建队列 %s  <- %s | 驱动 %s | %s" % (name, uri, ppd, s))
    return True


def set_default(name):
    rc, s = run(["lpstat", "-d"], 20)
    if name not in s:
        run(["lpadmin", "-d", name])
        log("已把 %s 设为默认打印机" % name)


def read_idstr(dev):
    r = None
    for w in (0x0300, 0):
        try:
            # GET_DEVICE_ID: wValue=w, wIndex=0  (原来参数写反了)
            r = dev.ctrl_transfer(0xA1, 0, w, 0, 1024, timeout=3000)
            break
        except Exception:
            r = None
    if not r:
        return ""
    b = bytes(r)
    try:
        return (b[2:2 + (b[0] | (b[1] << 8))] if len(b) >= 2 else b).decode("latin1", "replace")
    except Exception:
        return ""


def send_fw(dev, path):
    import usb.util
    data = open(path, "rb").read()
    try:
        dev.set_configuration()
    except Exception:
        pass
    cfg = dev.get_active_configuration()
    intf = None
    for i in cfg:
        if i.bInterfaceClass == 7:
            intf = i
            break
    if intf is None:
        intf = cfg[(0, 0)]
    try:
        usb.util.claim_interface(dev, intf.bInterfaceNumber)
    except Exception:
        pass
    ep = usb.util.find_descriptor(
        intf,
        custom_match=lambda e: (
            usb.util.endpoint_direction(e.bEndpointAddress) == usb.util.ENDPOINT_OUT
            and usb.util.endpoint_type(e.bmAttributes) == usb.util.ENDPOINT_TYPE_BULK))
    if ep is None:
        log("找不到 bulk OUT 端点")
        return False
    for off in range(0, len(data), 4096):
        ep.write(data[off:off + 4096], timeout=5000)
    try:
        usb.util.release_interface(dev, intf.bInterfaceNumber)
    except Exception:
        pass
    return True


def do_firmware(key, fwfile):
    global FLASHED
    try:
        import usb.core
    except Exception as e:
        log("pyusb 不可用: %s" % e)
        return
    fwp = os.path.join(FWDIR, fwfile)
    if not os.path.exists(fwp):
        log("缺固件文件 %s" % fwp)
        return
    devs = list(usb.core.find(find_all=True, idVendor=0x03f0))
    present = set("%s:%s" % (d.bus, d.address) for d in devs)
    FLASHED &= present                      # 拔掉的设备(键不再出现) → 忘掉，重插会再灌
    for dev in devs:
        dk = "%s:%s" % (dev.bus, dev.address)
        if dk in FLASHED:
            continue
        ids = read_idstr(dev)
        prod = ""
        try:
            prod = dev.product or ""
        except Exception:
            pass
        if key not in (ids + " " + prod).lower():
            continue
        if "fwver" in ids.lower():
            FLASHED.add(dk)                 # 固件已在，免灌
            continue
        log("检测到 HP LaserJet %s（id=%r），灌固件 %s …" % (key, ids[:60], fwfile))
        try:
            if send_fw(dev, fwp):
                log("固件已发送 (%d 字节)" % os.path.getsize(fwp))
        except Exception as e:
            log("灌固件失败: %s" % e)
        FLASHED.add(dk)


def main():
    log("printerwatch 启动")
    while True:
        try:
            for uri in usb_uris():
                m = match_model(uri)
                if not m:
                    continue
                key, fwfile, ppd, name = m
                try:
                    do_firmware(key, fwfile)
                except Exception as e:
                    log("固件步骤异常: %s" % e)
                try:
                    if not ensure_queue(uri, ppd, name):
                        set_default(name)
                except Exception as e:
                    log("建队列异常: %s" % e)
        except Exception as e:
            log("循环异常: %s" % e)
        time.sleep(8)


if __name__ == "__main__":
    main()
