#!/system/bin/sh
# OpenHW Lab 打印服务器 开机自启（Android 根上下文）
R=/data/linux
for i in 1 2 3 4 5 6 7 8; do [ -d $R/usr ] && break; busybox sleep 2; done
busybox mount -t proc proc $R/proc 2>/dev/null
busybox mount -t sysfs sysfs $R/sys 2>/dev/null
busybox mount -o bind /dev $R/dev 2>/dev/null
busybox chroot $R /usr/bin/env -i PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin HOME=/root /bin/bash /root/printstart.sh
# 开机自动全屏显示「打印桌面」(覆盖运营商桌面)
busybox setsid sh -c 'busybox sleep 28; am start -n com.openhardwarelab.printsrv/.MainActivity' >/dev/null 2>&1 &
