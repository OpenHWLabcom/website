#!/bin/bash
# ============================================================
#  OpenHW Lab · 魔百和 CM201-1 改打印机服务器 —— 一键安装（在电脑上跑）
#  用法：  ./一键安装.sh <盒子IP>
#  前提：  盒子已 root、已开 ADB；已按教程搭好 Linux 子系统 /data/linux；
#          电脑装了 adb，与盒子同一局域网。
#  作用：  推打印服务/驱动守护/固件 进子系统、装打印服务器桌面、装开机脚本。
#          幂等，可重复执行。
#  说明：  依赖包(CUPS 等)需先在子系统里装好（见教程第 3 步：禁 apt 的绕法）。
# ============================================================
set -e
IP="$1"
[ -z "$IP" ] && { echo "用法: $0 <盒子IP>"; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"
R=/data/linux
say(){ echo -e "\n\033[1;36m==> $*\033[0m"; }

say "连接盒子 $IP:5555"
adb connect "${IP}:5555"
adb wait-for-device

say "检查 Linux 子系统 $R"
adb shell "[ -d $R/root ] || { echo '未找到 $R（先按教程搭好子系统）'; exit 1; }"

say "推 网页门户 + 驱动守护 到子系统 /root"
adb push "$HERE/打印服务.py"    $R/root/printd.py
adb push "$HERE/printerwatch.py" $R/root/printerwatch.py
adb push "$HERE/二维码贴纸.py"   $R/root/qrsheet.py

say "放 HP 原厂固件 到子系统 /lib/firmware/hp"
adb shell "mkdir -p $R/lib/firmware/hp"
for m in 1018 1020 1022 1022n; do
  adb push "$HERE/firmware/hp$m.img" $R/lib/firmware/hp/sihp$m.img
  adb shell "cp -f $R/lib/firmware/hp/sihp$m.img $R/lib/firmware/hp/sihp$m.dl"
done

say "装「打印服务器桌面」App（上电即进: 内嵌打印页 + 菜单 + 二维码）"
adb push "$HERE/桌面.apk" /data/local/tmp/printsrv.apk
adb shell 'pm install -r /data/local/tmp/printsrv.apk'

say "装子系统开机脚本 /root/printstart.sh"
adb push "$HERE/开机自启-子系统.sh" $R/root/printstart.sh

say "装盒子开机脚本 /data/printstart.sh（挂子系统 + chroot 起服务 + 起打印桌面）"
adb push "$HERE/开机自启-盒子.sh" /data/printstart.sh
adb shell "chmod 755 /data/printstart.sh"

cat <<'TIP'

  提示：
   · 依赖包(CUPS/dbus/printer-driver-* 等)需首次在子系统里装好（本 ROM 禁 apt，
     见教程第 3 步：电脑侧下载 armhf .deb → 推到盒子 → dpkg -i）。
   · 开机自启依赖 boot 镜像里的 init.rc 里那条 `service printstart`（见教程第 6 步）。
   · 装完手机/电脑打开：  http://<盒子IP>:8080/   （未配打印机会自动进设置向导）
   · HP LaserJet 1018/1020/1022/1022n 插上后约 10 秒自动配好。

  —— OpenHW Lab · 智能硬件开放实验室
TIP
