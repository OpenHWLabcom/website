# 魔百和 CM201-1 改打印机服务器 · China Mobile CM201-1 → Print Server

> 把吃灰的 **魔百和 CM201-1** 盒子变成一台**局域网网络打印机**：手机/电脑打开网页就能打印。
> Turn an idle **China Mobile CM201-1** box into a **LAN network printer**: print straight from a phone/PC browser.

支持 **IPP 直连** + **网页打印**；内置驱动库**多品牌自适应**，HP LaserJet 1018/1020/1022/1022n **插上即用**。
Direct **IPP** + **web printing**; built-in driver library, **multi-brand self-adapting**; HP LaserJet 1018/1020/1022/1022n are **plug-and-play**.

---

## 🇨🇳 中文

### 功能
- **网页打印门户**：手机/电脑浏览器打开即可**拖拽 / 选文件 → 打印**
- **IPP 直连**：电脑「添加打印机」用 `ipp://<盒子IP>:631/printers/<队列>`
- **驱动向导 · 多品牌自适应**：插上 USB 打印机 → **自动识别型号** → 从**内置驱动库**匹配（HP / 兄弟 / 联想 / 爱普生 / 佳能 / 三星 等主流品牌；含 brlaser / foo2zjs / gutenprint / cups-filters）；认不出的机型可**上传 .ppd** 补上
- **主机型即插即用**：HP LaserJet 1018/1020/1022/1022n（主机型/ZJS）插上**自动灌固件 + 建队列 + 设为默认**
- **管理页**：队列列表、设默认、测试页、删除、换驱动
- **二维码**：扫码传件打印；还能**打印「A4 一版 6 张」的二维码贴纸**
- **打印桌面**：盒子开机全屏显示打印页（左网页 + 右菜单），遥控器可操作
- **中文打印**：内置中文字体，中文文档不会打成空白

> ⚠ 本盒子 chroot 里 **avahi（AirPrint 自动发现）起不来**（socket 受限），
> 所以用 **IPP 直连 + 网页** 打印，**不支持 AirPrint 自动发现**。

### 预览
![魔百和 CM201-1 打印服务器面板](docs/预览-面板.jpg)

### 环境要求
- **魔百和 CM201-1**（Amlogic S905L / armv7 / Android 4.4.2 / 1GB / eMMC）**已 root**，能开 **ADB**
- 盒子里的 **Linux 子系统**：chroot 一个 **Ubuntu 20.04（armhf）** 到 `/data/linux`
- 一台 **USB 打印机**（HP LaserJet 1018/1020/1022/1022n 即插即用；联想/兄弟主机型走 brlaser）

### 安装
```bash
cd install
./一键安装.sh <盒子IP>
```
详细图文：**[`docs/安装教程.md`](docs/安装教程.md)**（另附 html）

> ⚠ 盒子 chroot 内 **apt 建不了 socket**（`socket: Permission denied`）→ 不能直接 `apt install`。
> 驱动包要按教程用**用户态 apt** 在电脑上下载 armhf `.deb`，推到盒子 `dpkg -i` 安装。

### 操作说明
- **打印门户**：`http://<盒子IP>:8080/` → 拖拽/选文件 → 打印
- **管理**：`http://<盒子IP>:8080/admin`（队列 / 默认 / 测试页 / 删除 / 换驱动）
- **设置向导**：`http://<盒子IP>:8080/setup`（打开即自动带出 USB 型号 + 列出匹配驱动）
- **电视页**：`http://<盒子IP>:8080/tv`（全屏二维码，适合接电视常显）
- **电脑添加打印机**：用页面上的打印机地址 `ipp://<盒子IP>:631/printers/<队列>`
- **盒子屏幕**：打印桌面（左栏网页打印界面 + 右栏菜单，遥控器可操作）
- **二维码贴纸**：首页「打印此二维码」→ A4 一版 6 张

### 目录
```
install/   安装文件（一键安装.sh + 打印服务.py + printerwatch.py + 二维码贴纸.py
           + 桌面.apk + 开机自启脚本 + firmware/  HP 原厂固件）
src/       源码（printd 打印服务 + Android 打印桌面 App + 构建 / 开机脚本）
docs/      教程与开发者文档
```
> `install/firmware/` 内含 HP LaserJet **1018/1020/1022/1022n** 原厂固件（主机型打印机需要灌固件才能用）。

---

## 🇬🇧 English

### Features
- **Web print portal**: open in a phone/PC browser, **drag & drop / choose a file → print**
- **Direct IPP**: add via `ipp://<box-ip>:631/printers/<queue>`
- **Driver wizard · multi-brand, self-adapting**: plug in a USB printer → **model auto-detected** → matched against the **built-in driver library** (HP / Brother / Lenovo / Epson / Canon / Samsung …; includes brlaser / foo2zjs / gutenprint / cups-filters); unknown models can be added via **.ppd upload**
- **Host-based plug-and-play**: HP LaserJet 1018/1020/1022/1022n (host-based/ZJS) are **auto-flashed + queue created + set default** on plug-in
- **Admin page**: queues, set default, test page, delete, change driver
- **QR codes**: scan to upload & print; also **print a sheet of 6 QR stickers (A4)**
- **Print desktop**: the box boots straight into the print page (web UI left, menu right), remote-controllable
- **CJK printing**: bundled Chinese font, so Chinese documents never print blank

> ⚠ **avahi (AirPrint auto-discovery) cannot start inside this box's chroot** (socket restriction),
> so printing works via **direct IPP + web**; **AirPrint auto-discovery is not supported**.

### Requirements
- A **rooted** **China Mobile CM201-1** box (Amlogic S905L / armv7 / Android 4.4.2 / 1GB / eMMC) with **ADB**
- A **Linux subsystem** in the box: an **Ubuntu 20.04 (armhf)** chroot at `/data/linux`
- A **USB printer** (HP LaserJet 1018/1020/1022/1022n plug-and-play; Lenovo/Brother host-based via brlaser)

### Install
```bash
cd install
./一键安装.sh <box-ip>
```
Full illustrated guide: **[`docs/安装教程.md`](docs/安装教程.md)** (html included)

> ⚠ Inside the chroot **apt cannot create a socket** (`socket: Permission denied`) → plain `apt install` fails.
> Download the armhf `.deb` set on a PC with a **user-mode apt** config, push to the box and `dpkg -i` (see the tutorial).

### Usage
- **Print portal**: open **`http://<box-ip>:8080/`** on a phone/PC → drop/choose a file → print
- **Admin**: `http://<box-ip>:8080/admin` (queues / default / test / delete / change driver)
- **Setup wizard**: `http://<box-ip>:8080/setup` (auto-detects the USB model + lists matching drivers)
- **TV page**: `http://<box-ip>:8080/tv` (fullscreen QR, good for an always-on TV)
- **Add printer on a PC**: use the on-page address `ipp://<box-ip>:631/printers/<queue>`
- **On the box screen**: the print desktop (web print UI left, menu right; remote-controllable)
- **QR sticker sheet**: homepage → “Print this QR code” → 6 per A4 page

### Layout
```
install/   installer (one-click + print service + printerwatch + QR-sheet script
           + desktop.apk + autostart scripts + firmware/  HP factory firmware)
src/       source (printd service + Android print-desktop app + build / boot scripts)
docs/      guides & dev docs
```
> `install/firmware/` ships HP LaserJet **1018/1020/1022/1022n** factory firmware (host-based printers must be flashed).

---

## License · 许可
[MIT](docs/LICENSE) · 仅供学习与个人使用 / For learning and personal use only.

---

## 🔗 相关链接 · Links

- 官网 **OpenHW Lab**：https://www.openhwlab.com/ — 让闲置硬件重获新生
- 本项目仓库：https://github.com/OpenHWLabcom/cm201-1-print-server
- 同系列机顶盒改造项目：
  - 机顶盒改游戏机 — https://github.com/OpenHWLabcom/tvbox-game-console
  - 机顶盒改电脑主机 — https://github.com/OpenHWLabcom/tvbox-desktop-pc
  - 机顶盒改监控录像主机 — https://github.com/OpenHWLabcom/tvbox-surveillance
- 官网源码：https://github.com/OpenHWLabcom/website

联系 · Contact：hi@openhwlab.com
