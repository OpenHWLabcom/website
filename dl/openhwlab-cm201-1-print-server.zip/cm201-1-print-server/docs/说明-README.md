# 说明 README —— 机顶盒变打印机服务器（开发者）

本项目的组成与数据流。

## 组成

```
[手机/电脑浏览器] --:8080--> printd.py (网页打印门户/管理/驱动向导/二维码)
                                   |
                                   v
                          CUPS (:631)  --> USB 打印机
[盒子屏幕] 桌面.apk (com.openhwlab.printsrv)
   ├─ 左：内嵌 WebView 载 http://127.0.0.1:8080/  (打印/拖拽/二维码)
   └─ 右：菜单(驱动管理/测试页/复制地址/回到首页) —— 通过 HTTP 调 printd 的 /api/*
[Mac/iPhone] --:631/avahi--> CUPS (AirPrint)
[电脑]       --:631--> IPP 直连打印机
```

## 文件

- `打印服务.py` (printd.py)：纯标准库 HTTP 服务，端口 8080。
  - 页面：`/`(打印页,未配自动转 /setup) `/setup`(向导) `/admin`(管理) `/upage/qr` 等；
  - 二维码：`/qr.png`(打印页) `/ippqr.png`(打印机地址) `/setupqr.png`(设置页)；
  - 动作：`/print`(传文件打印) `/qrprint`(打 A4 二维码贴纸)；
  - 给本地 App 的 JSON：`/api/{detect,queues,search,install,test,setdefault,delete,online,onlinesearch,localfiles,installfile,ls}`。
  - 默认队列存 `/root/print.set`。
- `二维码贴纸.py` (qrsheet.py)：PIL 生成 A4(300dpi) 版式 2×3=6 张，每张上方标注文字。
- `桌面.apk` (com.openhwlab.printsrv)：原生 Android 桌面（HOME）。含 MainActivity/Manager/Setup/FileInstall/Qr。
- `startbox.sh` / `bootlinux.sh`：子系统与盒子的开机脚本。

## 关键接口（App ⇄ printd）
- `GET /api/detect` → 打印机/队列/型号(1284)/打印机地址(ipp)/打印页URL。
- `GET /api/search?q=` → 本地库匹配的驱动型号列表。
- `GET /api/onlinesearch?q=` → 联网(apt)获取驱动包后返回匹配型号。
- `POST /api/install`(ppd,uri,pname) / `installfile`(path,uri,pname) → 建/改队列。
- `POST /api/{test,setdefault,delete}`、`GET /api/queues`、`GET /api/ls`(浏览U盘/本地)。

## 构建桌面 App
`build-printsrv.sh`（复用 kiosk 工具链：jdk8 + aapt81 + d8 + android-4.4.2）：
```
cd <工具链目录> && ./build-printsrv.sh    # 输出 printsrv.apk
```
源码在 `源码/`（Java + 资源）。

## 依赖（子系统）
`cups cups-filters avahi-daemon avahi-utils printer-driver-gutenprint printer-driver-brlaser printer-driver-cups-pdf python3-pil fonts-droid-fallback qrencode`

—— OpenHW Lab
