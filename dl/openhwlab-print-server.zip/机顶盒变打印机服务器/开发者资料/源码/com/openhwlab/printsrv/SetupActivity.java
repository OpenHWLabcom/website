package com.openhwlab.printsrv;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

/** 驱动设置: 插好USB自动带型号并搜索 -> 遥控器选驱动 -> OK 安装; 也可联网按品牌装。 */
public class SetupActivity extends Activity {
    private ArrayAdapter<String> ad;
    private ArrayList<String> labels = new ArrayList<String>();
    private ArrayList<String> candUris = new ArrayList<String>();   // 与候选行一一对应
    private ArrayList<Integer> kinds = new ArrayList<Integer>();     // 0=驱动 1=联网 2=返回
    private String usbUri = "";
    private String model = "";
    private String pname = "";
    private int sel = 0;
    private String lastKey = "";
    private ListView list;
    private TextView detectTv, hintTv;
    private boolean busy = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (getIntent() != null && getIntent().getStringExtra("pname") != null)
            pname = getIntent().getStringExtra("pname");

        LinearLayout L = new LinearLayout(this);
        L.setOrientation(LinearLayout.VERTICAL);
        L.setBackgroundColor(0xFF0F172A);
        L.setPadding(44, 30, 44, 30);

        TextView t = new TextView(this); t.setText("\uD83D\uDD27 驱动设置");
        t.setTextSize(26); t.setTextColor(0xFFFFFFFF); L.addView(t);
        detectTv = new TextView(this); detectTv.setTextSize(16); detectTv.setTextColor(0xFF9FD0FF);
        detectTv.setPadding(0, 6, 0, 4); L.addView(detectTv);
        hintTv = new TextView(this); hintTv.setTextSize(14); hintTv.setTextColor(0xFF7F93B3);
        hintTv.setPadding(0, 0, 0, 6); L.addView(hintTv);

        list = new ListView(this); list.setBackgroundColor(0xFF0E1830);
        ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels);
        list.setAdapter(ad);
        list.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) { activate(pos); } });
        L.addView(list);

        setContentView(L, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        list.requestFocus();
        loadDetect();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int kc = e.getKeyCode();
            if (kc == KeyEvent.KEYCODE_DPAD_DOWN) { move(1); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_UP) { move(-1); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER
                    || kc == KeyEvent.KEYCODE_NUMPAD_ENTER) { activate(sel); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    private void move(int d) {
        if (labels.isEmpty()) return;
        sel += d;
        if (sel < 0) sel = 0;
        if (sel > labels.size() - 1) sel = labels.size() - 1;
        list.setSelection(sel);
    }

    private void loadDetect() {
        new Thread(new Runnable() { public void run() {
            final String s = Http.get("/api/detect");
            runOnUiThread(new Runnable() { public void run() {
                try {
                    JSONObject o = new JSONObject(s);
                    JSONArray ps = o.optJSONArray("printers");
                    String dm = o.optString("model", "");
                    boolean hostBased = false;
                    JSONArray dv = o.optJSONArray("devid");
                    if (dv != null && dv.length() > 0) hostBased = dv.getJSONObject(0).optBoolean("host_based");
                    if (ps != null && ps.length() > 0) {
                        String nm = ps.getJSONArray(0).optString(0);
                        usbUri = ps.getJSONArray(0).optString(1);
                        model = dm.length() > 0 ? dm
                                : nm.replace("usb://", "").split("\\?")[0].replace("/", " ").trim();
                        detectTv.setText("已检测到 USB 打印机：" + model
                                + (hostBased ? "（主机型/GDI → 优先 brlaser）" : ""));
                    } else {
                        model = dm;
                        detectTv.setText("未检测到 USB 打印机（请插好后再进此页）");
                    }
                } catch (Exception e) { detectTv.setText("读取打印机状态失败"); }
                if (usbUri.length() > 0 && model.length() > 0) search();
                else { hintTv.setText("插好 USB 打印机后重进本页即可。"); showTail(); }
            } });
        } }).start();
    }

    private void showTail() {
        labels.add("\uD83C\uDF10 联网检索驱动型号（按品牌）"); kinds.add(1); candUris.add("");
        labels.add("\u2B05 返回"); kinds.add(2); candUris.add("");
        ad.notifyDataSetChanged();
    }

    private void search() {
        hintTv.setText("搜索驱动中…");
        new Thread(new Runnable() { public void run() {
            final String s = Http.get("/api/search?q=" + Http.enc(model));
            runOnUiThread(new Runnable() { public void run() {
                labels.clear(); candUris.clear(); kinds.clear(); lastKey = "";
                try {
                    JSONArray a = new JSONArray(s);
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject o = a.getJSONObject(i);
                        labels.add(o.optString("make"));
                        candUris.add(o.optString("uri"));
                        kinds.add(0);
                    }
                } catch (Exception e) { }
                showTail();
                ad.notifyDataSetChanged();
                sel = 0; list.setSelection(0);
                if (candUris.size() <= 2)
                    hintTv.setText("本地库没匹配到 → 选下面「联网下载该品牌驱动」。遥控器 ↑↓ 选择 · OK 执行");
                else
                    hintTv.setText("共 " + (candUris.size() - 2) + " 个候选，多选第一个。遥控器 ↑↓ 选择 · OK 执行");
            } });
        } }).start();
    }

    private void activate(int pos) {
        Log.i("psrv", "setup activate " + pos);
        if (pos < 0 || pos >= kinds.size()) return;
        if (kinds.get(pos) == 1) { online(); return; }
        if (kinds.get(pos) == 2) { finish(); return; }
        install(candUris.get(pos));
    }

    private void online() {
        if (busy) return;
        if (model.length() == 0) { toast("没有型号，无法联网检索"); return; }
        busy = true; hintTv.setText("联网检索驱动型号中…（1-3 分钟）");
        new Thread(new Runnable() { public void run() {
            final String s = Http.get("/api/onlinesearch?q=" + Http.enc(model));
            runOnUiThread(new Runnable() { public void run() {
                busy = false;
                int n = 0;
                try {
                    JSONObject o = new JSONObject(s);
                    JSONArray a = o.optJSONArray("cands");
                    labels.clear(); candUris.clear(); kinds.clear(); lastKey = "";
                    if (a != null) {
                        n = a.length();
                        for (int i = 0; i < a.length(); i++) {
                            JSONObject c = a.getJSONObject(i);
                            labels.add(c.optString("make"));
                            candUris.add(c.optString("uri"));
                            kinds.add(0);
                        }
                    }
                    showTail();
                    ad.notifyDataSetChanged(); sel = 0; list.setSelection(0);
                    hintTv.setText(n > 0
                            ? "联网检索到 " + n + " 个驱动型号，选中后按 OK 安装"
                            : "联网没检索到该型号，换个写法或上传 .ppd");
                } catch (Exception e) {
                    hintTv.setText("联网检索失败（服务未就绪或网络不通）");
                }
            } });
        } }).start();
    }

    private void install(final String ppd) {
        if (busy || ppd.length() == 0) return;
        final String name = (pname.length() > 0) ? pname : autoName();
        busy = true; hintTv.setText("安装中…");
        new Thread(new Runnable() { public void run() {
            final String s = Http.post("/api/install",
                    "ppd=" + Http.enc(ppd) + "&uri=" + Http.enc(usbUri) + "&pname=" + Http.enc(name));
            runOnUiThread(new Runnable() { public void run() {
                busy = false;
                try {
                    JSONObject o = new JSONObject(s);
                    if (o.optBoolean("ok")) { toast("安装成功 ✓ 去管理页打张测试页"); finish(); }
                    else { toast("失败: " + o.optString("msg")); hintTv.setText("安装失败，见提示"); }
                } catch (Exception e) { toast("失败：服务无响应"); }
            } });
        } }).start();
    }

    private String autoName() {
        String b = usbUri;
        int q = b.indexOf('?');
        if (q >= 0) b = b.substring(0, q);
        b = b.substring(b.lastIndexOf('/') + 1);
        b = b.replaceAll("[^A-Za-z0-9._-]", "");
        if (b.length() == 0) {
            String[] parts = model.trim().split("\\s+");
            b = parts[parts.length - 1].replaceAll("[^A-Za-z0-9._-]", "");
        }
        return b.length() > 0 ? b : "printer";
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
