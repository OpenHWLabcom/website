import time
import usb.core, usb.util

dev = usb.core.find(idVendor=0x17ef, idProduct=0x5624)
cfg = dev.get_active_configuration()
intf = [i for i in cfg if i.bInterfaceClass == 7][0]
epo = usb.util.find_descriptor(intf, custom_match=lambda e: usb.util.endpoint_type(e.bmAttributes) == 2 and usb.util.endpoint_direction(e.bEndpointAddress) == 0)
epi = usb.util.find_descriptor(intf, custom_match=lambda e: usb.util.endpoint_type(e.bmAttributes) == 2 and usb.util.endpoint_direction(e.bEndpointAddress) == 0x80)
try:
    if dev.is_kernel_driver_active(intf.bInterfaceNumber):
        dev.detach_kernel_driver(intf.bInterfaceNumber)
except Exception:
    pass
for a in range(6):
    try:
        usb.util.claim_interface(dev, intf.bInterfaceNumber)
        break
    except Exception:
        time.sleep(1)
epo.write(b"\x1b%-12345X@PJL INFO PAGECOUNT\r\n\x1b%-12345X\r\n", timeout=5000)
time.sleep(1.0)
out = b""
t0 = time.time()
while time.time() - t0 < 3:
    try:
        out += bytes(epi.read(2048, timeout=1500))
    except Exception:
        break
usb.util.release_interface(dev, intf.bInterfaceNumber)
print(out.decode("latin1").replace("\r", "\\r").replace("\n", "\\n"))
