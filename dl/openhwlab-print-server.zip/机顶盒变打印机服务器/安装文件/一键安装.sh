#!/bin/bash
# ============================================================
#  OpenHW Lab · 机顶盒变打印机服务器 —— 一键安装（在电脑上跑）
#  用法：  ./一键安装.sh <盒子IP>
#  前提：  盒子已 root、已开 ADB 调试、电脑装了 adb、同一局域网；
#          盒子已建好 Linux 子系统 /data/linux（见教程第 3 步）。
#  作用：  推打印服务脚本进子系统、装打印服务器桌面、提示装依赖。
#          可重复执行（幂等）。
# ============================================================
set -e
IP="$1"
[ -z "$IP" ] && { echo "用法: $0 <盒子IP>"; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"
R=/data/linux
say(){ echo -e "\n\033[1;36m==> $*\033[0m"; }

say "连接盒子 $IP:5555"
adb connect "${IP}:5555"
adb wait-for-device

say "检查 Linux 子系统"
adb shell "[ -d $R/root ] || { echo '未找到 $R （先按教程搭好 Linux 子系统）'; exit 1; }"

say "推打印服务脚本到子系统（chroot 的 /root）"
adb push "$HERE/打印服务.py"   $R/root/printd.py
adb push "$HERE/二维码贴纸.py" $R/root/qrsheet.py

say "装打印服务器桌面 App"
adb push "$HERE/桌面.apk" /sdcard/printsrv.apk
adb shell 'pm install -r /sdcard/printsrv.apk'

say "提示：在子系统里装依赖（首次，需联网 apt）"
echo "  在子系统里执行："
echo "    apt-get update && apt-get install -y cups cups-filters avahi-daemon avahi-utils \\"
echo "      printer-driver-gutenprint printer-driver-brlaser printer-driver-cups-pdf \\"
echo "      python3-pil fonts-droid-fallback qrencode"
echo "  或一步（在电脑上跑）："
echo "    adb shell \"busybox chroot $R /usr/bin/env PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin /bin/bash -c 'apt-get update && apt-get install -y cups cups-filters avahi-daemon avahi-utils printer-driver-gutenprint printer-driver-brlaser printer-driver-cups-pdf python3-pil fonts-droid-fallback qrencode'\""

say "提示：配置开机自启（把启动脚本放进子系统/盒子）"
echo "  子系统：把 3-开机自启.sh 的内容并入 /root/startbox.sh（dbus+cupsd+avahi+printd）"
echo "  盒子：  把 4-开机兜底.sh 放到 /data/bootlinux.sh（挂子系统 + 进桌面）"

say "现在可手动起一次服务（在子系统里）"
echo "  dbus-daemon --system --fork"
echo "  /usr/sbin/cupsd"
echo "  avahi-daemon -D --no-chroot --no-drop-root"
echo "  python3 /root/printd.py &"

say "完成！手机/电脑浏览器打开： http://$IP:8080/   （未配打印机时会自动进设置向导）"
