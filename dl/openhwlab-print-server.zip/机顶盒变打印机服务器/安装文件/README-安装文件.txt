========================================
  安装文件 · 说明（OpenHW Lab 机顶盒变打印机服务器）
========================================

先读顶层「安装教程.pdf」（图文），照着做即可。

本目录文件：

  一键安装.sh            ← 电脑上跑：./一键安装.sh <盒子IP>
                            （推服务脚本 + 装桌面 + 提示装依赖，一步到位）
  桌面.apk               ← 打印服务器桌面（开机即进：内嵌网页打印界面 + 菜单 + 二维码）
                            → pm install -r 后设为盒子 HOME
  打印服务.py            ← 网页打印门户/管理/驱动向导/二维码 → 子系统 /root/printd.py（:8080）
  二维码贴纸.py          ← A4 一版 6 张二维码贴纸生成 → /root/qrsheet.py
  3-开机自启.sh          ← 子系统启动脚本（dbus/cupsd/avahi/printd）→ /root/startbox.sh
  4-开机兜底.sh          ← 盒子开机脚本（挂子系统/起服务/进桌面）→ /data/bootlinux.sh

端口一览：
  8080  网页打印门户（手机扫码传文件打印 / 管理 / 驱动向导）
  631   CUPS 打印服务（电脑按 IPP 加打印机）
  5353  avahi（Mac/iPhone AirPrint 自动发现）

怎么用：
  A) 省事：连好 adb，跑  ./一键安装.sh <盒子IP>
  B) 手动：按「安装教程.pdf」一步步复制文件、执行命令（可照抄）

依赖（在 Linux 子系统里装，apt 走 http 镜像）：
  cups cups-filters avahi-daemon avahi-utils
  printer-driver-gutenprint printer-driver-brlaser printer-driver-cups-pdf
  python3-pil fonts-droid-fallback qrencode
  （python3-pil + fonts-droid-fallback 只在用「二维码贴纸」时需要，顺带让中文能打印）

—— OpenHW Lab · 智能硬件开放实验室
