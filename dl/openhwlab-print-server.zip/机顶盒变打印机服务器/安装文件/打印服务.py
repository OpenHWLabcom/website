#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OpenHW Lab 打印服务器 (@ HG680-J) — 纯打印场景
打开 http://<盒子IP>:8080/ :
  - 已配置打印机 -> 网页打印(选文件 -> 打印)
  - 未配置       -> 打印机设置向导(输入型号 -> 自动装驱动)
管理界面: http://<盒子IP>:8080/admin  (查看/测试/删除/更换驱动)

路由:
  /                 网页打印页(带二维码) 未配置时转 /setup
  /setup            设置向导: 输入型号 / 检测 USB / 上传 .ppd / 联网检索驱动
  /admin            管理控制台: 队列列表 + 设默认/测试页/删除/换驱动
  /tv               电视页(全屏显示二维码, HOME 应用打开)
  /print  POST      上传文件 -> lp 打印
  /qr.png /adminqr.png   二维码
🔒 保密模式: 打印后清 CUPS 任务/日志/上传文件(默认开)。
"""
import os, sys, re, glob, uuid, time, socket, subprocess, shutil, html, urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

HOST = "0.0.0.0"
PORT = 8080
QR = "/root/printqr.png"        # 打印页二维码
AQR = "/root/adminqr.png"       # 管理页二维码
TMP = "/tmp/printjobs"
DNS = "/root/print.set"         # printer=<默认队列名>
os.makedirs(TMP, exist_ok=True)

_ppd_cache = {"t": 0, "list": []}

ALIAS = {                        # 主机型(GDI)打印机 -> brlaser 对应型号
    "m7206": "drv:///brlaser.drv/br1600.ppd",
    "m7206w": "drv:///brlaser.drv/br1600.ppd",
    "m7216": "drv:///brlaser.drv/br1600.ppd",
}
QUICK = [
    ("联想 Lenovo M7206W", "Lenovo M7206W"),
    ("联想 Lenovo M7268W", "Lenovo M7268W"),
    ("兄弟 Brother DCP-1600", "Brother DCP-1600"),
    ("惠普 HP LaserJet 1020", "HP LaserJet 1020"),
]
BRAND_PKG = {                    # 品牌 -> 联网需装的 Ubuntu 驱动包(apt, 走 HTTP 镜像)
    "hp": ["printer-driver-hpcups", "printer-driver-postscript-hp"],
    "hewlett": ["printer-driver-hpcups", "printer-driver-postscript-hp"],
    "惠普": ["printer-driver-hpcups", "printer-driver-postscript-hp"],
    "samsung": ["printer-driver-splix"], "xerox": ["printer-driver-splix"],
    "三星": ["printer-driver-splix"], "施乐": ["printer-driver-splix"],
    "epson": ["printer-driver-escpr"], "爱普生": ["printer-driver-escpr"],
    "canon": ["printer-driver-cjet"], "佳能": ["printer-driver-cjet"],
    "brother": ["printer-driver-brlaser"], "lenovo": ["printer-driver-brlaser"],
    "兄弟": ["printer-driver-brlaser"], "联想": ["printer-driver-brlaser"],
    "lexmark": ["printer-driver-splix", "printer-driver-c2050"],
    "ricoh": ["printer-driver-sag-gdi"],
    "konica": ["printer-driver-min12xxw", "printer-driver-foo2zjs"],
    "minolta": ["printer-driver-min12xxw"],
    "oki": ["printer-driver-oki"], "fuji": ["printer-driver-fujixerox"],
    "dymo": ["printer-driver-dymo"], "kodak": ["printer-driver-c2esp"],
}
ONLINE_FALLBACK = ["openprinting-ppds"]


def run(cmd, t=90):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=t)
        return r.returncode, (r.stdout + r.stderr).decode("utf-8", "ignore").strip()
    except Exception as e:
        return 1, str(e)


def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close(); return ip
    except Exception:
        return "127.0.0.1"


IP = local_ip()
URL = "http://%s:%d/" % (IP, PORT)
AURL = "http://%s:%d/admin" % (IP, PORT)


# ---------------------------------------------------------------- 驱动库

def _tok(s):
    stop = {"series", "using", "cups", "gutenprint", "with", "options", "printer",
            "driver", "the", "and", "expert", "simplified", "standard", "new", "for"}
    return [t for t in re.findall(r"[a-z0-9]+", s.lower()) if len(t) >= 2 and t not in stop]


def list_ppds():
    now = time.time()
    if _ppd_cache["list"] and now - _ppd_cache["t"] < 300:
        return _ppd_cache["list"]
    out = []
    rc, s = run(["lpinfo", "-m"], 60)
    if rc == 0:
        for line in s.splitlines():
            line = line.strip()
            if line and " " in line:
                uri, mm = line.split(" ", 1)
                out.append((uri, mm.strip()))
    _ppd_cache.update(t=now, list=out)
    return out


def search_ppds(q, limit=25):
    q = (q or "").strip()
    ql = re.sub(r"[^a-z0-9]", "", q.lower())
    qt = _tok(q)
    res = []
    for k, uri in ALIAS.items():
        if k in ql:
            for u, mm in list_ppds():
                if u == uri:
                    res.append((u, mm)); break
            break
    scored = []
    for uri, mm in list_ppds():
        mt = set(_tok(mm))
        ml = re.sub(r"[^a-z0-9]", "", mm.lower())
        sc = 0
        for t in qt:
            if t in mt:
                sc += 3
            elif any(t in x for x in mt):
                sc += 1
        if ql and ql in ml:
            sc += 6
        if sc > 0:
            scored.append((sc, -len(mm), uri, mm))
    scored.sort(reverse=True)
    for sc, _, uri, mm in scored:
        if (uri, mm) not in res:
            res.append((uri, mm))
        if len(res) >= limit:
            break
    if ("lenovo" in ql) or ("联想" in q) or ("brother" in ql):
        for uri, mm in list_ppds():
            if "/brlaser.drv/" in uri and (uri, mm) not in res:
                res.append((uri, mm))
    return res[:limit]


def detect_usb():
    out = []
    rc, s = run(["lpinfo", "-v"], 30)
    if rc == 0:
        for line in s.splitlines():
            line = line.strip()
            if line.startswith("direct usb://"):
                out.append((urllib.parse.unquote(line[7:]), line[7:]))
    return out


def _usb_printer_ids():
    """从 sysfs 找 USB 打印机(bInterfaceClass=07)的设备。"""
    out = []
    for f in glob.glob("/sys/bus/usb/devices/*/*/bInterfaceClass"):
        try:
            if open(f).read().strip().lstrip("0") != "7":
                continue
            base = os.path.dirname(os.path.dirname(f))
            v = open(base + "/idVendor").read().strip()
            p = open(base + "/idProduct").read().strip()
            mfg = open(base + "/manufacturer").read().strip() if os.path.exists(base + "/manufacturer") else ""
            prd = open(base + "/product").read().strip() if os.path.exists(base + "/product") else ""
            out.append((v, p, mfg, prd))
        except Exception:
            pass
    return out


def device_ids():
    """读 USB 打印机的 IEEE-1284 设备ID (MFG/MDL/CMD)，识别型号 + 是否主机型(GDI)。"""
    res = []
    try:
        import usb.core
    except Exception:
        return res
    for (v, p, umfg, uprd) in _usb_printer_ids():
        info = {"vid": v, "pid": p, "usb_mfg": umfg, "usb_product": uprd,
                "mfg": "", "mdl": "", "cmd": "", "raw": ""}
        try:
            dev = usb.core.find(idVendor=int(v, 16), idProduct=int(p, 16))
            if dev is not None:
                r = None
                for wVal in (0x0300, 0):
                    try:
                        r = dev.ctrl_transfer(0xA1, 0x00, wVal, 0, 1024, timeout=3000)
                        break
                    except Exception:
                        pass
                if r is not None:
                    b = bytes(r)
                    s = (b[2:2 + (b[0] | (b[1] << 8))] if len(b) >= 2 else b).decode("latin1", "replace")
                    info["raw"] = s
                    for part in s.split(";"):
                        if ":" in part:
                            k, val = part.split(":", 1)
                            k = k.strip().upper()
                            if k == "MFG": info["mfg"] = val.strip()
                            elif k == "MDL": info["mdl"] = val.strip()
                            elif k == "CMD": info["cmd"] = val.strip()
        except Exception:
            pass
        info["model"] = ("%s %s" % (info["mfg"] or umfg, info["mdl"] or uprd)).strip()
        c = info["cmd"].upper()
        info["host_based"] = ("HBP" in c) or (bool(c) and not any(x in c for x in ("PCL", "POSTSCRIPT", "PJL")))
        res.append(info)
    return res


def cur_printer():
    try:
        with open(DNS) as f:
            for ln in f:
                if ln.startswith("printer="):
                    p = ln.split("=", 1)[1].strip()
                    if p:
                        return p
    except Exception:
        pass
    for q in queues():
        if not q["is_pdf"]:
            return q["name"]
    return None


def save_printer(name):
    try:
        with open(DNS, "w") as f:
            f.write("printer=%s\n" % name)
    except Exception:
        pass


def queues():
    """列出所有打印队列。"""
    uris = {}
    rc, v = run(["lpstat", "-v"], 20)
    for ln in (v or "").splitlines():
        m = re.match(r"device for ([^:]+):\s*(.+)$", ln)
        if m:
            uris[m.group(1).strip()] = m.group(2).strip()
    default = ""
    rc, d = run(["lpstat", "-d"], 20)
    m = re.search(r"default destination:\s*(\S+)", d or "")
    if m:
        default = m.group(1)
    out = []
    for name in sorted(uris):
        uri = uris[name]
        rc, l = run(["lpstat", "-l", "-p", name], 20)
        l = l or ""
        mm = re.search(r"Description:\s*(.+)", l)
        model = mm.group(1).strip() if mm else ""
        if not model or model == name:
            try:
                nn = mn = ""
                with open("/etc/cups/ppd/%s.ppd" % name, errors="ignore") as pf:
                    for ln in pf:
                        if ln.startswith("*NickName:"):
                            nn = ln.split(":", 1)[1].strip().strip('"')
                        elif ln.startswith("*ModelName:") and not mn:
                            mn = ln.split(":", 1)[1].strip().strip('"')
                model = nn or mn or model
            except Exception:
                pass
        first = l.split("\n")[0] if l else ""
        ms = re.search(r"printer \S+ is ([\w ]+?)[\.\s]", first)
        state = ms.group(1).strip() if ms else ""
        out.append({
            "name": name, "uri": uri, "model": model, "state": state,
            "enabled": "disabled" not in first.lower(),
            "accepting": "not accepting" not in l,
            "default": (name == default),
            "is_pdf": ("cups-pdf" in uri),
        })
    return out


def make_qr(url, path):
    try:
        subprocess.run(["qrencode", "-o", path, "-s", "10", "-m", "2", url],
                       capture_output=True, timeout=10)
    except Exception:
        pass


def qr_bytes(url):
    """动态生成二维码(按内容缓存到 /tmp)，返回 PNG 字节。"""
    if not url:
        return None
    import hashlib
    fn = "/tmp/qr_" + hashlib.md5(url.encode("utf-8")).hexdigest()[:12] + ".png"
    if not os.path.exists(fn):
        try:
            subprocess.run(["qrencode", "-o", fn, "-s", "10", "-m", "2", url],
                           capture_output=True, timeout=10)
        except Exception:
            return None
    try:
        with open(fn, "rb") as f:
            return f.read()
    except Exception:
        return None


def printer_addr():
    """本机给局域网用的打印机地址(IPP)。未配置时为空。"""
    cur = cur_printer()
    return ("ipp://%s:631/printers/%s" % (IP, cur)) if cur else ""


def disk_free_mb():
    try:
        st = os.statvfs("/")
        return st.f_bavail * st.f_frsize // (1024 * 1024)
    except Exception:
        return -1


def brand_pkgs(model):
    q = (model or "").lower()
    pkgs = []
    for k, v in BRAND_PKG.items():
        if k in q:
            pkgs += v
    if not pkgs:
        pkgs = list(ONLINE_FALLBACK)
    seen, out = set(), []
    for p in pkgs:
        if p not in seen:
            seen.add(p); out.append(p)
    return out


def apt_sim(pkgs):
    rc, out = run(["apt-get", "-y", "--print-uris", "install", "--no-install-recommends"] + pkgs, 120)
    total = 0
    for ln in out.splitlines():
        m = re.match(r"^'(\S+)'\s+\S+\s+(\d+)\s", ln)
        if m:
            total += int(m.group(2))
    _, so = run(["apt-get", "-s", "install", "-y", "--no-install-recommends"] + pkgs, 120)
    newp = re.findall(r"^Inst (\S+)", so, re.M)
    size = ((" %.1f MB" % (total / 1048576.0)) if total > 1048576 else ("%d KB" % (total // 1024))) if total else "?"
    return rc, size, newp


def apt_install(pkgs):
    rc, out = run(["apt-get", "install", "-y", "--no-install-recommends"] + pkgs, 900)
    if rc != 0 and ("Unable to fetch" in out or "404" in out or "not be found" in out
                    or "has no installation candidate" in out):
        run(["apt-get", "-o", "Acquire::Retries=2", "update"], 900)
        rc, out = run(["apt-get", "install", "-y", "--no-install-recommends"] + pkgs, 900)
    return rc, out


# ---------------------------------------------------------------- 打印动作

def do_print(path, printer):
    rc, out = run(["lp", "-d", printer, "-o", "media=A4", path], 120)
    ok = (rc == 0 and "request id" in out)
    return ok, (out if ok else ("打印命令失败: " + out))


def wipe():
    for f in glob.glob("/var/spool/cups/d*") + glob.glob("/var/spool/cups/c*"):
        try: os.remove(f)
        except Exception: pass
    for lg in ("/var/log/cups/access_log", "/var/log/cups/page_log", "/var/log/cups/error_log"):
        try:
            with open(lg, "w"):
                pass
        except Exception: pass
    shutil.rmtree("/var/spool/cups-pdf", ignore_errors=True)


# ---------------------------------------------------------------- 供本地 App 调用的动作

def install_driver(ppd, uri, pname):
    pname = re.sub(r"[^A-Za-z0-9._-]", "", pname or "") or ("pr_" + uuid.uuid4().hex[:6])
    if not ppd:
        return False, "没有选择驱动"
    if not uri:
        return False, "没有可用连接（USB 未检测到？）"
    rc0, _ = run(["lpstat", "-p", pname], 20)
    exists = (rc0 == 0)
    if exists:
        rc, out = run(["lpadmin", "-p", pname, "-v", uri, "-m", ppd], 90)
    else:
        rc, out = run(["lpadmin", "-p", pname, "-E", "-v", uri, "-m", ppd], 90)
    if rc != 0:
        return False, "%s队列失败: %s" % ("修改" if exists else "新建", out)
    run(["lpadmin", "-d", pname], 20)
    run(["lpadmin", "-p", pname, "-o", "printer-is-shared=true"], 20)
    run(["cupsenable", pname], 20)
    run(["cupsaccept", pname], 20)
    save_printer(pname)
    return True, "已%s打印机 “%s”\n连接：%s\n驱动：%s" % ("修改" if exists else "新建", pname, uri, ppd)


def test_print(name):
    if not name:
        return False, "没有打印机"
    msg = "打印服务器 测试页\n打印机: %s\n时间: %s\n中文测试 OK\n%s" % (
        name, time.strftime("%Y-%m-%d %H:%M:%S"), "=" * 30)
    tp = os.path.join(TMP, "test.txt")
    with open(tp, "w", encoding="utf-8") as f:
        f.write(msg + "\n")
    ok, out = do_print(tp, name)
    try: os.remove(tp)
    except Exception: pass
    return ok, (("测试页已发出 ✓\n" if ok else "") + out)


def set_default(name):
    if not name:
        return False, "没有打印机"
    rc, out = run(["lpadmin", "-d", name], 20)
    if rc == 0:
        save_printer(name)
    return rc == 0, out


def delete_printer(name):
    rc, out = run(["lpadmin", "-x", name], 30)
    if rc == 0:
        try:
            if open(DNS).read().strip().endswith(name):
                os.remove(DNS)
        except Exception:
            pass
        _ppd_cache["t"] = 0
    return rc == 0, out


def _walk_drivers(base, maxdepth=2, out=None, skip=None):
    if out is None:
        out = []
    if skip is None:
        skip = ("Android", "DCIM", ".thumbnails", ".cache", "lost+found")
    if not os.path.isdir(base):
        return out
    base = base.rstrip("/")
    for root, ds, fs in os.walk(base):
        depth = root[len(base):].count(os.sep)
        ds[:] = [d for d in ds if d not in skip and not d.startswith(".")]
        if depth >= maxdepth:
            ds[:] = []
        for fn in fs:
            lf = fn.lower()
            if lf.endswith(".ppd") or lf.endswith(".ppd.gz"):
                p = os.path.join(root, fn)
                try:
                    sz = os.path.getsize(p)
                except Exception:
                    sz = 0
                if 0 < sz < 60 * 1024 * 1024:
                    out.append({"name": fn, "path": p, "size": sz, "dir": root})
        if len(out) >= 200:
            break
    return out


def local_drivers():
    """扫描盒子本地 / U盘 上的 .ppd 驱动文件。"""
    out = []
    shallow = ["/sdcard", "/sdcard/Download", "/sdcard/驱动", "/root"]
    for d in shallow:
        _walk_drivers(d, 1, out)
    # U盘 / 外置存储 (Android 侧): /proc/1/root 可见
    for d in glob.glob("/proc/1/root/storage/*") + glob.glob("/proc/1/root/mnt/media_rw/*") \
            + glob.glob("/proc/1/root/mnt/usb*") + glob.glob("/mnt/*"):
        if os.path.isdir(d) and "emulated" not in d:
            _walk_drivers(d, 2, out)
    seen, uniq = set(), []
    for f in out:
        if f["path"] not in seen:
            seen.add(f["path"]); uniq.append(f)
    return uniq[:200]


def _vol_info(path):
    try:
        st = os.statvfs(path)
        return st.f_bavail * st.f_frsize, st.f_blocks * st.f_frsize
    except Exception:
        return 0, 0


def usb_roots():
    """可移动存储(U盘)挂载点 —— 读 /proc/mounts 找 vfat/ntfs/exfat 等可移动盘,
    再从 chroot 通过 /proc/1/root<挂载点> 访问。"""
    usbfs = ("tntfs", "ntfs", "vfat", "exfat", "fuseblk", "texfat", "msdos",
             "iso9660", "udf", "fuse", "sdcardfs")
    roots = []
    try:
        with open("/proc/mounts") as f:
            for ln in f:
                p = ln.split()
                if len(p) < 3:
                    continue
                mp = p[1].replace("\\040", " ")
                fst = p[2]
                if fst not in usbfs:
                    continue
                if mp.startswith("/storage/emulated") or mp == "/mnt/sdcard":
                    continue
                if mp in ("/mnt/secure", "/mnt/asec", "/mnt/obb", "/mnt/shell", "/mnt/media_rw"):
                    continue
                if not (mp.startswith("/mnt/") or mp.startswith("/media/") or mp.startswith("/storage/")):
                    continue
                rp = "/proc/1/root" + mp
                if os.path.isdir(rp) and rp not in roots:
                    roots.append(rp)
    except Exception:
        pass
    if not roots:                                  # 退化: 扫目录
        skip = ("emulated", "self", "sdcard", "secure", "asec", "obb", "shell", "media_rw", "runtime")
        for pat in ("/proc/1/root/storage/*", "/proc/1/root/mnt/media_rw/*", "/mnt/*"):
            for d in sorted(glob.glob(pat)):
                if os.path.basename(d) in skip or not os.path.isdir(d):
                    continue
                if d not in roots:
                    roots.append(d)
    return roots


def allowed_roots():
    r = usb_roots()
    if "/sdcard" not in r:
        r.append("/sdcard")
    return r


def _path_allowed(p):
    try:
        rp = os.path.realpath(p)
    except Exception:
        return False
    for r in allowed_roots():
        rr = os.path.realpath(r)
        if rp == rr or rp.startswith(rr + "/"):
            return True
    return False


def ls_entries(path):
    out = []
    try:
        for fn in sorted(os.listdir(path)):
            if fn.startswith("."):
                continue
            p = os.path.join(path, fn)
            try:
                isdir = os.path.isdir(p)
                sz = 0 if isdir else os.path.getsize(p)
            except Exception:
                isdir = False; sz = 0
            out.append({"name": fn, "path": p, "isdir": isdir, "size": sz})
    except Exception:
        pass
    return out


def browse(path):
    """path 为空 -> 返回存储根列表; 否则返回该目录内容。"""
    if not path:
        vols = []
        for r in allowed_roots():
            free, total = _vol_info(r)
            disp = r.replace("/proc/1/root", "")
            vols.append({"name": os.path.basename(r), "path": r, "disp": disp, "free": free,
                         "total": total, "removable": (r != "/sdcard")})
        return {"roots": vols, "path": ""}
    if not _path_allowed(path):
        return {"error": "路径不被允许", "path": path}
    path = path.rstrip("/") or "/"
    parent = os.path.dirname(path)
    allowed_parent = parent if (_path_allowed(parent) and parent != path) else ""
    return {"path": path, "parent": allowed_parent, "entries": ls_entries(path)}


def install_file(path, uri, pname):
    """用本地 .ppd 文件安装/更换驱动。"""
    if not path or not os.path.exists(path):
        return False, "文件不存在：%s" % path
    lp = path
    if path.lower().endswith(".gz"):
        run(["gunzip", "-kf", path], 30)
        lp = path[:-3]
        if not os.path.exists(lp):
            return False, "解压失败：%s" % path
    if not uri:
        d = detect_usb()
        uri = d[0][1] if d else ""
    if not uri:
        return False, "没有可用连接（USB 未检测到？）"
    pname = re.sub(r"[^A-Za-z0-9._-]", "", pname or "") or ("pr_" + uuid.uuid4().hex[:6])
    rc0, _ = run(["lpstat", "-p", pname], 20)
    exists = (rc0 == 0)
    if exists:
        rc, out = run(["lpadmin", "-p", pname, "-v", uri, "-P", lp], 90)
    else:
        rc, out = run(["lpadmin", "-p", pname, "-E", "-v", uri, "-P", lp], 90)
    if rc != 0:
        return False, "%s队列失败: %s" % ("修改" if exists else "新建", out)
    run(["lpadmin", "-d", pname], 20)
    run(["lpadmin", "-p", pname, "-o", "printer-is-shared=true"], 20)
    run(["cupsenable", pname], 20)
    run(["cupsaccept", pname], 20)
    save_printer(pname)
    return True, "已用 %s 建打印机 “%s”\n连接：%s" % (os.path.basename(path), pname, uri)


# ---------------------------------------------------------------- 页面

CSS = """body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;margin:0;
background:#0f172a;color:#e5edf7}.w{max-width:640px;margin:0 auto;padding:22px 18px 60px}
h1{font-size:22px;margin:8px 0 2px}.sub{color:#8ea6c8;font-size:13px;margin-bottom:18px}
.card{background:#17223a;border-radius:14px;padding:18px;box-shadow:0 6px 24px #0006;margin-bottom:14px}
label{display:block;font-size:13px;color:#9fb2d0;margin:10px 0 4px}
input[type=text],select{width:100%;font-size:16px;color:#e5edf7;background:#0e1830;
border:1px solid #3b5586;border-radius:10px;padding:12px;box-sizing:border-box}
input[type=file]{width:100%;color:#cdd;background:#0e1830;border:1px dashed #3b5586;
border-radius:10px;padding:14px;box-sizing:border-box}
.rad{display:flex;align-items:flex-start;gap:10px;padding:10px;border:1px solid #26365a;
border-radius:10px;margin:6px 0;background:#0e1830}
.rad input{margin-top:3px}.rad .nm{font-size:14px}.rad .ur{color:#8ea6c8;font-size:11px;word-break:break-all}
button{width:100%;padding:15px;font-size:18px;font-weight:700;color:#06240f;background:#41d17a;
border:0;border-radius:12px;margin-top:12px;cursor:pointer}.gh{background:#2b3b5e;color:#dfe9f7;font-size:15px;padding:11px}
.hint{color:#7f93b3;font-size:12px;margin-top:10px;line-height:1.6}
.tag{display:inline-block;background:#22304f;color:#9fd0ff;border-radius:6px;padding:2px 8px;font-size:12px;margin:2px 4px 2px 0}
.qr{display:block;margin:8px auto 4px;width:170px;height:170px;background:#fff;border-radius:12px;padding:8px}
.u{text-align:center;color:#8ea6c8;font-size:12px;word-break:break-all}
a.lk{color:#41d17a;text-decoration:none;font-weight:600}
.ok{color:#41d17a}.err{color:#ff6b6b}
table{width:100%;border-collapse:collapse;font-size:14px}
th,td{padding:9px 6px;border-bottom:1px solid #26365a;text-align:left;vertical-align:top}
th{color:#8ea6c8;font-size:12px;font-weight:600}
.mini{display:inline-block;font-size:13px;padding:6px 10px;margin:2px 4px 2px 0;border-radius:8px;
background:#2b3b5e;color:#dfe9f7;border:0;font-weight:600;text-decoration:none;width:auto;cursor:pointer}
.mini.danger{background:#5e2b3b;color:#ffdfe6}
.badge{display:inline-block;border-radius:6px;padding:1px 7px;font-size:12px;margin-left:6px}
.b-ok{background:#173d27;color:#7fe0a5}.b-off{background:#3d1720;color:#ff9db0}
.b-def{background:#1c3452;color:#8fc7ff}"""


def page(title, body):
    return ("<!doctype html><html lang=zh><head><meta charset=utf-8>"
            "<meta name=viewport content=\"width=device-width,initial-scale=1\">"
            "<title>%s</title><style>%s</style></head><body><div class=w>%s</div></body></html>"
            % (title, CSS, body))


def notice_page(title, msg, ok=True, back="/admin", backtxt="← 返回"):
    cls = "ok" if ok else "err"
    body = ("<h1 class=%s>%s</h1><div class=card><div class=ur style=\"font-size:14px;color:#cbd8ea;"
            "white-space:pre-wrap;word-break:break-all\">%s</div></div><a class=lk href=\"%s\">%s</a>"
            % (cls, html.escape(title), html.escape(msg[:800]), html.escape(back, quote=True), html.escape(backtxt)))
    return page(title, body)


# ---------- 设置向导 ----------

def setup_page(msg="", detect=None, q="", pname=""):
    detect = detect if detect is not None else detect_usb()
    cards = ""
    if detect:
        rows = "".join(
            "<label class=rad><input type=radio name=usb value=\"%s\">"
            "<span><span class=nm>%s</span><br><span class=ur>%s</span></span></label>"
            % (html.escape(u, quote=True), html.escape(n), html.escape(u)) for n, u in detect)
        cards = ("<div class=card><b>① 检测到已连接的 USB 打印机</b>"
                 "<div class=hint>选中即用它的 USB 地址，只填型号即可。</div>" + rows + "</div>")
    quick = "".join("<a class=lk href=\"/setup?q=%s\">%s</a>　"
                    % (urllib.parse.quote(mm), html.escape(label)) for label, mm in QUICK)
    m = ("<div class='hint err'>%s</div>" % html.escape(msg)) if msg else ""
    body = (
        "<h1>🖨 打印机设置向导</h1><div class=sub>输入打印机型号，盒子自动装驱动</div>" + m + cards +
        "<form method=post action=/setup/search>"
        "<input type=hidden name=pname value=\"%s\">"
        "<div class=card><b>② 输入打印机型号</b>"
        "<label>型号（可含品牌，如 联想 M7206W / HP LaserJet 1020）</label>"
        "<input type=text name=model value=\"%s\" placeholder=\"例如：Lenovo M7206W\" autofocus>"
        "<label>连接方式</label>"
        "<select name=conn><option value=usb>USB（本机直连）</option>"
        "<option value=net>网络打印机（IP）</option></select>"
        "<label>网络打印机 IP / 地址（选网络时填，如 192.168.31.50）</label>"
        "<input type=text name=ip placeholder=\"192.168.31.50\">"
        "<button type=submit>搜索驱动 →</button></div></form>"
        "<div class=card><b>常见型号快捷选择</b><div class=hint>%s</div></div>"
        "<div class=card><b>③ 本地库找不到？</b>"
        "<div class=hint>可上传打印机官方的 .ppd 驱动文件直接安装。</div>"
        "<form method=post action=/setup/upload enctype=multipart/form-data>"
        "<input type=file name=ppd accept=\".ppd,.gz\" required>"
        "<label>队列名（可留空自动生成）</label><input type=text name=pname value=\"%s\">"
        "<button class=gh type=submit>上传并安装驱动</button></form></div>"
        "<a class=lk href=\"/admin\">⚙ 打印管理界面</a>"
    ) % (html.escape(pname), html.escape(q), quick, html.escape(pname))
    return page("打印机设置", body)


def _conn_uri(conn, usb, ip):
    if conn == "net" and ip.strip():
        ip = ip.strip()
        return ip if "://" in ip else "socket://%s:9100" % ip
    if usb:
        return usb
    d = detect_usb()
    return d[0][1] if d else None


def search_page(model, conn, ip, usb, pname=""):
    cands = search_ppds(model)
    if not cands:
        pkgs = brand_pkgs(model)
        rc, size, newp = apt_sim(pkgs)
        return online_page(model, pkgs, size, newp,
                           note="本地驱动库没找到 “%s”，可联网按品牌检索驱动型号。" % model)
    uri = _conn_uri(conn, usb, ip)
    conn_txt = uri or "（未检测到 USB 打印机，请先用 USB 连接并重试）"
    rows = ""
    for i, (u, mm) in enumerate(cands):
        ck = "checked" if i == 0 else ""
        rows += ("<label class=rad><input type=radio name=ppd value=\"%s\" %s>"
                 "<span><span class=nm>%s</span><br><span class=ur>%s</span></span></label>"
                 % (html.escape(u, quote=True), ck, html.escape(mm), html.escape(u)))
    qn = pname or (re.sub(r"[^A-Za-z0-9._-]", "", model.split()[-1]) if model.split() else "") or "printer"
    body = (
        "<h1>选择驱动</h1><div class=sub>型号：%s</div>"
        "<div class=card><b>连接：</b><span class=ur>%s</span></div>"
        "<form method=post action=/setup/install>"
        "<input type=hidden name=uri value=\"%s\">"
        "<div class=card><b>匹配到的驱动（选一个）</b>%s</div>"
        "<label>队列名（打印机名称）</label>"
        "<input type=text name=pname value=\"%s\">"
        "<button type=submit>安装驱动并启用</button></form>"
        "<a class=lk href=\"/setup?q=%s\">← 返回重搜</a>　"
        "<a class=lk href=\"/admin\">⚙ 管理</a>"
        "<div class=card style=\"margin-top:14px\"><b>列表里没有想要的？</b>"
        "<div class=hint>可按品牌联网下载官方驱动包后再搜。</div>"
        "<form method=post action=/setup/online>"
        "<input type=hidden name=model value=\"%s\">"
        "<button class=gh type=submit>🌐 联网检索驱动型号</button></form></div>"
    ) % (html.escape(model), html.escape(conn_txt), html.escape(uri or "", quote=True),
         rows, html.escape(qn), urllib.parse.quote(model), html.escape(model))
    return page("选择驱动", body)


def online_page(model, pkgs, size, newpkgs, note=""):
    free = disk_free_mb()
    free_txt = ("%d MB" % free) if free >= 0 else "?"
    warn = "" if (free < 0 or free > 120) else ("<div class='hint err'>磁盘剩余仅 %s，可能装不下，建议先清理。</div>" % free_txt)
    rows = "".join("<span class=tag>%s</span>" % html.escape(p) for p in pkgs)
    body = (
        "<h1>🌐 联网检索驱动</h1><div class=sub>%s</div>"
        "<div class=card><b>联网获取的驱动源（先装包再检索型号）</b><div style=\"margin:8px 0\">%s</div>"
        "<div class=ur>下载约 %s · 磁盘剩余 %s · 实际拉取 %d 个包</div>%s</div>"
        "<form method=post action=/setup/online/install>"
        "<input type=hidden name=model value=\"%s\">"
        "<input type=hidden name=pkgs value=\"%s\">"
        "<button type=submit>联网获取并检索（约 1-3 分钟）</button></form>"
        "<a class=lk href=\"/setup?q=%s\">← 返回</a>"
    ) % (html.escape(note or ("型号：%s" % model)), rows, html.escape(size),
         free_txt, len(newpkgs), warn, html.escape(model),
         html.escape(",".join(pkgs)), urllib.parse.quote(model))
    return page("联网检索驱动", body)


def result_page(ok, msg, pname=""):
    if ok:
        make_qr(URL, QR)
        head = "<h1 class=ok>✅ 打印机已就绪</h1>"
        qr = ("<div class=card><b>📱 手机扫二维码 → 传文件来打印</b>"
              "<img class=qr src=/qr.png><div class=u>%s</div></div>"
              "<form method=post action=/setup/test><input type=hidden name=p value=\"%s\">"
              "<button class=gh type=submit>打印测试页（验证出纸）</button></form>"
              "<a class=lk href=\"/\">→ 进入网页打印</a>　<a class=lk href=\"/admin\">⚙ 管理</a>"
              % (URL, html.escape(pname)))
    else:
        head = "<h1 class=err>❌ 安装失败</h1>"
        qr = "<a class=lk href=\"/setup\">← 返回设置向导</a>"
    body = head + "<div class=card><div class=ur style=\"font-size:14px;color:#cbd8ea;white-space:pre-wrap\">%s</div></div>" % html.escape(msg[:600]) + qr
    return page("打印机设置", body)


# ---------- 管理界面 ----------

def admin_page(msg="", ok=True):
    qs = queues()
    rows = ""
    for q in qs:
        name = q["name"]
        badges = ""
        if q["default"]:
            badges += "<span class='badge b-def'>默认</span>"
        badges += "<span class='badge %s'>%s</span>" % (
            "b-ok" if q["enabled"] else "b-off", "启用" if q["enabled"] else "已禁用")
        if not q["accepting"]:
            badges += "<span class='badge b-off'>暂停</span>"
        if q["is_pdf"]:
            badges += "<span class='badge b-def'>测试虚拟队列</span>"
        act = (
            "<form method=post action=/admin/act style=\"display:inline\">"
            "<input type=hidden name=name value=\"%s\">"
            "<button class=mini name=op value=default>设默认</button>"
            "<button class=mini name=op value=test>测试页</button>"
            "<a class=mini href=\"/admin/del?name=%s\">删除</a>"
            "</form>"
            "<a class=mini href=\"/setup?q=%s&pname=%s\">换驱动</a>"
            % (html.escape(name, quote=True), urllib.parse.quote(name),
               urllib.parse.quote(q["model"] or name), urllib.parse.quote(name)))
        rows += ("<tr><td><b>%s</b>%s<br><span class=ur>%s</span></td>"
                 "<td>%s<br><span class=ur>%s</span></td>"
                 "<td style=\"white-space:nowrap\">%s</td></tr>"
                 % (html.escape(name), badges, html.escape(q["uri"]),
                    html.escape(q["model"] or "—"), html.escape(q["state"]), act))
    if not rows:
        rows = "<tr><td colspan=3>还没有配置打印机 —— <a class=lk href=\"/setup\">去设置向导</a></td></tr>"
    m = ("<div class='hint %s'>%s</div>" % ("ok" if ok else "err", html.escape(msg))) if msg else ""
    body = (
        "<h1>⚙ 打印管理</h1><div class=sub>驱动 / 队列管理 · 本机 %s</div>" % html.escape(IP) + m +
        "<div class=card><b>打印机队列</b><div class=hint>设默认=手机打印走这台；测试页=验证驱动是否出纸。</div>"
        "<table><tr><th>打印机</th><th>驱动 / 型号</th><th>操作</th></tr>%s</table></div>" % rows +
        "<div class=card><b>添加 / 更换打印机</b>"
        "<div class=hint>输入型号自动匹配驱动；本地库没有可联网按品牌下载，或上传 .ppd。</div>"
        "<a class=lk href=\"/setup\"><button class=gh type=submit style=\"width:100%%\">🖨 打开设置向导</button></a>"
        "<a class=lk href=\"/upload\">📂 上传 .ppd 驱动文件安装</a></div>"
        "<div class=card><b>打印页入口</b><div class=u>%s</div>"
        "<a class=lk href=\"/\">→ 网页打印页</a>　<a class=lk href=\"/tv\" target=_blank>电视页</a></div>" % URL
    )
    return page("打印管理", body)


def upload_page():
    d = detect_usb()
    det = ("检测到 USB 打印机：%s" % html.escape(d[0][0])) if d else "未检测到 USB 打印机（可先插好再上传/安装）"
    body = (
        "<h1>\U0001F4C2 上传驱动文件</h1><div class=sub>把打印机驱动 .ppd 传到盒子安装（手机/电脑浏览器）</div>"
        "<div class=card><b>目标连接</b><div class=ur>%s</div></div>"
        "<form method=post action=/setup/upload enctype=multipart/form-data>"
        "<div class=card><label>驱动文件（.ppd / .ppd.gz）</label>"
        "<input type=file name=ppd accept=\".ppd,.gz\" required>"
        "<label>队列名（可留空自动生成）</label><input type=text name=pname>"
        "<button type=submit>上传并安装</button></div></form>"
        "<a class=lk href=\"/admin\">\u2699 返回管理</a>"
    ) % det
    return page("上传驱动", body)


def del_confirm_page(name):
    body = ("<h1 class=err>删除打印机？</h1>"
            "<div class=card>即将删除队列 <b>%s</b>（驱动配置一并移除）。</div>"
            "<form method=post action=/admin/act>"
            "<input type=hidden name=name value=\"%s\">"
            "<button name=op value=delete class=\"mini danger\" style=\"width:100%%;padding:14px;font-size:16px\">确认删除</button>"
            "</form><a class=lk href=\"/admin\">← 取消返回</a>"
            % (html.escape(name), html.escape(name, quote=True)))
    return page("删除打印机", body)


# ---------- 网页打印 ----------

PAGE_PRINT = """<!doctype html><html lang=zh><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1"><title>打印</title>
<style>%s
.cols{text-align:center}
.col{display:block;vertical-align:top;text-align:left;margin:0 auto}
@media(min-width:380px){.col{display:inline-block;width:48%%;margin:0 1%%}}
</style></head><body><div class=w>
<h1>🖨 网页打印</h1><div class=sub>%s</div>
<div class=cols>
 <div class=col>
  <div id=dz class=card style="border:2px dashed #3b5586;text-align:center;font-size:16px;color:#9fd0ff;padding:18px">🖱 把文件拖到这里<br>→ 立即打印</div>
  <div class=card><form method=post action=/print enctype=multipart/form-data>
   <input type=file name=f accept=".pdf,.txt,.ps,.pcl,.png,.jpg,.jpeg,.gif,.bmp,.tif,.tiff,application/pdf,image/*" required>
   <label class=conf style="display:flex;align-items:center;gap:8px;color:#bfe6cf;font-size:15px">
   <input type=checkbox name=conf value=1 checked style="width:18px;height:18px"> 🔒 保密模式（打印后不留记录）</label>
   <button type=submit>打 印</button></form>
   <div class=hint>支持 PDF / 图片 / txt。Word/Excel 先另存为 PDF。<br>
   <a class=lk href="/admin">⚙ 管理</a>　<a class=lk href="/setup">更换打印机</a></div></div>
 </div>
 <div class=col>
  <div class=card style="text-align:center"><b>📱 扫码传文件打印</b>
  <img class=qr src=/qr.png><div class=u>%s</div>
  <form method=post action=/qrprint style="margin-top:10px"><button class=gh type=submit>🖨 打印此二维码（A4 一版 6 张）</button></form></div>
 </div>
</div>
</div>
<script>
var dz=document.getElementById('dz'),form=document.getElementsByTagName('form')[0],
inp=form.querySelector('input[type=file]');
function hl(on){dz.style.background=on?'#1d2c4d':'';}
['dragenter','dragover'].forEach(function(e){document.addEventListener(e,function(ev){ev.preventDefault();hl(true);});});
['dragleave','dragend'].forEach(function(e){document.addEventListener(e,function(ev){hl(false);});});
document.addEventListener('drop',function(ev){ev.preventDefault();hl(false);
 var dt=ev.dataTransfer; if(!dt||!dt.files||!dt.files.length)return;
 var f=dt.files[0];
 if(!/[.](pdf|txt|ps|pcl|png|jpg|jpeg|gif|bmp|tif|tiff)$/i.test(f.name)){dz.textContent='❌ 不支持: '+f.name;return;}
 dz.textContent='⏳ 正在打印 '+f.name+' …';
 try{inp.files=dt.files;}catch(e){}
 form.submit();
});
</script>
</body></html>"""


def qr_sheet(out="/tmp/qrsheet.pdf"):
    """生成 A4 二维码贴纸版 (2x3=6 张, 每张上方标注文字)。"""
    try:
        subprocess.run(["python3", "/root/qrsheet.py", URL, out, "扫码传文件打印"],
                       capture_output=True, timeout=60)
    except Exception:
        pass
    return out if os.path.exists(out) else ""


def print_page(pname):
    make_qr(URL, QR)
    return PAGE_PRINT % (CSS, html.escape(pname) + " · 局域网打印", URL)


TV_PAGE = """<!doctype html><html lang=zh><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<meta http-equiv=refresh content=15><title>打印服务器</title>
<style>
 body{margin:0;background:#0f172a;color:#e5edf7;font-family:"Microsoft YaHei","PingFang SC",sans-serif;text-align:center}
 .hd{font-size:36px;font-weight:700;padding:24px 0 4px}
 .st{font-size:22px;color:#9fd0ff;margin-bottom:6px}
 .box{display:inline-block;vertical-align:top;margin:14px 26px;background:#17223a;border-radius:16px;padding:20px 26px}
 .qr{width:220px;height:220px;background:#fff;border-radius:12px;padding:10px}
 .cap{font-size:20px;font-weight:700;margin:10px 0 4px}
 .url{font-size:14px;color:#8ea6c8;word-break:break-all}
 .ft{font-size:17px;color:#7f93b3;margin-top:20px;line-height:1.7}
 .warn{color:#ffd479}
</style></head><body>
 <div class=hd>\U0001F5A8 打印服务器</div>
 <div class=st>__STATUS__</div>
 <div>__BOXES__</div>
 <div class=ft>手机连同一个 WiFi，扫码即用</div>
</body></html>"""


def tv_page():
    make_qr(URL, QR)
    cur = cur_printer()
    if cur:
        status = "当前打印机：" + html.escape(cur)
        boxes = ('<div class=box><img class=qr src=/qr.png><div class=cap>\U0001F4F1 扫码传文件打印</div>'
                 '<div class=url>%s</div></div>'
                 '<div class=box><img class=qr src=/ippqr.png><div class=cap>\u2795 扫码添加打印机</div>'
                 '<div class=url>%s</div></div>') % (URL, html.escape(printer_addr()))
    else:
        status = "<span class=warn>尚未设置打印机 — 请扫码进入设置</span>"
        boxes = ('<div class=box><img class=qr src=/setupqr.png><div class=cap>\U0001F4F1 扫码设置打印机</div>'
                 '<div class=url>%s/setup</div></div>') % URL.rstrip("/")
    return TV_PAGE.replace("__STATUS__", status).replace("__BOXES__", boxes)


# ---------------------------------------------------------------- HTTP

class H(BaseHTTPRequestHandler):
    server_version = "openhwlab-print"

    def log_message(self, *a):
        pass

    def _s(self, code, ctype, body):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _redirect(self, to):
        self.send_response(302)
        self.send_header("Location", to)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _png(self, path):
        try:
            with open(path, "rb") as f:
                self._s(200, "image/png", f.read())
        except Exception:
            self._s(404, "text/plain", "no qr")

    # ---- GET
    def do_GET(self):
        p = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(p.query)
        g = lambda k, d="": qs.get(k, [d])[0]
        if p.path in ("/", "/index.html"):
            pr = cur_printer()
            if not pr:
                self._redirect("/setup"); return
            self._s(200, "text/html; charset=utf-8", print_page(pr))
        elif p.path == "/setup":
            self._s(200, "text/html; charset=utf-8", setup_page(q=g("q"), pname=g("pname")))
        elif p.path == "/admin":
            self._s(200, "text/html; charset=utf-8", admin_page())
        elif p.path == "/admin/del":
            self._s(200, "text/html; charset=utf-8", del_confirm_page(g("name")))
        elif p.path == "/upload":
            self._s(200, "text/html; charset=utf-8", upload_page())
        elif p.path == "/tv":
            self._s(200, "text/html; charset=utf-8", tv_page())
        elif p.path == "/qr.png":
            self._png(QR)
        elif p.path == "/qrprint":
            self._qrprint()
        elif p.path == "/ippqr.png":
            b = qr_bytes(printer_addr())
            if b:
                self._s(200, "image/png", b)
            else:
                self._s(404, "text/plain", "no printer")
        elif p.path == "/setupqr.png":
            b = qr_bytes(URL.rstrip("/") + "/setup")
            if b:
                self._s(200, "image/png", b)
            else:
                self._s(404, "text/plain", "no qr")
        elif p.path == "/adminqr.png":
            self._png(AQR)
        elif p.path == "/api/search":
            import json
            self._s(200, "application/json",
                    json.dumps([{"uri": u, "make": m} for u, m in search_ppds(g("q"))], ensure_ascii=False))
        elif p.path == "/api/queues":
            import json
            self._s(200, "application/json",
                    json.dumps({"queues": queues(), "current": cur_printer()}, ensure_ascii=False))
        elif p.path == "/api/localfiles":
            import json
            self._s(200, "application/json",
                    json.dumps({"files": local_drivers()}, ensure_ascii=False))
        elif p.path == "/api/ls":
            import json
            self._s(200, "application/json",
                    json.dumps(browse(g("path")), ensure_ascii=False))
        elif p.path == "/api/detect":
            import json
            cur = cur_printer() or ""
            dids = device_ids()
            model = dids[0]["model"] if dids else ""
            self._s(200, "application/json",
                    json.dumps({"printers": detect_usb(), "current": cur, "model": model,
                                "devid": dids, "queues": queues(), "ip": IP, "printurl": URL,
                                "ipp": ("ipp://%s:631/printers/%s" % (IP, cur)) if cur else "",
                                "ipp_s": ("ipp://%s/printers/%s" % (IP, cur)) if cur else ""},
                               ensure_ascii=False))
        elif p.path == "/api/onlinesearch":
            import json
            q = g("q")
            pkgs = brand_pkgs(q)
            rc, size, newp = apt_sim(pkgs)
            if newp:                                   # 联网获取缺失的品牌驱动包
                apt_install(pkgs)
                _ppd_cache["t"] = 0; _ppd_cache["list"] = []
            cands = search_ppds(q)
            self._s(200, "application/json",
                    json.dumps({"ok": True, "model": q, "pkgs": pkgs, "size": size,
                                "count": len(cands),
                                "cands": [{"uri": u, "make": m} for u, m in cands]},
                               ensure_ascii=False))
        else:
            self._s(404, "text/plain", "?")

    # ---- POST
    def do_POST(self):
        p = urllib.parse.urlparse(self.path)
        form = self._form()
        if p.path == "/setup/search":
            model = form.get("model", "").strip()
            conn = form.get("conn", "usb")
            ip = form.get("ip", "")
            usb = form.get("usb", "")
            pname = re.sub(r"[^A-Za-z0-9._-]", "", form.get("pname", "") or "")
            if not model and usb:
                model = usb.split("//")[-1].split("?")[0].replace("/", " ")
            self._s(200, "text/html; charset=utf-8", search_page(model, conn, ip, usb, pname))
        elif p.path == "/setup/install":
            self._install(form)
        elif p.path == "/setup/upload":
            self._upload(form)
        elif p.path == "/setup/test":
            self._test(form)
        elif p.path == "/setup/online":
            model = form.get("model", "").strip()
            pkgs = brand_pkgs(model)
            rc, size, newp = apt_sim(pkgs)
            self._s(200, "text/html; charset=utf-8", online_page(model, pkgs, size, newp))
        elif p.path == "/setup/online/install":
            self._online_install(form)
        elif p.path == "/admin/act":
            self._admin_act(form)
        elif p.path == "/qrprint":
            self._qrprint()
        elif p.path.startswith("/api/"):
            self._api_post(p.path, form)
        elif p.path == "/print":
            self._print(form)
        else:
            self._s(404, "text/plain", "?")

    def _form(self):
        ctype = self.headers.get("Content-Type", "")
        length = int(self.headers.get("Content-Length", "0") or 0)
        if "multipart/form-data" in ctype:
            import cgi
            env = {"REQUEST_METHOD": "POST", "CONTENT_TYPE": ctype, "CONTENT_LENGTH": str(length)}
            fs = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ=env)
            out = {"_fs": fs}
            for k in fs.keys():
                it = fs[k]
                if getattr(it, "filename", None):
                    out[k] = it
                elif isinstance(it, list):
                    out[k] = it[0].value if it else ""
                else:
                    out[k] = it.value
            return out
        raw = self.rfile.read(length).decode("utf-8", "ignore") if length else ""
        d = {k: v[0] for k, v in urllib.parse.parse_qs(raw).items()}
        d["_raw"] = raw
        return d

    def _install(self, form):
        ppd = form.get("ppd", "")
        uri = form.get("uri", "")
        pname = re.sub(r"[^A-Za-z0-9._-]", "", form.get("pname", "") or "")
        ok, msg = install_driver(ppd, uri, pname)
        self._s(200, "text/html; charset=utf-8", result_page(ok, msg, pname))

    def _upload(self, form):
        item = form.get("ppd")
        if item is None or not getattr(item, "filename", None):
            self._s(200, "text/html; charset=utf-8", result_page(False, "没有选择 .ppd 文件")); return
        pname = re.sub(r"[^A-Za-z0-9._-]", "", form.get("pname", "") or "") or ("pr_" + uuid.uuid4().hex[:6])
        path = os.path.join(TMP, "drv_" + uuid.uuid4().hex + ".ppd")
        with open(path, "wb") as out:
            while True:
                c = item.file.read(65536)
                if not c:
                    break
                out.write(c)
        with open(path, "rb") as f:
            magic = f.read(2)
        if path.endswith(".gz") or magic == b"\x1f\x8b":
            run(["gunzip", "-f", path], 30)
            path = path[:-3]
        d = detect_usb()
        uri = d[0][1] if d else ""
        if not uri:
            self._s(200, "text/html; charset=utf-8",
                    result_page(False, "未检测到 USB 打印机，无法确定连接地址")); return
        rc, out = run(["lpadmin", "-p", pname, "-E", "-v", uri, "-P", path], 90)
        if rc != 0:
            self._s(200, "text/html; charset=utf-8", result_page(False, "安装失败: " + out)); return
        run(["lpadmin", "-d", pname], 20)
        run(["cupsenable", pname], 20)
        run(["cupsaccept", pname], 20)
        save_printer(pname)
        self._s(200, "text/html; charset=utf-8",
                result_page(True, "已用上传的驱动建立打印机 “%s”：%s" % (pname, uri), pname))

    def _online_install(self, form):
        model = form.get("model", "")
        pkgs = [x for x in (form.get("pkgs", "") or "").split(",") if x]
        if not pkgs:
            self._s(200, "text/html; charset=utf-8", result_page(False, "没有要安装的驱动包")); return
        if 0 <= disk_free_mb() < 60:
            self._s(200, "text/html; charset=utf-8",
                    result_page(False, "磁盘空间不足(<60MB)，请先清理再联网安装")); return
        rc, out = apt_install(pkgs)
        _ppd_cache["t"] = 0; _ppd_cache["list"] = []
        if rc != 0:
            self._s(200, "text/html; charset=utf-8",
                    result_page(False, "驱动下载/安装失败：\n" + out[-500:])); return
        cands = search_ppds(model)
        if not cands:
            self._s(200, "text/html; charset=utf-8",
                    result_page(False, "驱动已装，但仍未匹配到 “%s”，请换写法或上传 .ppd。\n已装：%s"
                                % (model, ", ".join(pkgs)))); return
        self._s(200, "text/html; charset=utf-8", search_page(model, "usb", "", ""))

    def _test(self, form):
        name = form.get("p", "") or cur_printer() or ""
        ok, msg = test_print(name)
        self._s(200, "text/html; charset=utf-8", result_page(ok, msg, name))

    def _admin_act(self, form):
        name = re.sub(r"[^A-Za-z0-9._-]", "", form.get("name", "") or "")
        op = form.get("op", "")
        if not name:
            self._s(200, "text/html; charset=utf-8", notice_page("操作失败", "缺少打印机名", False)); return
        if op == "default":
            ok, msg = set_default(name)
            self._s(200, "text/html; charset=utf-8",
                    notice_page("已设为默认打印机" if ok else "设置失败", "%s\n%s" % (name, msg), ok))
        elif op == "delete":
            ok, msg = delete_printer(name)
            self._s(200, "text/html; charset=utf-8",
                    notice_page("已删除打印机" if ok else "删除失败", "%s\n%s" % (name, msg), ok))
        elif op == "test":
            ok, msg = test_print(name)
            self._s(200, "text/html; charset=utf-8",
                    notice_page("测试页已发出 ✓" if ok else "测试页失败", msg, ok))
        else:
            self._s(200, "text/html; charset=utf-8", notice_page("未知操作", op, False))

    def _api_post(self, path, form):
        import json
        def out(ok, msg, extra=None):
            d = {"ok": bool(ok), "msg": msg}
            if extra:
                d.update(extra)
            self._s(200, "application/json", json.dumps(d, ensure_ascii=False))
        if path == "/api/install":
            ok, msg = install_driver(form.get("ppd", ""), form.get("uri", ""), form.get("pname", ""))
            out(ok, msg, {"printer": cur_printer()})
        elif path == "/api/test":
            ok, msg = test_print(form.get("name", "") or cur_printer() or "")
            out(ok, msg)
        elif path == "/api/setdefault":
            ok, msg = set_default(form.get("name", ""))
            out(ok, msg)
        elif path == "/api/installfile":
            ok, msg = install_file(form.get("path", ""), form.get("uri", ""), form.get("pname", ""))
            out(ok, msg, {"printer": cur_printer()})
        elif path == "/api/delete":
            ok, msg = delete_printer(form.get("name", ""))
            out(ok, msg, {"printer": cur_printer()})
        elif path == "/api/online":
            model = form.get("model", "")
            pkgs = brand_pkgs(model)
            rc, size, newp = apt_sim(pkgs)
            out(True, "", {"pkgs": pkgs, "size": size, "count": len(newp)})
        elif path == "/api/online/install":
            pkgs = [x for x in (form.get("pkgs", "") or "").split(",") if x]
            model = form.get("model", "")
            if not pkgs:
                out(False, "没有要安装的驱动包"); return
            if 0 <= disk_free_mb() < 60:
                out(False, "磁盘空间不足(<60MB)"); return
            rc, o = apt_install(pkgs)
            _ppd_cache["t"] = 0; _ppd_cache["list"] = []
            out(rc == 0, (o[-400:] if rc != 0 else "驱动已安装"),
                {"cands": [{"uri": u, "make": m} for u, m in search_ppds(model)]})
        else:
            out(False, "未知接口")

    def _qrprint(self):
        pr = cur_printer() or ""
        if not pr:
            self._s(200, "text/html; charset=utf-8", result_page(False, "尚未设置打印机")); return
        sheet = qr_sheet()
        if not sheet:
            self._s(200, "text/html; charset=utf-8", result_page(False, "生成二维码版式失败")); return
        rc, out = run(["lp", "-d", pr, "-o", "media=A4", sheet], 120)
        ok = (rc == 0 and "request id" in out)
        self._s(200, "text/html; charset=utf-8",
                result_page(ok, ("已发送二维码打印任务 ✓（A4 一版 6 张）\n" if ok else "打印失败: ") + out, pr))

    def _print(self, form):
        conf = "conf" in form
        item = form.get("f")
        pname = cur_printer() or "PDF"
        if item is None or not getattr(item, "filename", None):
            self._s(200, "text/html; charset=utf-8", result_page(False, "没有选择文件", pname)); return
        ext = os.path.splitext(os.path.basename(item.filename))[1].lower()
        path = os.path.join(TMP, uuid.uuid4().hex + ext)
        size = 0
        try:
            with open(path, "wb") as out:
                while True:
                    c = item.file.read(65536)
                    if not c:
                        break
                    size += len(c)
                    if size > 80 * 1024 * 1024:
                        raise Exception("文件过大(>80MB)")
                    out.write(c)
        except Exception as e:
            self._s(200, "text/html; charset=utf-8", result_page(False, "保存失败: %s" % e, pname)); return
        ok, msg = do_print(path, pname)
        try:
            sz = os.path.getsize(path)
            with open(path, "r+b") as f:
                f.seek(0); f.write(b"\0" * sz)
            os.remove(path)
        except Exception:
            pass
        if conf:
            time.sleep(1.0)
            wipe()
        self._s(200, "text/html; charset=utf-8", result_page(ok, msg, pname))


if __name__ == "__main__":
    os.makedirs(TMP, exist_ok=True)
    make_qr(URL, QR)
    make_qr(AURL, AQR)
    srv = HTTPServer((HOST, PORT), H)
    sys.stderr = open("/dev/null", "w")
    srv.serve_forever()
