#!/bin/bash
# 盒子新 rootfs(Ubuntu 20.04) 启动脚本: DNS(TCP)桥 + HTTP 代理 + 打印服务
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
D=/root
echo "=== startbox $(date) ==="

sleep 4

# DNS-over-TCP 桥 (盒子 UDP 被封, 一切走 TCP)
pkill -f "dnstcp[.]py" 2>/dev/null
pkill -f "httpproxy[.]py" 2>/dev/null
sleep 1
nohup /usr/bin/python3 $D/dnstcp.py   >$D/dnstcp.log   2>&1 &
nohup /usr/bin/python3 $D/httpproxy.py >$D/httpproxy.log 2>&1 &
sleep 3
echo "dnstcp: $(tail -1 $D/dnstcp.log 2>/dev/null)"
echo "proxy: $(tail -1 $D/httpproxy.log 2>/dev/null)"

echo "=== startbox done ==="

# ---- 打印服务器: dbus + CUPS + avahi(AirPrint) ----
[ -s /etc/machine-id ] || dbus-uuidgen --ensure 2>/dev/null
mkdir -p /run/cups /run/dbus /run/avahi-daemon /var/run/avahi-daemon
pgrep dbus-daemon >/dev/null 2>&1 || dbus-daemon --system --fork
pgrep cupsd       >/dev/null 2>&1 || /usr/sbin/cupsd
pgrep -x avahi-daemon >/dev/null 2>&1 || /usr/sbin/avahi-daemon -D --no-chroot --no-drop-root
sleep 1
echo "cupsd: $(pgrep -x cupsd | head -1)  avahi: $(pgrep -x avahi-daemon | head -1)"
# 网页打印门户
pgrep -f "[p]rintd.py" >/dev/null 2>&1 || ( cd /root && nohup python3 /root/printd.py >/var/log/printd.log 2>&1 & )
sleep 1
echo "printd: $(pgrep -f '[p]rintd.py' | head -1)"
