package com.laifu.printsrv;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

/** 打印二维码页: 二维码 + 打印文件上传页地址 + 打印机地址(可复制)。 */
public class QrActivity extends Activity {
    private String ipp = "";
    private TextView uploadTv, addrTv;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout L = new LinearLayout(this);
        L.setOrientation(LinearLayout.VERTICAL);
        L.setBackgroundColor(0xFF0F172A);
        L.setGravity(Gravity.CENTER);
        L.setPadding(40, 30, 40, 30);

        TextView t = new TextView(this);
        t.setText("\uD83D\uDCF1 扫码传文件打印");
        t.setTextSize(26); t.setTextColor(0xFFFFFFFF); t.setGravity(Gravity.CENTER);
        L.addView(t);

        final ImageView iv = new ImageView(this);
        L.addView(iv);

        uploadTv = new TextView(this);
        uploadTv.setTextSize(19); uploadTv.setTextColor(0xFF9FD0FF);
        uploadTv.setGravity(Gravity.CENTER); uploadTv.setPadding(0, 8, 0, 4);
        L.addView(uploadTv);

        addrTv = new TextView(this);
        addrTv.setTextSize(17); addrTv.setTextColor(0xFFBFE6CF);
        addrTv.setGravity(Gravity.CENTER); addrTv.setPadding(0, 6, 0, 8);
        L.addView(addrTv);

        Button copy = new Button(this);
        copy.setText("\uD83D\uDCCB 复制打印机地址");
        copy.setTextSize(18);
        copy.setLayoutParams(new LinearLayout.LayoutParams(620, 64));
        copy.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { copyAddr(); } });
        L.addView(copy);

        TextView h = new TextView(this);
        h.setText("手机扫二维码传文件打印 · 按 OK 复制打印机地址 · 返回键退出");
        h.setTextSize(14); h.setTextColor(0xFF7F93B3); h.setGravity(Gravity.CENTER);
        h.setPadding(0, 14, 0, 0); L.addView(h);

        setContentView(L, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        new Thread(new Runnable() { public void run() {
            final byte[] d = Http.getBytes("/qr.png");
            final String det = Http.get("/api/detect");
            runOnUiThread(new Runnable() { public void run() {
                if (d != null) {
                    Bitmap bm = BitmapFactory.decodeByteArray(d, 0, d.length);
                    if (bm != null) {
                        int w = 460; int hh = w * bm.getHeight() / bm.getWidth();
                        iv.setImageBitmap(Bitmap.createScaledBitmap(bm, w, hh, false));
                    }
                }
                try {
                    JSONObject o = new JSONObject(det);
                    String pu = o.optString("printurl", "");
                    ipp = o.optString("ipp", "");
                    uploadTv.setText("打印文件上传页：" + (pu.length() > 0 ? pu : "<盒子IP>:8080/"));
                    addrTv.setText("打印机地址：\n" + (ipp.length() > 0 ? ipp : "（未设置打印机）"));
                } catch (Exception e) {
                    uploadTv.setText("打印文件上传页：<盒子IP>:8080/");
                }
            } });
        } }).start();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int kc = e.getKeyCode();
            if (kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER
                    || kc == KeyEvent.KEYCODE_NUMPAD_ENTER) { copyAddr(); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    private void copyAddr() {
        if (ipp.length() == 0) { Toast.makeText(this, "没有打印机地址可复制", Toast.LENGTH_LONG).show(); return; }
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("printer", ipp));
            Toast.makeText(this, "已复制打印机地址：\n" + ipp, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "复制失败", Toast.LENGTH_SHORT).show();
        }
    }
}
