package com.laifu.printsrv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

/** 驱动与打印机管理: 队列列表 + 操作(设默认/测试页/换驱动/删除) + 添加/换驱动 + U盘安装。 */
public class ManagerActivity extends Activity {
    private ArrayAdapter<String> ad;
    private ArrayList<String> labels = new ArrayList<String>();
    private ArrayList<String> qnames = new ArrayList<String>();   // 队列名(特殊项为空)
    private ArrayList<Integer> kinds = new ArrayList<Integer>();   // 0=队列 1=添加 2=U盘 3=返回
    private int sel = 0;
    private String lastKey = "";
    private ListView list;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout L = new LinearLayout(this);
        L.setOrientation(LinearLayout.VERTICAL);
        L.setBackgroundColor(0xFF0F172A);
        L.setPadding(44, 30, 44, 30);

        TextView t = new TextView(this); t.setText("\u2699 驱动与打印机管理");
        t.setTextSize(26); t.setTextColor(0xFFFFFFFF); L.addView(t);
        TextView hint = new TextView(this);
        hint.setText("遥控器：↑↓ 选择 · OK 操作 · 返回键退出");
        hint.setTextSize(13); hint.setTextColor(0xFF7F93B3); hint.setPadding(0, 6, 0, 6);
        L.addView(hint);

        list = new ListView(this); list.setBackgroundColor(0xFF0E1830);
        ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels);
        list.setAdapter(ad);
        list.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) { activate(pos); } });
        L.addView(list);

        setContentView(L, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        list.requestFocus();
        load();
    }

    @Override protected void onResume() { super.onResume(); lastKey = ""; load(); }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int kc = e.getKeyCode();
            if (kc == KeyEvent.KEYCODE_DPAD_DOWN) { move(1); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_UP) { move(-1); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER
                    || kc == KeyEvent.KEYCODE_NUMPAD_ENTER) { activate(sel); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    private void move(int d) {
        if (labels.isEmpty()) return;
        sel += d;
        if (sel < 0) sel = 0;
        if (sel > labels.size() - 1) sel = labels.size() - 1;
        list.setSelection(sel);
    }

    private void load() {
        new Thread(new Runnable() { public void run() {
            final String s = Http.get("/api/queues");
            runOnUiThread(new Runnable() { public void run() {
                ArrayList<String> lv = new ArrayList<String>(), nv = new ArrayList<String>();
                ArrayList<Integer> kv = new ArrayList<Integer>();
                try {
                    JSONObject o = new JSONObject(s);
                    JSONArray qs = o.optJSONArray("queues");
                    if (qs != null) for (int i = 0; i < qs.length(); i++) {
                        JSONObject q = qs.getJSONObject(i);
                        lv.add(q.optString("name")
                                + (q.optBoolean("default") ? "  \u2B50默认" : "")
                                + (q.optBoolean("is_pdf") ? "  [测试]" : "")
                                + "\n" + q.optString("model"));
                        nv.add(q.optString("name")); kv.add(0);
                    }
                    if (lv.isEmpty()) lv.add("(还没有打印机，选下面添加)");
                    if (lv.size() == 1 && nv.isEmpty()) { nv.add(""); kv.add(-1); }
                } catch (Exception e) { lv.add("服务未就绪"); nv.add(""); kv.add(-1); }
                lv.add("\uFF0B 添加/更换驱动（按型号自动搜）"); nv.add(""); kv.add(1);
                lv.add("\uD83D\uDCC2 U盘/本地安装驱动"); nv.add(""); kv.add(2);
                lv.add("\u2B05 返回"); nv.add(""); kv.add(3);
                String key = s + ":" + nv.size();
                if (key.equals(lastKey)) return;
                lastKey = key;
                labels.clear(); labels.addAll(lv);
                qnames.clear(); qnames.addAll(nv);
                kinds.clear(); kinds.addAll(kv);
                ad.notifyDataSetChanged();
                if (sel > lv.size() - 1) sel = 0;
                list.setSelection(sel);
            } });
        } }).start();
    }

    private void activate(int pos) {
        Log.i("psrv", "mgr activate " + pos);
        if (pos < 0 || pos >= kinds.size()) return;
        int k = kinds.get(pos);
        if (k == 1) { startActivity(new Intent(this, SetupActivity.class)); return; }
        if (k == 2) { startActivity(new Intent(this, FileInstallActivity.class)); return; }
        if (k == 3) { finish(); return; }
        if (k == 0 && qnames.get(pos).length() > 0) options(qnames.get(pos));
    }

    private void options(final String name) {
        final String[] items = { "设为默认", "打印测试页", "更换驱动", "删除", "取消" };
        new AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    if (w == 0) act("setdefault", name, "已设为默认");
                    else if (w == 1) act("test", name, "已发送测试页");
                    else if (w == 2) {
                        Intent i = new Intent(ManagerActivity.this, SetupActivity.class);
                        i.putExtra("pname", name); startActivity(i);
                    } else if (w == 3) confirmDelete(name);
                }
            })
            .show();
    }

    private void confirmDelete(final String name) {
        new AlertDialog.Builder(this)
            .setTitle("删除打印机")
            .setMessage("确定删除队列 " + name + " ？")
            .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { act("delete", name, "已删除"); } })
            .setNegativeButton("取消", null)
            .show();
    }

    private void act(final String api, final String name, final String okMsg) {
        new Thread(new Runnable() { public void run() {
            final String s = Http.post("/api/" + api, "name=" + Http.enc(name));
            runOnUiThread(new Runnable() { public void run() {
                String m = okMsg;
                try { JSONObject o = new JSONObject(s);
                    if (!o.optBoolean("ok")) m = "失败: " + o.optString("msg"); }
                catch (Exception e) { m = "失败：服务无响应"; }
                Toast.makeText(ManagerActivity.this, m, Toast.LENGTH_LONG).show();
                lastKey = ""; load();
            } });
        } }).start();
    }
}
