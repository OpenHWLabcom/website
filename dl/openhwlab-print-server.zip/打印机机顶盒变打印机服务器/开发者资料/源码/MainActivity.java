package com.laifu.printsrv;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

/** 打印服务器主页(HOME): 左侧内嵌网页打印界面(拖文件/选文件打印 + 二维码), 右侧菜单。 */
public class MainActivity extends Activity {
    private TextView status;
    private WebView web;
    private ArrayAdapter<String> ad;
    private ArrayList<String> labels = new ArrayList<String>();
    private int sel = 0;
    private String ipp = "";
    private static final String HOME = "http://127.0.0.1:8080/";
    private ListView list;
    private ValueCallback<Uri> mUpl;
    private String lastCur = null;
    private static final int REQ_FILE = 1001;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0F172A);
        root.setPadding(36, 24, 36, 24);

        TextView t = new TextView(this); t.setText("\uD83D\uDDA8  打印服务器 · 智能硬件开放实验室");
        t.setTextSize(30); t.setTextColor(0xFFFFFFFF); root.addView(t);
        status = new TextView(this); status.setTextSize(18); status.setTextColor(0xFF9FD0FF);
        status.setPadding(0, 4, 0, 10); root.addView(status);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        web.setBackgroundColor(0xFF0F172A);
        web.setWebChromeClient(new WebChromeClient() {
            public void openFileChooser(ValueCallback<Uri> cb) { mUpl = cb; pick(); }
            public void openFileChooser(ValueCallback<Uri> cb, String type) { mUpl = cb; pick(); }
            public void openFileChooser(ValueCallback<Uri> cb, String type, String capture) { mUpl = cb; pick(); }
        });
        web.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.5f));
        row.addView(web);

        labels.add("\uD83D\uDD27 驱动与打印机管理");
        labels.add("\uD83D\uDD8C 打印测试页");
        labels.add("\uD83D\uDCCB 复制打印机地址");
        labels.add("\uD83C\uDFE0 回到首页");
        list = new ListView(this); list.setBackgroundColor(0xFF0E1830);
        ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels);
        list.setAdapter(ad);
        list.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) { activate(pos); } });
        row.addView(list);

        root.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView h = new TextView(this);
        h.setText("拖文件到左侧即打印（电脑浏览器同样支持拖拽/扫码）　·　遥控器 ↑↓ 选右侧菜单 · OK 确认");
        h.setTextSize(14); h.setTextColor(0xFF7F93B3); h.setPadding(0, 10, 0, 0); root.addView(h);

        setContentView(root, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.loadUrl(HOME);
        list.requestFocus();
        load();
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*");
        try { startActivityForResult(Intent.createChooser(i, "选择文件"), REQ_FILE); }
        catch (Exception e) { if (mUpl != null) { mUpl.onReceiveValue(null); mUpl = null; } }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            Uri u = (res == RESULT_OK && data != null) ? data.getData() : null;
            if (mUpl != null) { mUpl.onReceiveValue(u); mUpl = null; }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override protected void onResume() { super.onResume(); load(); }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int kc = e.getKeyCode();
            if (kc == KeyEvent.KEYCODE_DPAD_DOWN) { move(1); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_UP) { move(-1); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER
                    || kc == KeyEvent.KEYCODE_NUMPAD_ENTER) { activate(sel); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    private void move(int d) {
        sel += d;
        if (sel < 0) sel = 0;
        if (sel > labels.size() - 1) sel = labels.size() - 1;
        list.setSelection(sel);
    }

    private void activate(int pos) {
        Log.i("psrv", "home activate " + pos);
        if (pos == 0) startActivity(new Intent(this, ManagerActivity.class));
        else if (pos == 1) runTest();
        else if (pos == 2) copyAddr();
        else if (pos == 3) web.loadUrl(HOME);   // 任何情况都回首页
    }

    private void load() {
        new Thread(new Runnable() { public void run() {
            final String s = Http.get("/api/detect");
            runOnUiThread(new Runnable() { public void run() {
                try {
                    JSONObject o = new JSONObject(s);
                    String cur = o.optString("current", "");
                    String drv = "";
                    JSONArray qs = o.optJSONArray("queues");
                    if (qs != null) for (int i = 0; i < qs.length(); i++) {
                        JSONObject qj = qs.getJSONObject(i);
                        if (qj.optString("name").equals(cur)) drv = qj.optString("model");
                    }
                    ipp = o.optString("ipp", "");
                    if (lastCur == null) lastCur = cur;
                    else if (!lastCur.equals(cur)) { lastCur = cur; web.reload(); }
                    if (cur.length() == 0)
                        status.setText("尚未设置打印机 — 请进「驱动与打印机管理」");
                    else
                        status.setText("当前打印机：" + cur + (drv.length() > 0 ? "　(" + drv + ")" : "")
                                + "　·　打印机地址：" + ipp);
                } catch (Exception e) { status.setText("服务未就绪，请稍候…"); }
            } });
        } }).start();
    }

    private void copyAddr() {
        if (ipp.length() == 0) { Toast.makeText(this, "还没装打印机，没有地址可复制", Toast.LENGTH_LONG).show(); return; }
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("printer", ipp));
            Toast.makeText(this, "已复制打印机地址：\n" + ipp, Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "复制失败", Toast.LENGTH_SHORT).show(); }
    }

    private void runTest() {
        Toast.makeText(this, "正在发送测试页…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() { public void run() {
            final String s = Http.post("/api/test", "");
            runOnUiThread(new Runnable() { public void run() {
                String m = "已发送测试页，请看出纸";
                try { JSONObject o = new JSONObject(s); if (!o.optBoolean("ok")) m = "失败: " + o.optString("msg"); }
                catch (Exception e) { m = "失败：服务无响应"; }
                Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show();
            } });
        } }).start();
    }
}
