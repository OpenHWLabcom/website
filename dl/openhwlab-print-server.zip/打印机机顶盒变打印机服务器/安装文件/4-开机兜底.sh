#!/system/bin/sh
# 开机: 等系统就绪 -> 挂 new rootfs(linux20 = Ubuntu 20.04) -> chroot 起 DNS桥/代理/OpenClaw -> 桌面 httpd
# (桌面由系统 HOME 应用 com.laifu.printsrv 全屏显示 —— 专用打印服务器)
exec > /data/bootlinux.log 2>&1
echo "=== autostart $(date) ==="
[ -e /data/no_autostart ] && { echo "no_autostart, skip"; exit 0; }

# 性能调优 (CPU 性能模式 + zram 交换 + 关动画 + 精简后台)
sh /data/tune.sh &

# 等系统启动完成 (否则 /storage/emulated/0 未就绪)
i=0
while [ $i -lt 60 ]; do
  [ "$(getprop sys.boot_completed)" = "1" ] && break
  sleep 2
  i=$((i+1))
done
sleep 5

# 动态磁盘 swap: 把 /sdcard 空余并成内存溢出层 (存储当内存)
sh /data/swapdisk.sh &

# 挂载 Linux 镜像 (linux20 = Ubuntu 20.04 + Node22 + OpenClaw)
IMG=/storage/emulated/0/linux20.img
busybox losetup /dev/block/loop0 "$IMG" 2>/dev/null
mkdir -p /data/linux
busybox mount -t ext4 /dev/block/loop0 /data/linux 2>/dev/null
mkdir -p /data/linux/proc /data/linux/dev/pts
busybox mount -t proc proc /data/linux/proc 2>/dev/null
busybox mount -o bind /dev /data/linux/dev 2>/dev/null
busybox mount -t devpts devpts /data/linux/dev/pts 2>/dev/null
busybox mkdir -p /data/linux/sdcard
busybox mount -o bind /storage/emulated/0 /data/linux/sdcard 2>/dev/null
busybox mkdir -p /data/linux/sys
busybox mount -o bind /sys /data/linux/sys 2>/dev/null
echo "mounted=$(busybox mount | busybox grep -c '/data/linux ')"

# chroot 内: DNS桥 + 代理 + OpenClaw (startbox.sh 内部各自 nohup)
busybox chroot /data/linux /usr/bin/env PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin HOME=/root /bin/bash /root/startbox.sh >/data/startbox.log 2>&1 </dev/null &
sleep 5

# 局域网互传 (手机<->盒子): 手机浏览器开 http://<盒子IP>:8890/
# [来福 2026-10-05] 纯打印场景, 已停用文件互传(transfer:8890)
# busybox chroot /data/linux /usr/bin/nohup /usr/bin/python3 /root/transfer.py >/data/transfer.log 2>&1 &

# 安卓侧 DNS 指向本地桥
setprop net.dns1 127.0.0.1
setprop net.dns2 127.0.0.1
ndc resolver setifdns eth0 "" 127.0.0.1 2>/dev/null
ndc resolver setdefaultif eth0 2>/dev/null

# 桌面 HTTP 服务 (静态页 + CGI 启动器)
busybox httpd -p 127.0.0.1:8899 -h /data/www
sleep 1
echo "httpd: $(busybox netstat -tlnp 2>/dev/null | busybox grep -c 8899)"
/system/bin/ping -c1 -W3 www.baidu.com >/dev/null 2>&1 && echo "DNS ok" || echo "DNS fail"

# 恢复显示设置 (用户自定)
if [ -f /data/dispset ]; then
  DD=$(busybox grep "^density=" /data/dispset | busybox sed "s/^density=//")
  [ -n "$DD" ] && [ "$DD" != "160" ] && wm density "$DD"
  Z=$(busybox grep "^deskzoom=" /data/dispset | busybox sed "s/^deskzoom=//")
  UZ=$(busybox grep "^webzoom=" /data/dispset | busybox sed "s/^webzoom=//")
  UM=$(busybox grep "^uaimode=" /data/dispset | busybox sed "s/^uaimode=//")
  echo "display: density=$DD deskzoom=$Z webzoom=$UZ"
fi

# 打开桌面
am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null 2>&1

# adb over TCP (远程救急通道; 5555; 仅授权本机 adbkey, adb_keys 里只放自己的公钥)
setprop service.adb.tcp.port 5555
if ! ps | busybox grep -q "[s]bin/adbd"; then
  /sbin/adbd &
fi

echo "=== done ==="
[ -x /data/oc_ime.sh ] && /data/oc_ime.sh

[ -f /data/ota-install.sh ] && (busybox setsid sh /data/ota-install.sh >/dev/null 2>&1 &)
