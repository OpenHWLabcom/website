# 说明 README —— 机顶盒变「下载机 + NAS」(开发者)

## 组成

```
[手机/电脑浏览器] --:8080--> nasd.py  (管理面板: 加任务/进度/暂停继续删/二维码)
                                 |
                                 v
                          aria2  (下载引擎, RPC :6800)  -->  USB 硬盘 / 内部存储
[电脑/手机]  --SMB:445-->  smbd   (家庭网盘 \盒z\nas)
[电视]       --DLNA---->   minidlna (可选, 播放媒体)
[盒子屏幕]   桌面.apk (全屏 WebView) --> http://127.0.0.1:8080/   (开机即进)
```

## 文件

| 文件 | 说明 |
|---|---|
| `下载服务.py` (nasd.py) | 管理面板 + 下载/磁盘状态 + 二维码 + 任务控制；托管 AriaNg |
| `aria2.conf` | aria2 配置（dir / RPC / BT） |
| `smb.conf` | Samba 共享配置 |
| `3-开机自启.sh` (nasstart.sh) | 子系统启动：拉起 aria2/smbd/nmbd/nasd |
| `4-开机兜底.sh` | 盒子侧启动（挂子系统 + 调 nasstart） |
| `桌面.apk` | 全屏网页壳，开机显示面板 |
| `源码/` | 上述脚本 + 桌面 App 源码(Android/kiosk) + 构建脚本 |

## 接口（nasd.py）

- `GET /`  管理面板
- `GET /api/state`  状态 JSON（disk/global/active/waiting/stopped）
- `POST /api/add` `{url}`  加任务
- `POST /api/pause|resume|remove` `{gid}`  任务控制
- `GET /ariang/`  托管 AriaNg 静态页

## 环境变量

`NASD_PORT`(8080) · `ARIA2_RPC`(http://127.0.0.1:6800/jsonrpc) · `ARIA2_SECRET` ·
`NAS_ROOT`(网盘根) · `NAS_DL`(下载目录) · `ARIANG_DIR`(/root/ariang) · `BOX_IP`(可选)

## 桌面 App（源码/Android）

`com.openhardwarelab.desktop`：全屏 WebView → `http://127.0.0.1:8080/`，带 HOME 类别（开机即进）。
构建：`bash build-nas.sh`（需 jdk8/aapt/d8/android.jar 组成的工具链）。
