#!/bin/sh
# OpenHW Lab · 下载机 + NAS 启动脚本（在 Linux 子系统/chroot 里跑，幂等）
# 放到子系统 /root/nasstart.sh；由盒子开机脚本 chroot 调用。
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root

# 目录（按需改：用 USB 盘时换成 /media/usb/nas）
mkdir -p /mnt/sdcard/nas/downloads
mkdir -p /var/log/samba /var/lib/samba/private /var/run/samba /var/lib/samba/usershares
[ -f /root/aria2.session ] || touch /root/aria2.session

# 下载引擎
pgrep -f "[a]ria2c" >/dev/null || aria2c --conf-path=/root/aria2.conf -D
# 网盘
pgrep -x smbd >/dev/null || smbd -D -s /root/smb.conf
pgrep -x nmbd >/dev/null || nmbd -D -s /root/smb.conf
# 管理面板
pgrep -f "[n]asd.py" >/dev/null || \
  NAS_ROOT=/mnt/sdcard/nas NAS_DL=/mnt/sdcard/nas/downloads ARIANG_DIR=/root/ariang \
  nohup python3 /root/nasd.py >>/root/nasd.log 2>&1 &

sleep 1
echo "nasstart done: aria2=$(pgrep -c -f '[a]ria2c') smbd=$(pgrep -c -x smbd) nasd=$(pgrep -c -f '[n]asd.py')"
