#!/bin/bash
# ============================================================
#  OpenHW Lab · 机顶盒变「下载机 + NAS」—— 一键安装（在电脑上跑）
#  用法：  ./一键安装.sh <盒子IP>
#  前提：  盒子已 root、已开 ADB、电脑装了 adb、同一局域网；
#          盒子已建好 Linux 子系统 /data/linux（见教程）。
#  作用：  推下载/NAS 服务进子系统、装依赖(可选)、提示自启配置。
#          可重复执行（幂等）。
# ============================================================
set -e
IP="$1"
[ -z "$IP" ] && { echo "用法: $0 <盒子IP>"; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"
R=/data/linux
CH="busybox chroot $R /usr/bin/env PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin HOME=/root /bin/bash -c"
say(){ echo -e "\n\033[1;36m==> $*\033[0m"; }

say "连接盒子 $IP:5555"
adb connect "${IP}:5555"; adb wait-for-device

say "检查 Linux 子系统"
adb shell "[ -d $R/root ] || { echo '未找到 $R （先按教程搭好 Linux 子系统）'; exit 1; }"

say "推服务脚本与配置到子系统（chroot /root）"
adb push "$HERE/下载服务.py" $R/root/nasd.py
adb push "$HERE/aria2.conf"  $R/root/aria2.conf
adb push "$HERE/smb.conf"    $R/root/smb.conf

say "装依赖（首次，走 http 镜像 apt）"
echo "  在盒子子系统里执行（或取消下面注释自动装）："
echo "    apt-get update && apt-get install -y aria2 samba minidlna qrencode"
echo "#  adb shell \"$CH 'apt-get update && apt-get install -y aria2 samba minidlna qrencode'\""

say "挂载 USB 硬盘（若有）并建目录"
echo "  在子系统里："
echo "    mkdir -p /media/usb /sdcard/nas/downloads"
echo "    mount --bind /proc/1/root/mnt/sda/sda1 /media/usb   # 按实际盘符改"
echo "    ln -sf /media/usb/nas /sdcard/nas                   # 或直接用内部存储"

say "配置开机自启"
echo "  子系统：把 3-开机自启.sh 内容并入 /root/startbox.sh"
echo "  盒子：  用 4-开机兜底.sh 作为 /data/bootlinux.sh（挂子系统）"

say "先手动起一次（子系统里）"
echo "  aria2c --conf-path=/root/aria2.conf -D"
echo "  smbd -D && nmbd -D"
echo "  minidlnad -f /root/minidlna.conf"
echo "  python3 /root/nasd.py &"

say "完成！浏览器打开  http://$IP:8080/  （下载面板 + 磁盘 + 二维码）"
echo "  电脑映射网络盘： \\\\$IP\\nas"
