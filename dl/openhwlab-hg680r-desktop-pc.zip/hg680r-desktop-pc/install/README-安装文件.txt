========================================
  安装文件 · 说明
  OpenHW Lab · 魔百盒 HG680-R 改「桌面小电脑」
  适用机型：HG680-R（MStar / Android 4.4.4）
========================================

先读上级目录 安装教程（docs/安装教程.md，另附 .txt/.html）。

本目录文件：
  一键安装.sh            电脑上跑：./一键安装.sh <盒子IP>（装桌面 + Firefox配置 + 瘦身 + swap + 开机自启）
  桌面.apk               「桌面」App（com.openhwlab.desktop，设为 HOME，图标双击打开）
  1-系统瘦身.sh          禁无用包
  2-内存扩容.sh          建 /cache swap（zram 由 ROM 自带）
  5-局域网互传.py        互传服务 :8890 → 子系统 /root/transfer.py
  6-系统工具服务.py      系统工具 :8899(本机) → 子系统 /root/boxctl.py
  开机自启-盒子.sh       盒子侧开机脚本 → /data/startlinux.sh（钩 init.fhservice.sh）
  firefox-user.js        Firefox 桌面UA/单标签/百度 配置 → 子系统 Fireofx profile
  framework-res.original.apk / .patched.apk   系统指针补丁(手→箭头 + 去白圈)前后
  pointer_arrow.png      替换用的箭头图

端口：8890 互传 · 8899 系统工具(仅本机) · 5555 ADB

⚠️ 本 ROM 要点：
  · adbd 需授权：把电脑 ~/.android/adbkey.pub 写入盒子 /data/misc/adb/adb_keys 再重启 adbd。
  · 开机自启钩子 = /system/bin/opt/etc/init.fhservice.sh（追加 sh /data/startlinux.sh &）。
  · 改 framework-res 有风险，改前备份 /data/fwres.bak。
  · 系统老(4.4.4)：只认 minSdk≤19 的 App；WPS高版装不上、B站TV跑不动 → 用网页版/当贝市场兼容版。

—— OpenHW Lab · hi@openhwlab.com
