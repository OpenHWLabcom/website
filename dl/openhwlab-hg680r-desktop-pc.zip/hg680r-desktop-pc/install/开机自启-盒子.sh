#!/system/bin/sh
# OpenHW Lab · HG680-R 桌面小电脑 开机自启（Android 侧）
# 由 init.fhservice.sh 调用；等系统启动完成后再挂子系统/起服务。
# 用 start-stop-daemon(pidfile) 保证幂等，避免 pgrep 误判。
R=/data/linux
BB=/system/bin/busybox
CPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
CH="$BB chroot $R /usr/bin/env -i PATH=$CPATH HOME=/root"

# 1) 等系统启动完成（网络/框架就绪；MStar 启动慢）
n=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ $n -lt 150 ]; do $BB sleep 2; n=$((n+1)); done
$BB sleep 5

# 2) swap 扩容（zram 由 ROM 自挂）
[ -f /cache/swapfile ] && $BB swapon /cache/swapfile 2>/dev/null

# 3) 挂子系统
for i in 1 2 3 4 5; do [ -d $R/usr ] && break; $BB sleep 1; done
$BB mount -t proc  proc  $R/proc 2>/dev/null
$BB mount -t sysfs sysfs $R/sys  2>/dev/null
$BB mount -o bind  /dev  $R/dev  2>/dev/null
$BB mount -t devpts devpts $R/dev/pts 2>/dev/null
mkdir -p $R/mnt/sdcard $R/run 2>/dev/null
$BB mount -o bind /mnt/shell/emulated $R/mnt/sdcard 2>/dev/null

# 4) 起互传(:8890) + 系统工具(:8899) —— pidfile 幂等
$CH /sbin/start-stop-daemon --start --background --make-pidfile \
    --pidfile /run/transfer.pid --chdir /root --exec /usr/bin/python3 -- /root/transfer.py 2>/dev/null
[ -f $R/root/boxctl.py ] && $CH /sbin/start-stop-daemon --start --background --make-pidfile \
    --pidfile /run/boxctl.pid --chdir /root --exec /usr/bin/python3 -- /root/boxctl.py 2>/dev/null

# 5) ADB over TCP 保活（重起 adbd 让它带 5555 端口）
setprop service.adb.tcp.port 5555
setprop ctl.restart adbd

echo "startlinux done $(date)" >> /data/startlinux.log
