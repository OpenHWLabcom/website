#!/bin/bash
# ============================================================
#  OpenHW Lab · 魔百盒 HG680-R 改「桌面小电脑」—— 一键安装（电脑上跑）
#  适用机型：魔百盒 HG680-R（MStar 平台 / Android 4.4.4）
#  用法：  ./一键安装.sh <盒子IP>
#  前提：  盒子已 root、已开 ADB（串口里: setprop service.adb.tcp.port 5555; start adbd；
#          本 ROM adbd 需授权：把电脑 ~/.android/adbkey.pub 写入盒子 /data/misc/adb/adb_keys 再重启 adbd）；
#          电脑装了 adb，与盒子同一局域网。
#  作用：  装打印桌面/软件图标 + Firefox(桌面UA) + 瘦身 + swap + 开机自启(init.fhservice.sh 钩子)
#          + （可选）系统鼠标指针补丁(手→箭头/去白圈)。
#          幂等，可重复执行。
# ============================================================
set -e
IP="$1"
[ -z "$IP" ] && { echo "用法: $0 <盒子IP>"; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"
BOX="${IP}:5555"
R=/data/linux
C(){ adb -s "$BOX" shell "$@"; }
say(){ echo -e "\n\033[1;36m==> $*\033[0m"; }

say "连接盒子 $BOX"
adb connect "$BOX"; adb wait-for-device

say "装「桌面」App（com.openhwlab.desktop）→ 设为默认 HOME"
adb -s "$BOX" push "$HERE/桌面.apk" /data/local/tmp/desk.apk
C "pm install -r /data/local/tmp/desk.apk"
C "am start -n com.openhwlab.desktop/.MainActivity" || true
C "pm disable com.fiberhome.iptv" 2>/dev/null || true   # 禁运营商桌面(可 pm enable 还原)

say "装浏览器 Firefox（若未装；装完写桌面UA配置）"
if ! C "pm list packages | /system/bin/busybox grep -q org.mozilla.firefox"; then
  echo "  ⚠️ 未装 Firefox。请先手动安装 armv7 的 Firefox 68（多语言），再重跑本脚本。"
else
  P=$(C "ls -d /data/data/org.mozilla.firefox/files/mozilla/*/ 2>/dev/null | /system/bin/busybox head -1" | tr -d '\r')
  if [ -n "$P" ]; then
    adb -s "$BOX" push "$HERE/firefox-user.js" "${P}user.js"
    C "am force-stop org.mozilla.firefox" || true
    echo "  已写桌面UA配置: ${P}user.js"
  fi
  C "pm disable com.android.browser" 2>/dev/null || true   # 避免与Firefox抢打开链接
fi

say "瘦身 + 内存扩容(swap)"
adb -s "$BOX" push "$HERE/1-系统瘦身.sh" /data/瘦身.sh
adb -s "$BOX" push "$HERE/2-内存扩容.sh" /data/扩容.sh
C "sh /data/瘦身.sh" || true
C "sh /data/扩容.sh" || true

say "子系统服务（互传 :8890 / 系统工具 :8899）——需 /data/linux 子系统"
if C "[ -d $R/root ]"; then
  adb -s "$BOX" push "$HERE/5-局域网互传.py"   $R/root/transfer.py
  adb -s "$BOX" push "$HERE/6-系统工具服务.py" $R/root/boxctl.py
  adb -s "$BOX" push "$HERE/close_fg.sh"        /data/close_fg.sh
  # qrcodegen（互传页二维码用；没有也能跑）
  echo "  (如需二维码：在子系统里 pip 装 qrcodegen，或忽略)"
else
  echo "  ⚠️ /data/linux 不存在：先建子系统(Ubuntu 20.04 armhf)+python3（见 docs/安装教程.md）"
fi

say "配开机自启（钩到 init.fhservice.sh）"
adb -s "$BOX" push "$HERE/开机自启-盒子.sh" /data/startlinux.sh
C "chmod 755 /data/startlinux.sh"
C "mount -o remount,rw /system 2>/dev/null || true"
C "[ -f /system/bin/opt/etc/init.fhservice.sh.bak ] || /system/bin/busybox cp /system/bin/opt/etc/init.fhservice.sh /system/bin/opt/etc/init.fhservice.sh.bak"
C "/system/bin/busybox grep -q startlinux /system/bin/opt/etc/init.fhservice.sh || { echo '' >> /system/bin/opt/etc/init.fhservice.sh; echo '# OpenHW Lab desktop autostart' >> /system/bin/opt/etc/init.fhservice.sh; echo 'sh /data/startlinux.sh >/dev/null 2>&1 &' >> /system/bin/opt/etc/init.fhservice.sh; }"

say "(可选) 系统鼠标指针补丁：手 → 箭头 + 去掉白圈"
echo "  本 ROM 指针是'手'、且指针处有白圈。可刷入本目录已改好的 framework-res.patched.apk："
echo "    adb shell 'mount -o remount,rw /system'"
echo "    adb shell 'cp /system/framework/framework-res.apk /data/fwres.bak'"
echo "    adb push framework-res.patched.apk /system/framework/framework-res.apk"
echo "    adb shell 'chmod 644 /system/framework/framework-res.apk; reboot'"
echo "  ⚠️ 改核心包有风险（本次实测可正常开机）；还原： cp /data/fwres.bak /system/framework/framework-res.apk"

say "完成！重启后自检：桌面(开机进)、互传 http://$IP:8890/ 、adb root"
