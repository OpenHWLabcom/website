# 魔百盒 HG680-R 改「桌面小电脑」· China Mobile HG680-R → Mini PC

> **适用机型（重要）：魔百盒 HG680-R — 主控 MStar（platform `clippers`），Android 4.4.4。**
> For the **China Mobile HG680-R** box (**MStar** SoC, platform `clippers`, Android 4.4.4).

把吃灰的 **HG680-R** 变成一台**桌面小电脑**：开机进桌面、浏览器上网办公、中文输入、
局域网互传、当贝市场/投屏/电视直播等 App **双击即用**，**断电重启全自动**。

> 与通用版 [tvbox-desktop-pc](https://github.com/OpenHWLabcom/tvbox-desktop-pc) 同一产品思路；本仓库是**针对 HG680-R（MStar）实测**的型号版，含该机型**专属**的处理（开机自启、指针补丁、adb 授权等）。

---

## 🇨🇳 中文

### 实测机型
| 项 | 值 |
|---|---|
| 型号 | **HG680-R**（`ro.product.model/name`=HG680-R） |
| 品牌/平台 | **MStar**（`ro.product.brand=MStar`；platform/hardware=`clippers`；board=`orange`） |
| CPU/系统 | 4×Cortex-A7（armv7）；Android **4.4.4**（SDK19） |
| 内存/存储 | RAM ~800MB；eMMC 4GB（`/data`、`/cache` 各 ~992MB） |
| 串口/网络 | console 115200；eth0 |

### 功能
- **桌面**（开机即进，默认 HOME）：双击打开图标（像电脑软件）
- **浏览器**：Firefox 68（**桌面版 UA**、单标签、百度主页）
- **应用**：当贝市场 / 当贝投屏 / 电视直播（双击即用）；当贝市场可自己装 App
- **中文输入法**：盒内自带搜狗输入法 TV
- **局域网互传**：手机/电脑开 `http://<盒子IP>:8890/` 传文件
- **存储当内存**：多层 swap（zram + /cache 文件）
- **鼠标指针**：**箭头**（非"手"）+ 去掉指针白圈（framework-res 补丁）
- **开机自愈**：桌面/互传/adb 全自动

### 环境要求
- **已 root** 的 **HG680-R**（能开 ADB）。⚠️ 本 ROM adbd **需授权**：把电脑 `~/.android/adbkey.pub` 写入盒子 `/data/misc/adb/adb_keys`，再 `stop/start adbd`。
- 电脑装了 `adb`；**不刷机**，随时可还原。

### 安装
```bash
cd install
./一键安装.sh <盒子IP>
```
详细图文：**[`docs/安装教程.md`](docs/安装教程.md)**

### 操作
- 桌面双击图标打开应用；右上角悬浮栏有 `返回/任务/⌂桌面/确定/关机`
- 浏览器：桌面「浏览器」→ Firefox 百度；应用：桌面「当贝市场/当贝投屏/电视直播」
- 传文件：`http://<盒子IP>:8890/`

---

## 🇬🇧 English

### Tested hardware
**China Mobile HG680-R** — **MStar** SoC (platform `clippers`, board `orange`), 4×Cortex-A7 (armv7),
Android **4.4.4**, ~800MB RAM, 4GB eMMC, console 115200.

### Features
- **Desktop** (default HOME, boots straight in) — **double-click icons** to open
- **Browser**: Firefox 68 (desktop UA, single tab, Baidu home)
- **Apps**: Dangbei Market / Dangbei Cast / Live TV (double-click); install more from Dangbei Market
- **Chinese IME** (built-in Sogou TV)
- **LAN file transfer**: `http://<box-ip>:8890/`
- **Storage as RAM**: multi-layer swap
- **Mouse pointer = arrow** (not a hand) + no white ring (framework-res patch)
- **Self-healing autostart**

### Install
```bash
cd install
./一键安装.sh <box-ip>
```
Guide: **[`docs/安装教程.md`](docs/安装教程.md)**

---

## 与通用版的关键差异 · Key differences vs the generic version

| | 通用版 | **HG680-R 型号版（本仓库）** |
|---|---|---|
| 目标机型 | 任意 | **魔百盒 HG680-R（MStar / Android 4.4.4）** |
| 开机自启 | 模板 | 已适配：钩 **`/system/bin/opt/etc/init.fhservice.sh`**（等 boot_completed；start-stop-daemon 幂等；`ctl.restart adbd` 开 5555） |
| ADB | 一般直连 | 本 ROM adbd **需授权**（写 `/data/misc/adb/adb_keys`） |
| 鼠标指针 | — | **framework-res 补丁**：`pointer_arrow`→箭头、`pointer_spot_*`→透明 |
| 桌面 | 单击打开 | **双击打开** + 当贝市场/投屏/电视直播图标 |

---

## License · 许可
[MIT](LICENSE) · 仅供学习与个人使用 / For learning and personal use only.

## 🔗 相关链接
- 官网 **OpenHW Lab**：https://www.openhwlab.com/
- 通用版：https://github.com/OpenHWLabcom/tvbox-desktop-pc
- 同系列：CM201-1/CM201-2 打印机服务器 · M301H 下载机NAS · 机顶盒改游戏机 等

联系 · Contact：hi@openhwlab.com
