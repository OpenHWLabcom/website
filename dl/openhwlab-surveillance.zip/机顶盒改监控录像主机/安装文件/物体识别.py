#!/usr/bin/env python3
# 本地 YOLO 物体识别 + 告警 (chroot 内运行, onnxruntime)
# - 每隔 INTERVAL 秒从 cam.py 的 /snap.jpg 取最新帧, 跑一次检测
# - 实时结果: 标注图 OUT_JPG + 结构化 OUT_JSON (供 cam.py 页面展示)
# - 命中 TARGETS: 存「告警截图」到 ALERT_DIR + 记 ALERT_LOG + 推送手机(notify)
# 环境变量: DET_INTERVAL(6) DET_CONF DET_IOU DET_THREADS DET_TARGETS DET_IMGSZ DET_ONCE
# 告警配置: /root/alert.cfg  (provider=ntfy|serverchan|bark|telegram|pushplus|webhook)
import os, io, json, time, glob, urllib.request, urllib.parse
import numpy as np
import cv2
import onnxruntime as ort

MODEL   = os.environ.get("DET_MODEL", "/root/yolov8n_320.onnx")
SETFILE = "/root/det.set"                 # 精度档: imgsz=320|416|480|640
SNAP    = os.environ.get("DET_SNAP", "http://127.0.0.1:8891/snap.jpg")
OUT_JPG = os.environ.get("DET_OUT", "/root/det_latest.jpg")
OUT_JSON= "/root/det.json"
INTERVAL= int(os.environ.get("DET_INTERVAL", "6"))
CONF    = float(os.environ.get("DET_CONF", "0.35"))
IOU     = float(os.environ.get("DET_IOU", "0.45"))
THREADS = int(os.environ.get("DET_THREADS", "2"))
TARGETS = [s for s in os.environ.get("DET_TARGETS", "person,car,bus,truck,motorcycle,bicycle,dog,cat").split(",") if s]
ONCE    = os.environ.get("DET_ONCE") == "1"

ALERT_DIR  = os.environ.get("ALERT_DIR", "/mnt/sdcard/alerts")
ALERT_LOG  = os.path.join(ALERT_DIR, "events.log")
ALERT_MAX  = int(os.environ.get("ALERT_MAX", "500"))       # 保留告警截图数量
COOLDOWN   = int(os.environ.get("ALERT_COOLDOWN", "90"))   # 同类告警最小间隔(秒)
CFG        = os.environ.get("ALERT_CFG", "/root/alert.cfg")

CLASSES = ["person","bicycle","car","motorcycle","airplane","bus","train","truck","boat","traffic light",
"fire hydrant","stop sign","parking meter","bench","bird","cat","dog","horse","sheep","cow","elephant",
"bear","zebra","giraffe","backpack","umbrella","handbag","tie","suitcase","frisbee","skis","snowboard",
"sports ball","kite","baseball bat","baseball glove","skateboard","surfboard","tennis racket","bottle",
"wine glass","cup","fork","knife","spoon","bowl","banana","apple","sandwich","orange","broccoli","carrot",
"hot dog","pizza","donut","cake","chair","couch","potted plant","bed","dining table","toilet","tv","laptop",
"mouse","remote","keyboard","cell phone","microwave","oven","toaster","sink","refrigerator","book","clock",
"vase","scissors","teddy bear","hair drier","toothbrush"]

ZH = {"person":"人","bicycle":"自行车","car":"汽车","motorcycle":"摩托","bus":"公交","truck":"卡车","dog":"狗","cat":"猫"}


# ---------- 模型 / 检测 ----------
def load(path=MODEL):
    so = ort.SessionOptions()
    so.intra_op_num_threads = THREADS
    so.log_severity_level = 3
    return ort.InferenceSession(path, so, providers=["CPUExecutionProvider"])


def model_for(size):
    p = "/root/yolov8n_%d.onnx" % size
    return p if os.path.exists(p) else MODEL


def get_set():
    d = {}
    try:
        for ln in open(SETFILE):
            k, _, v = ln.strip().partition("=")
            if k:
                d[k.strip()] = v.strip()
    except Exception:
        pass
    return d


def get_n():
    try:
        return int(json.loads(urllib.request.urlopen("http://127.0.0.1:8891/cams.json", timeout=5).read()).get("n", 1))
    except Exception:
        return 1


def grab(cam=0):
    url = SNAP + (("?" if "?" not in SNAP else "&") + "cam=%d" % cam)
    with urllib.request.urlopen(url, timeout=8) as r:
        buf = np.frombuffer(r.read(), np.uint8)
    return cv2.imdecode(buf, cv2.IMREAD_COLOR)


def letterbox(img, new=640):
    h, w = img.shape[:2]
    r = min(new / h, new / w)
    nh, nw = int(round(h * r)), int(round(w * r))
    resized = cv2.resize(img, (nw, nh))
    canvas = np.full((new, new, 3), 114, np.uint8)
    dy, dx = (new - nh) // 2, (new - nw) // 2
    canvas[dy:dy + nh, dx:dx + nw] = resized
    return canvas, r, dx, dy


def detect(sess, img, size):
    canvas, r, dx, dy = letterbox(img, size)
    x = cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    x = np.ascontiguousarray(x.transpose(2, 0, 1)[None])
    out = sess.run(None, {sess.get_inputs()[0].name: x})[0]      # (1,84,N)
    p = out[0].T
    cls_scores = p[:, 4:]
    ids = cls_scores.argmax(1)
    confs = cls_scores[np.arange(len(ids)), ids]
    keep = confs > CONF
    if not keep.any():
        return []
    p, ids, confs = p[keep], ids[keep], confs[keep]
    cx, cy, w, h = p[:, 0], p[:, 1], p[:, 2], p[:, 3]
    if max(cx.max(), cy.max(), w.max(), h.max()) < 2.0:          # 归一化 xywh -> 画布像素
        cx = cx * size; cy = cy * size; w = w * size; h = h * size
    lb = np.stack([cx - w / 2, cy - h / 2, w, h], 1)
    idx = cv2.dnn.NMSBoxes(lb.tolist(), confs.tolist(), CONF, IOU)
    H, W = img.shape[:2]
    dets = []
    if len(idx):
        for i in np.array(idx).flatten():
            bx, by, bw, bh = lb[i]
            bx = (bx - dx) / r; by = (by - dy) / r; bw /= r; bh /= r
            bx = max(0, min(W - 1, bx)); by = max(0, min(H - 1, by))
            bw = max(1, min(W - bx, bw)); bh = max(1, min(H - by, bh))
            dets.append({"cls": CLASSES[int(ids[i])] if int(ids[i]) < len(CLASSES) else str(int(ids[i])),
                         "conf": float(confs[i]), "box": [float(bx), float(by), float(bw), float(bh)]})
    return dets


# ---------- 告警配置 / 推送 ----------
def cfg():
    d = {}
    try:
        for ln in open(CFG):
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, _, v = ln.partition("=")
                d[k.strip()] = v.strip()
    except Exception:
        pass
    return d


def alert_token():
    c = cfg()
    t = c.get("alert_token") or ""
    if not t:
        t = os.urandom(8).hex()
        try:
            with open(CFG, "a") as f:
                f.write("alert_token=%s\n" % t)
        except Exception:
            pass
    return t


def _post(url, data=None, headers=None, method=None):
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    return urllib.request.urlopen(req, timeout=10).read()[:200]


def notify(title, msg, img_path=None, img_url=None):
    c = cfg()
    prov = (c.get("provider") or "").lower()
    if not prov:
        return "no provider"
    try:
        if prov == "ntfy":
            base = (c.get("ntfy_url") or "https://ntfy.sh").rstrip("/")
            payload = {"topic": c.get("ntfy_topic", ""), "title": title, "message": msg,
                       "tags": ["rotating_light"]}
            if img_url:
                payload["attach"] = img_url
                payload["click"] = img_url
            return _post(base, json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                         {"Content-Type": "application/json; charset=utf-8"})
        if prov == "serverchan":
            key = c.get("serverchan_key", "")
            u = "https://sctapi.ftqq.com/%s.send?title=%s&desp=%s" % (
                key, urllib.parse.quote(title), urllib.parse.quote(msg + ("\n![](%s)" % img_url if img_url else "")))
            return _post(u)
        if prov == "bark":
            base = c.get("bark_url", "https://api.day.app")
            key = c.get("bark_key", "")
            u = "%s/%s/%s/%s?group=cam" % (base.rstrip("/"), key, urllib.parse.quote(title), urllib.parse.quote(msg))
            if img_url:
                u += "&image=" + urllib.parse.quote(img_url)
            return _post(u)
        if prov == "telegram":
            tok = c.get("telegram_token", ""); chat = c.get("telegram_chat", "")
            if img_path and os.path.exists(img_path):
                boundary = "----camalert"
                b = io.BytesIO()
                b.write(("--%s\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n%s\r\n" % (boundary, chat)).encode())
                b.write(("--%s\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n%s\r\n" % (boundary, title + " " + msg)).encode())
                b.write(("--%s\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"a.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n" % boundary).encode())
                b.write(open(img_path, "rb").read()); b.write(("\r\n--%s--\r\n" % boundary).encode())
                return _post("https://api.telegram.org/bot%s/sendPhoto" % tok, b.getvalue(),
                             {"Content-Type": "multipart/form-data; boundary=%s" % boundary})
            return _post("https://api.telegram.org/bot%s/sendMessage" % tok,
                         urllib.parse.urlencode({"chat_id": chat, "text": title + "\n" + msg}).encode())
        if prov == "pushplus":
            tok = c.get("pushplus_token", "")
            return _post("http://www.pushplus.plus/send",
                         json.dumps({"token": tok, "title": title, "content": msg + ("\n![](%s)" % img_url if img_url else "")}).encode(),
                         {"Content-Type": "application/json"})
        if prov == "webhook":
            u = c.get("webhook_url", "")
            payload = {"title": title, "message": msg, "image_url": img_url, "ts": int(time.time())}
            return _post(u, json.dumps(payload).encode(), {"Content-Type": "application/json"})
        return "unknown provider %s" % prov
    except Exception as e:
        return "notify err %r" % e


def _urls():
    lan = ""
    try:
        s = __import__("socket").socket(__import__("socket").AF_INET, __import__("socket").SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); lan = s.getsockname()[0]; s.close()
    except Exception:
        lan = "127.0.0.1"
    tun = ""
    try:
        tun = open("/root/tunnel.url").read().strip().rstrip("/")
    except Exception:
        pass
    return lan, tun


# ---------- 主循环 ----------
def save_alert(cam, vis, hit, uniq):
    os.makedirs(ALERT_DIR, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    fn = "alert_c%d_%s_%s.jpg" % (cam, ts, "-".join(sorted(hit)))
    fp = os.path.join(ALERT_DIR, fn)
    cv2.imwrite(fp, vis, [cv2.IMWRITE_JPEG_QUALITY, 85])
    line = "%s  [c%d] %s  %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), cam, ",".join("%s x%d" % (k, uniq[k]) for k in hit), fn)
    try:
        with open(ALERT_LOG, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass
    # 数量上限(删最旧)
    try:
        files = sorted(glob.glob(os.path.join(ALERT_DIR, "alert_*.jpg")))
        for f in files[:-ALERT_MAX] if len(files) > ALERT_MAX else []:
            os.remove(f)
    except Exception:
        pass
    return fp


_ncam = 0
_nt = 0


def main():
    global CONF, dcam, _ncam, _nt
    st = get_set()
    size = int(st.get("imgsz", "416"))
    dcam = int(st.get("cam", "0"))
    path = model_for(size)
    sess = load(path)
    size = int(sess.get_inputs()[0].shape[2])
    print("det ready model=%s imgz=%d cam=%d interval=%ds alerts=%s targets=%s" % (path, size, dcam, INTERVAL, ALERT_DIR, TARGETS), flush=True)
    os.makedirs(ALERT_DIR, exist_ok=True)
    last_alert = {}          # cls -> ts
    while True:
        # 精度档可在页面上实时切换(读 det.set)
        try:
            st = get_set()
            ns = int(st.get("imgsz", str(size)))
            if ns != size:
                np2 = model_for(ns)
                sess = load(np2); size = int(sess.get_inputs()[0].shape[2])
                print("reload model=%s imgz=%d" % (np2, size), flush=True)
            if st.get("rotate", "0") == "1":
                if _ncam <= 1 or time.time() - _nt > 60:
                    _ncam = get_n(); _nt = time.time()
                if _ncam > 1:
                    dcam = (dcam + 1) % _ncam
            else:
                ncam = int(st.get("cam", str(dcam)))
                if ncam != dcam:
                    dcam = ncam
                    print("det cam -> %d" % dcam, flush=True)
            if st.get("conf"):
                CONF = float(st["conf"])
        except Exception as e:
            print("set err", repr(e), flush=True)
        t0 = time.time()
        img = None
        try:
            img = grab(dcam)
        except Exception as e:
            print("grab err", e, flush=True)
        if img is not None:
            try:
                dets = detect(sess, img, size)
                vis = img.copy()
                uniq = {}
                for d in dets:
                    bx, by, bw, bh = [int(v) for v in d["box"]]
                    col = (0, 0, 255) if d["cls"] in TARGETS else (0, 200, 0)
                    cv2.rectangle(vis, (bx, by), (bx + bw, by + bh), col, 2)
                    cv2.putText(vis, "%s %.2f" % (d["cls"], d["conf"]), (bx + 2, max(14, by - 4)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.55, col, 2)
                    uniq[d["cls"]] = uniq.get(d["cls"], 0) + 1
                cv2.putText(vis, "cam%d  " % (dcam + 1) + time.strftime("%Y-%m-%d %H:%M:%S"), (8, vis.shape[0] - 8),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.imwrite(OUT_JPG, vis, [cv2.IMWRITE_JPEG_QUALITY, 80])
                hit = [c for c in uniq if c in TARGETS]
                res = {"ts": int(time.time()), "ms": int((time.time() - t0) * 1000), "cam": dcam,
                       "scale": [img.shape[1], img.shape[0]], "items": uniq, "dets": dets, "targets": hit}
                tmp = OUT_JSON + ".tmp"
                open(tmp, "w").write(json.dumps(res))
                os.replace(tmp, OUT_JSON)
                # 告警
                now = time.time()
                fire = [c for c in hit if now - last_alert.get(c, 0) > COOLDOWN]
                if fire:
                    fp = save_alert(dcam, vis, hit, uniq)
                    for c in hit:
                        last_alert[c] = now
                    lan, tun = _urls()
                    names = "、".join("%s×%d" % (ZH.get(k, k), uniq[k]) for k in hit)
                    title = "摄像头告警(第%d路): %s" % (dcam + 1, names)
                    tok = alert_token()
                    if tun:
                        url = "%s/alert/%s?k=%s" % (tun, os.path.basename(fp), tok)
                    else:
                        url = "http://%s:8891/alert/%s?k=%s" % (lan, os.path.basename(fp), tok)
                    msg = "%s\n%s\n%s" % (time.strftime("%Y-%m-%d %H:%M:%S"), os.environ.get("CAM_NAME", "盒子摄像头"), url)
                    r = notify(title, msg, fp, url)
                    print("ALERT %s -> notify %r" % (names, r), flush=True)
                print("det %dms %s" % (res["ms"], uniq), flush=True)
            except Exception as e:
                print("det err", repr(e), flush=True)
        if ONCE:
            break
        time.sleep(max(1.0, INTERVAL - (time.time() - t0)))


if __name__ == "__main__":
    import fcntl as _f
    _lk = open("/run/det.lock", "w")
    try:
        _f.flock(_lk, _f.LOCK_EX | _f.LOCK_NB)
    except OSError:
        print("another det running; exit", flush=True); os._exit(0)
    main()
