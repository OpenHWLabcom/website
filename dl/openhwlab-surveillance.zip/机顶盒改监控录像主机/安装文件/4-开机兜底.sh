#!/system/bin/sh
# OpenHW Lab bootfix: 开机兜底 —— 关掉卡住的开机系统弹窗 + 确保桌面在前台
# 由 /data/startlinux.sh 在 Android(root=/) 上下文后台调用。
# 背景: 这 ROM(ZTE DingQin) 开机 bootscreen 偶尔不消失会把桌面挡死;
#       这里在开机后反复"关系统弹窗 + 拉桌面"直到桌面真的在前台。
# ⚠️ 2026-10-02: 改成**先看焦点再决定是否 am start** —— 否则 桌面 若已自动进了
#    摄像头画面(WebActivity), 这里的 am start MainActivity 会把它顶掉。
BB=/system/xbin/busybox
export PATH=/system/bin:/system/xbin:/sbin:/vendor/bin:/system/sbin
LOG=/data/bootfix.log

echo "=== bootfix start ===" >> $LOG

# 1) 等启动完成 (最多 ~5min)
n=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ $n -lt 150 ]; do
  $BB sleep 2; n=$((n+1))
done
echo "boot_completed (waited $((n*2))s)" >> $LOG

# 2) 准备 am/dumpsys 需要的环境 (开机脚本里没有 BOOTCLASSPATH, 缺了 am 会静默失效)
SP=$($BB pidof system_server)
if [ -n "$SP" ]; then
  BC=$($BB tr '\0' '\n' < /proc/$SP/environ 2>/dev/null | $BB grep ^BOOTCLASSPATH= | $BB cut -d= -f2-)
fi
[ -z "$BC" ] && BC="/system/framework/core.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/framework2.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/services.jar:/system/framework/apache-xml.jar:/system/framework/webviewchromium.jar"
export ANDROID_ROOT=/system ANDROID_DATA=/data LD_LIBRARY_PATH=/vendor/lib:/system/lib BOOTCLASSPATH="$BC"

# 3) 反复: 关系统弹窗; 若 桌面 不在前台才拉起桌面 (最多 ~2min)
i=0
while [ $i -lt 8 ]; do
  $BB sleep 15
  am broadcast -a android.intent.action.CLOSE_SYSTEM_DIALOGS >/dev/null 2>&1
  if dumpsys window windows 2>/dev/null | $BB grep -q "mCurrentFocus=.*com.openhwlab.desktop"; then
    echo "桌面 foreground @iter $i" >> $LOG
    break
  else
    am start -n com.openhwlab.desktop/.MainActivity >/dev/null 2>&1
  fi
  i=$((i+1))
done

echo "=== bootfix done (iter=$i) ===" >> $LOG
