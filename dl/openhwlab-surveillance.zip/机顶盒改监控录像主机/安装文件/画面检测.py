#!/usr/bin/env python3
# 画面自动检测 (look) —— 移动侦测 + 画面异常侦测
#   移动: 相邻帧变化像素比例超阈值 -> 判定有移动
#   异常: 无画面(抓不到) / 黑屏·遮挡(灰度方差过低) / 画面卡住(连续多帧几乎不变)
#   结果写 /root/look.json (cam.py 页面读取显示); 事件截图存 /mnt/sdcard/alerts/;
#   异常/移动可按 /root/alert.cfg 推送手机 (复用 monitor.notify/alert)。
# 环境变量: LOOK_INTERVAL LOOK_MOTION LOOK_BLANK_STD LOOK_FREEZE_N LOOK_MOTION_CD LOOK_ANOM_CD
import os, sys, json, time
os.environ["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:" + os.environ.get("PATH", "")
sys.path.insert(0, "/root")
import urllib.request
import numpy as np
import cv2
try:
    import monitor as MON        # 复用 alert.cfg 的推送
except Exception:
    MON = None

OUT = "/root/look.json"
ALERT_DIR = "/mnt/sdcard/alerts"
EVENTS = ALERT_DIR + "/events.log"
INTERVAL = float(os.environ.get("LOOK_INTERVAL", "4"))
MOTION_TH = float(os.environ.get("LOOK_MOTION", "0.03"))    # 变化像素比例阈值
BLANK_STD = float(os.environ.get("LOOK_BLANK_STD", "6"))    # 灰度标准差 < 此值 -> 黑屏/遮挡
FREEZE_N = int(os.environ.get("LOOK_FREEZE_N", "15"))        # 连续多少帧几乎不变 -> 画面卡住
MOTION_CD = float(os.environ.get("LOOK_MOTION_CD", "20"))   # 移动事件冷却(秒)
ANOM_CD = float(os.environ.get("LOOK_ANOM_CD", "300"))      # 异常告警冷却(秒)
W, H = 192, 108
CAM_API = "http://127.0.0.1:8891"


def cams():
    try:
        j = json.load(urllib.request.urlopen(CAM_API + "/cams.json", timeout=6))
        return int(j.get("n", 0)), list(j.get("names", []))
    except Exception:
        return 0, []


def grab(i):
    """返回 (缩小灰度帧 or None, 原始JPEG字节 or None)"""
    try:
        b = urllib.request.urlopen(CAM_API + "/snap.jpg?cam=%d" % i, timeout=8).read()
    except Exception:
        return None, None
    im = cv2.imdecode(np.frombuffer(b, np.uint8), cv2.IMREAD_GRAYSCALE)
    if im is None:
        return None, b
    return cv2.resize(im, (W, H)), b


def save_shot(raw, tag, i, name):
    if not raw:
        return
    try:
        os.makedirs(ALERT_DIR, exist_ok=True)
        base = "look_c%d_%s_%s.jpg" % (i, time.strftime("%Y%m%d_%H%M%S"), tag)
        with open(os.path.join(ALERT_DIR, base), "wb") as f:
            f.write(raw)
        with open(EVENTS, "a") as f:
            f.write("%s  look  cam%d  %s  %s  %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), i, tag, name, base))
    except Exception:
        pass


def push(key, title, msg):
    if MON:
        try:
            MON.alert(key, title, msg)
        except Exception:
            pass


def main():
    prev = {}
    still = {}
    last_motion = {}
    last_anom = {}
    n, names = 0, []
    while True:
        t0 = time.time()
        if not n:
            n, names = cams()
        out = []
        for i in range(max(n, 1)):
            name = names[i] if i < len(names) else "cam%d" % i
            img, raw = grab(i)
            st = {"i": i, "name": name, "state": "ok", "motion": False, "bright": 0, "std": 0}
            if img is None:
                st["state"] = "lost"
                if time.time() - last_anom.get((i, "lost"), 0) > ANOM_CD:
                    last_anom[(i, "lost")] = time.time()
                    push("look_lost%d" % i, "监控异常: 摄像头无画面", "%s 抓不到画面（USB/采集异常）" % name)
                out.append(st)
                continue
            g = img.astype(np.float32)
            bright = float(g.mean())
            std = float(g.std())
            st["bright"] = round(bright, 1)
            st["std"] = round(std, 1)
            p = prev.get(i)
            if p is not None:
                diff = np.abs(g - p)
                ratio = float((diff > 25).mean())
                st["diff"] = round(ratio, 4)
                if ratio > MOTION_TH:
                    st["motion"] = True
                still[i] = still.get(i, 0) + 1 if float(diff.mean()) < 1e-6 else 0   # 帧完全一致才算卡住
            prev[i] = g
            if std < BLANK_STD:
                st["state"] = "blank"
            elif still.get(i, 0) >= FREEZE_N:
                st["state"] = "frozen"
            if st["motion"] and time.time() - last_motion.get(i, 0) > MOTION_CD:
                last_motion[i] = time.time()
                save_shot(raw, "motion", i, name)
                push("look_motion%d" % i, "画面移动: %s" % name, "%s 检测到画面变化 %s" % (name, time.strftime("%F %T")))
            if st["state"] != "ok" and time.time() - last_anom.get((i, "state"), 0) > ANOM_CD:
                last_anom[(i, "state")] = time.time()
                save_shot(raw, st["state"], i, name)
                push("look_%s%d" % (st["state"], i), "画面异常: %s" % name,
                     {"blank": "画面黑屏/被遮挡", "frozen": "画面卡住不动"}.get(st["state"], st["state"]))
            st["motion_age"] = round(time.time() - last_motion[i]) if i in last_motion else -1
            out.append(st)
        try:
            with open(OUT, "w") as f:
                json.dump({"ts": time.time(), "interval": INTERVAL,
                           "motion_th": MOTION_TH, "cams": out}, f)
        except Exception:
            pass
        time.sleep(max(1.0, INTERVAL - (time.time() - t0)))


if __name__ == "__main__":
    import fcntl
    _lk = open("/run/look.lock", "w")
    try:
        fcntl.flock(_lk, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("another look running; exit", flush=True)
        os._exit(0)
    print("look start (interval %ss, motion_th %s)" % (INTERVAL, MOTION_TH), flush=True)
    main()
