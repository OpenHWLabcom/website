#!/usr/bin/env python3
# 家用监控: USB摄像头(UVC) 直播 + 本地循环录像 + 自动录制 + 手机扫码
#   /              观看/管理页(直播 + 状态 + 录像开关 + 扫码)
#   /live          MJPEG 流
#   /snap.jpg      最近一帧抓拍
#   /rec           录像列表(回看)
#   /recplay?f=    播放某段录像(mp4, 支持 Range)
#   /recctl?on=1|0 开/关录像
#   /qr            手机扫码页(内联 SVG 二维码)
# 单进程双输出: 720p MJPEG 直传直播 + 640x480 H.264 分段录到本地(循环覆盖, 自动录制)
# 环境变量: CAM W H FPS PORT REC RECSEG RLIMIT_GB MINFREE_GB
import os, sys, time, subprocess, threading, queue, glob, socket, shutil, hashlib, signal, html, base64, select, json

# 统一 PATH (由 Android 启动时 PATH 是安卓的, 找不到 chroot 里的 ffmpeg)
os.environ["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:" + os.environ.get("PATH", "")

try:
    _lf = os.open("/root/cam.log", os.O_WRONLY|os.O_CREAT|os.O_APPEND, 0o644)
    os.dup2(_lf, 1); os.dup2(_lf, 2)
except Exception:
    pass

sys.path.insert(0, "/root")
try:
    from qrcodegen import QrCode
except Exception:
    QrCode = None

def _detect_devs():
    out = []
    for v in sorted(glob.glob("/dev/video*")):
        try:
            nm = open("/sys/class/video4linux/%s/name" % os.path.basename(v)).read().strip()
        except Exception:
            continue
        if nm.startswith("zx_"):        # 跳过板载 video 节点(zx_ov/zx_ch)
            continue
        out.append(v)
    return out or ["/dev/video0"]


DEVS = [d for d in os.environ.get("CAM", "").split(",") if d] or _detect_devs()
_N = len(DEVS)
W = int(os.environ.get("W", "1280"))
H = int(os.environ.get("H", "720"))
FPS = os.environ.get("FPS", "15")
PORT = int(os.environ.get("PORT", "8891"))
RECSEG = int(os.environ.get("RECSEG", "30"))
RLIMIT_GB = float(os.environ.get("RLIMIT_GB", "0"))     # 0 = 不限总量, 只按剩余空间
MINFREE_GB = float(os.environ.get("MINFREE_GB", "0.3"))  # 至少保留这么多空闲

_subs = [set() for _ in range(_N)]
_lock = threading.Lock()
_last = [b"" for _ in range(_N)]
_rec_dir = {"d": None}
_state = {"res": "640x480", "fps": 15}
_rec = [(os.environ.get("REC", "1") == "1" and i == 0) for i in range(_N)]
_proc = [None for _ in range(_N)]
SETFILE = "/root/cam.set"
AUTH = {"user": "cam", "pass": ""}     # pass 非空 -> 远程(非本机直连)要密码
URLFILE = "/root/tunnel.url"           # Cloudflare 公网隧道地址(由 tunnel.sh 写入)
SD_MNT = os.environ.get("SD_MNT", "/mnt/sdext")   # 外置 TF/SD 卡挂载点(由 startlinux.sh 挂载)
DET_JPG = "/root/det_latest.jpg"      # 本地识别(YOLO)标注图
DET_JSON = "/root/det.json"
LOOK_JSON = "/root/look.json"           # 画面检测(移动/异常)结果
_LOOK_JS = ("var lk=document.getElementById('lkbar');"
            "function drawLk(){var x=new XMLHttpRequest();x.onload=function(){if(!lk)return;var d={};"
            "try{d=JSON.parse(x.responseText||'{}');}catch(e){}"
            "var now=Date.now()/1000;if(!d.ts||now-d.ts>30){lk.innerHTML='&#128065; \u753b\u9762\u68c0\u6d4b: \u2014';return;}"
            "var nm={ok:'\u6b63\u5e38',blank:'\u5f02\u5e38\u00b7\u9ed1\u5c4f/\u906e\u6321',frozen:'\u5f02\u5e38\u00b7\u5361\u4f4f',lost:'\u65e0\u753b\u9762'},s=[];"
            "(d.cams||[]).forEach(function(c){var t='cam'+(c.i+1)+' '+(nm[c.state]||c.state);if(c.motion)t+=' \u00b7 \u6709\u79fb\u52a8';s.push(t);});"
            "lk.innerHTML='&#128065; \u753b\u9762\u68c0\u6d4b: '+s.join('  |  ');};x.open('GET','/look.json?t='+Date.now(),true);x.send();}"
            "setInterval(drawLk,3000);drawLk();")            # 识别结果
_STORAGE_JS = ("var _sb=document.getElementById('stbar');"
               "function _hg(h){if(h<=0)return '-';if(h>=48)return '\u7ea6'+Math.round(h/24)+'\u5929';"
               "if(h>=1)return '\u7ea6'+h.toFixed(1)+'\u65f6';return '\u7ea6'+Math.round(h*60)+'\u5206';}"
               "function _fg(g){return g>=100?Math.round(g)+'G':(g>=10?g.toFixed(1)+'G':g.toFixed(2)+'G');}"
               "function drawSt(){var x=new XMLHttpRequest();x.onload=function(){if(!_sb)return;var d={};"
               "try{d=JSON.parse(x.responseText||'{}');}catch(e){}if(d.free_gb==null)return;"
               "var pct=d.total_gb>0?Math.round(d.used_gb/d.total_gb*100):0;"
               "_sb.innerHTML='&#128190; \u5f55\u50cf\u76d8['+d.label+'] \u7a7a\u95f2 '+_fg(d.free_gb)+'('+pct+'%\u7528) \u00b7 \u5df2\u5f55 '+d.clips+' \u6bb5 '+_fg(d.rec_gb)+' \u2248 '+_hg(d.rec_hours)+' \u00b7 \u53ef\u518d\u5f55 '+_hg(d.can_hours);};"
               "x.open('GET','/storage.json?t='+Date.now(),true);x.send();}"
               "setInterval(drawSt,10000);drawSt();")
DET_PID = "/run/det.pid"
DET_EVENTS = "/mnt/sdcard/alerts/events.log"
ALERT_DIR = "/mnt/sdcard/alerts"        # 告警截图目录
ALERT_CFG = "/root/alert.cfg"


def alert_token():
    try:
        for ln in open(ALERT_CFG):
            k, _, v = ln.strip().partition("=")
            if k == "alert_token" and v:
                return v
    except Exception:
        pass
    return ""


def det_imgsz():
    try:
        for ln in open("/root/det.set"):
            k, _, v = ln.strip().partition("=")
            if k == "imgsz" and v.strip().isdigit():
                return int(v.strip())
    except Exception:
        pass
    return 416


def det_cam():
    try:
        for ln in open("/root/det.set"):
            k, _, v = ln.strip().partition("=")
            if k == "cam" and v.strip().isdigit():
                return int(v.strip())
    except Exception:
        pass
    return 0


def det_rotate():
    try:
        for ln in open("/root/det.set"):
            k, _, v = ln.strip().partition("=")
            if k == "rotate" and v.strip() == "1":
                return True
    except Exception:
        pass
    return False


def page_events():
    try:
        d = open(DET_EVENTS, encoding="utf-8", errors="ignore").read()[-20000:]
    except Exception:
        d = ""
    d = d.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return ("<!doctype html><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>识别/告警日志</title><style>%s</style>"
            "<div class=\"bar\"><b>&#128680; 识别/告警日志</b></div>"
            "<div class=\"bar\"><a class=\"btn\" href=\"/\">返回监控</a> <a class=\"btn\" href=\"/alerts\">告警截图</a></div>"
            "<div class=\"lst\"><pre style=\"white-space:pre-wrap;text-align:left\">%s</pre></div>"
            % (CSS, d or "(暂无)"))


def page_shot(cam=0):
    return ("<!doctype html><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>抓拍</title><style>" + CSS + "</style>"
            "<div class=\"bar\"><b>&#128248; 抓拍（当前画面）</b> <span class=\"st\">" + time.strftime("%Y-%m-%d %H:%M:%S") + "</span></div>"
            "<div class=\"bar\"><a class=\"btn\" href=\"/view?cam=" + str(cam) + "\">&#8592; 返回</a> "
            "<a class=\"btn\" href=\"/shot?cam=" + str(cam) + "\">重新抓拍</a> "
            "<a class=\"btn\" href=\"/snap.jpg?cam=" + str(cam) + "\" download=\"snap" + str(cam) + ".jpg\">保存图片</a></div>"
            "<div id=\"wrap\"><img src=\"/snap.jpg?cam=" + str(cam) + "&t=" + str(int(time.time() * 1000)) + "\"></div>")


def page_alerts(show_all=False, cam=None):
    files = []
    try:
        files = sorted(glob.glob(os.path.join(ALERT_DIR, "alert_*.jpg")), reverse=True)
    except Exception:
        pass
    total = len(files)
    if cam is not None:
        files = [f for f in files if ("_c%d_" % cam) in os.path.basename(f)
                 or (("_c" not in os.path.basename(f)) and cam == 0)]
        scope = "摄像头%d" % (cam + 1)
        toggle = "<a class='btn' href='/alerts'>全部摄像头</a>"
    else:
        if not show_all:
            files = [f for f in files if "_person" in os.path.basename(f)]
        scope = "仅显示检测到「人」的" if not show_all else "全部类别"
        toggle = ("<a class='btn' href='/alerts'>仅看有人</a>" if show_all
                  else "<a class='btn' href='/alerts?all=1'>显示全部类别</a>")
    n = len(files)
    show = files[:60]
    cells = []
    for f in show:
        fn = os.path.basename(f)
        try:
            mt = time.strftime("%m-%d %H:%M:%S", time.localtime(os.path.getmtime(f)))
        except Exception:
            mt = ""
        cells.append("<td style='width:33.33%;padding:3px;vertical-align:top'>"
                     "<a href='/alert/" + fn + "' target='_blank'>"
                     "<img src='/alert/" + fn + "' style='width:100%;height:auto;display:block;border-radius:4px'>"
                     "<div style='font-size:12px;color:#8fa6c2'>" + mt + "</div></a></td>")
    rows = []
    for i in range(0, len(cells), 3):
        chunk = cells[i:i + 3]
        while len(chunk) < 3:
            chunk.append("<td style='width:33.33%'></td>")
        rows.append("<tr>" + "".join(chunk) + "</tr>")
    table = "<table style='width:100%;border-collapse:collapse;table-layout:fixed'>" + "".join(rows) + "</table>"
    if not cells:
        table = "<div class='bar'>暂无告警</div>"
    return ("<!doctype html><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>告警截图</title><style>" + CSS + "</style>"
            "<div class=\"bar\"><b>&#128680; 告警截图</b> <span class=\"st\">" + scope + " · " + str(n) + " 张（显示最近 " + str(len(show)) + "）</span></div>"
            "<div class=\"bar\">" + toggle + " <a class=\"btn\" href=\"/\">返回监控</a> <a class=\"btn\" href=\"/det_events\">识别/告警日志</a></div>"
            "<div style='max-width:1280px;margin:6px auto'>" + table + "</div>")
# 清晰度预设: 名称 -> (宽x高, 帧率, 码率)
PRESETS = [("高清", "640x480", 15, "800k"),
           ("标准", "480x360", 15, "450k"),
           ("省空间", "320x240", 12, "220k"),
           ("经济", "256x144", 10, "120k"),
           ("极省", "160x120", 8, "80k")]


def load_state():
    global _rec
    try:
        for ln in open(SETFILE):
            k, _, v = ln.strip().partition("=")
            if k == "rec":
                _rec[0] = (v == "1")
            elif k.startswith("rec") and k[3:].isdigit() and int(k[3:]) < _N:
                _rec[int(k[3:])] = (v == "1")
            elif k == "res" and "x" in v:
                _state["res"] = v
            elif k == "fps" and v.isdigit():
                _state["fps"] = int(v)
            elif k == "user" and v:
                AUTH["user"] = v
            elif k == "pass":
                AUTH["pass"] = v
    except Exception:
        pass


def save_state():
    try:
        parts = ["rec%d=%d" % (i, 1 if _rec[i] else 0) for i in range(_N)]
        parts += ["res=%s" % _state["res"], "fps=%d" % _state["fps"],
                  "user=%s" % AUTH["user"], "pass=%s" % AUTH["pass"]]
        open(SETFILE, "w").write("\n".join(parts) + "\n")
    except Exception:
        pass


def restart_capture(i=0):
    # 用 SIGINT 让 ffmpeg 优雅收尾(把当前分段写完 moov), 否则最后一段播不了
    p = _proc[i]
    if not p:
        return
    try:
        p.send_signal(signal.SIGINT)
        for _ in range(25):
            if p.poll() is not None:
                return
            time.sleep(0.2)
        p.kill()
    except Exception:
        pass


def det_on():
    try:
        pid = int(open(DET_PID).read().strip()); os.kill(pid, 0); return True
    except Exception:
        return False


def det_state():
    try:
        return json.load(open(DET_JSON))
    except Exception:
        return {}


def det_start():
    try:
        subprocess.Popen(["/sbin/start-stop-daemon", "--start", "--background", "--make-pidfile",
                          "--pidfile", DET_PID, "--exec", "/usr/bin/python3", "--", "/root/det.py"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def det_stop():
    try:
        os.kill(int(open(DET_PID).read().strip()), 9)
    except Exception:
        pass
    subprocess.run(["pkill", "-9", "-f", "^/usr/bin/python3 /root/det.py"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _is_mount(p):
    try:
        for ln in open("/proc/mounts"):
            f = ln.split()
            if len(f) > 1 and f[1] == p:
                return True
    except Exception:
        pass
    return False


def _dir_writable(d):
    try:
        os.makedirs(d, exist_ok=True)
        t = os.path.join(d, ".w"); open(t, "w").close(); os.remove(t)
        return True
    except Exception:
        return False


def pick_rec_dir():
    # 优先级: 外置 SD/TF 卡 > U 盘 > 内部存储 > /data
    cands = []
    if _is_mount(SD_MNT):              # TF/SD 卡槽(容量大, 首选)
        cands.append(SD_MNT + "/cctv")
    if _is_mount("/mnt/usb"):          # 真挂了 U 盘才用
        cands.append("/mnt/usb/cctv")
    cands += ["/mnt/sdcard/cctv", "/data/cctv"]
    for d in cands:
        if _dir_writable(d):
            return d
    return None


def local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def rec_dir_size():
    rd = _rec_dir["d"]
    if not rd:
        return 0.0
    try:
        return sum(os.path.getsize(f) for f in glob.glob(os.path.join(rd, "*.mp4"))) / 1e9
    except Exception:
        return 0.0


def disk_free_gb():
    rd = _rec_dir["d"] or "/"
    try:
        st = os.statvfs(rd)
        return st.f_bavail * st.f_frsize / 1e9
    except Exception:
        return 0.0


def rec_dir_space():
    # 录像所在文件系统的 (总容量, 已用, 可用), 单位 GB
    rd = _rec_dir["d"] or "/"
    try:
        st = os.statvfs(rd)
        b = st.f_frsize
        total = st.f_blocks * b / 1e9
        free = st.f_bavail * b / 1e9
        used = total - st.f_bfree * b / 1e9
        return total, used, free
    except Exception:
        return 0.0, 0.0, 0.0


def cur_kbps():
    for nm, rs, fp, b in PRESETS:
        if rs == _state["res"] and fp == _state["fps"]:
            try:
                return float(b.rstrip("k") or 800)
            except Exception:
                return 800.0
    return 800.0


def gb_to_hours(gb):
    # kbps -> GB/小时 = kbps*3600/8/1e6 = kbps*0.00045
    return gb / (cur_kbps() * 0.00045)


def rec_mount_label():
    rd = _rec_dir["d"] or ""
    if rd.startswith(SD_MNT):
        return "SD卡"
    if rd.startswith("/mnt/usb"):
        return "U盘"
    return "内部存储"


def rec_clip_count():
    rd = _rec_dir["d"]
    if not rd:
        return 0
    try:
        return len(glob.glob(os.path.join(rd, "*.mp4")))
    except Exception:
        return 0


def fmt_gb(g):
    if g >= 100:
        return "%.0fG" % g
    if g >= 10:
        return "%.1fG" % g
    return "%.2fG" % g


def storage_info():
    total, used, free = rec_dir_space()
    n = rec_clip_count()
    return {"dir": _rec_dir["d"], "label": rec_mount_label(),
            "total_gb": round(total, 2), "used_gb": round(used, 2), "free_gb": round(free, 2),
            "rec_gb": round(rec_dir_size(), 2), "clips": n,
            "rec_hours": round(n * RECSEG / 3600.0, 2),
            "can_hours": round(gb_to_hours(free), 2),
            "kbps": int(cur_kbps())}


def storage_html():
    total, used, free = rec_dir_space()
    rsz = rec_dir_size()
    n = rec_clip_count()
    rec_h = n * RECSEG / 3600.0
    can_h = gb_to_hours(free)
    pct = int(round(used / total * 100.0)) if total > 0 else 0
    return ("&#128190; 录像盘[%s] %s · 总 %s / 已用 %s / 空闲 %s (%d%%) · 已录 %d 段 %.2fG ≈ %s · 可再录 %s"
            % (rec_mount_label(), html.escape(_rec_dir["d"] or "-"), fmt_gb(total), fmt_gb(used),
               fmt_gb(free), pct, n, rsz, _dur(rec_h), _dur(can_h)))


def ffmpeg_cmd(i):
    rd = _rec_dir["d"]
    rec = _rec[i] and bool(rd)
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error",
           "-f", "v4l2", "-input_format", "mjpeg", "-video_size", "%dx%d" % (W, H),
           "-framerate", str(FPS), "-i", DEVS[i]]
    if rec:
        cmd += ["-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono"]
    cmd += ["-map", "0:v", "-c:v", "copy", "-f", "mpjpeg", "pipe:1"]
    if rec:
        br = "800k"
        for nm, rs, fp, b in PRESETS:
            if rs == _state["res"]:
                br = b
        cmd += ["-map", "0:v", "-map", "1:a",
                "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
                "-vf", "setpts=N/%s/TB,scale=%s" % (_state["fps"], _state["res"]),
                "-r", str(_state["fps"]), "-g", "30", "-b:v", br,
                "-c:a", "aac", "-b:a", "32k", "-shortest",
                "-f", "segment", "-segment_time", str(RECSEG), "-reset_timestamps", "1",
                "-strftime", "1", os.path.join(rd, "cam" + str(i) + "_%Y%m%d_%H%M%S.mp4")]
    return cmd


def capture_loop(i):
    # 开机后等到 up>=CAM_SETTLE 再开流(避开 USB 浪涌, 防过早 probe 卡死 UVC); 之后重启不等待
    try:
        _up = float(open("/proc/uptime").read().split()[0])
    except Exception:
        _up = 0.0
    _st = float(os.environ.get("CAM_SETTLE", "60"))
    time.sleep((_st - _up + i * 3) if _up < _st else i * 2)
    while True:
        try:
            _capture_once(i)
        except Exception as e:
            print("cam%d capture loop err: %r" % (i, e), flush=True)
            time.sleep(2)


def _register(dev):
    if dev in DEVS:
        return
    DEVS.append(dev)
    _subs.append(set()); _last.append(b""); _proc.append(None)
    _rec.append(False)          # 热插拔新增的路默认只看不录(防过载), 可在页面单独开启
    threading.Thread(target=capture_loop, args=(len(DEVS) - 1,), daemon=True).start()
    print("hotplug: %s (index %d)" % (dev, len(DEVS) - 1), flush=True)


def _watch_devs():
    # 热插拔: 新插入的 UVC 摄像头自动加入(不重启服务)
    while True:
        time.sleep(15)
        try:
            for v in sorted(glob.glob("/dev/video*")):
                try:
                    nm = open("/sys/class/video4linux/%s/name" % os.path.basename(v)).read().strip()
                except Exception:
                    continue
                if nm.startswith("zx_"):
                    continue
                if v not in DEVS:
                    _register(v)
        except Exception:
            pass


def _cam_ready(i):
    # 设备存在且真能吐出一帧 MJPEG 才算就绪(开机 USB 枚举可能晚于本服务,
    # 或设备节点已出现但传感器还没开始出流)
    dev = DEVS[i]
    if not os.path.exists(dev):
        return False
    probe = "/tmp/.camprobe%d.jpg" % i
    try:
        if os.path.exists(probe):
            os.remove(probe)
    except Exception:
        pass
    try:
        r = subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
             "-f", "v4l2", "-input_format", "mjpeg",
             "-video_size", "%dx%d" % (W, H), "-i", dev,
             "-frames:v", "1", "-f", "image2", probe],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15)
        return r.returncode == 0 and os.path.getsize(probe) > 1000
    except Exception:
        return False


def _usb_reenum(dev):
    # 设备在但打不开(典型: 某些摄像头 UVC probe 超时 -110 / 掉线) ->
    # 先 USBDEVFS_RESET 硬复位该 USB 设备(会触发重新枚举), 失败再 toggle authorized
    import fcntl
    try:
        real = os.path.realpath("/sys/class/video4linux/%s/device" % os.path.basename(dev))
    except Exception:
        return
    name = None
    for seg in real.split("/"):
        if "-" in seg and seg[0].isdigit() and seg.replace("-", "").replace(".", "").isdigit():
            name = seg
    if not name:
        print("usb_reenum: no usb path for %s (%s)" % (dev, real), flush=True)
        return
    d = "/sys/bus/usb/devices/" + name
    try:
        bus = int(open(d + "/busnum").read())
        num = int(open(d + "/devnum").read())
    except Exception as e:
        print("usb_reenum: read id err %r" % e, flush=True)
        return
    node = "/dev/bus/usb/%03d/%03d" % (bus, num)
    done = False
    try:
        f = os.open(node, os.O_RDWR)
        try:
            fcntl.ioctl(f, 0x5514, 0)      # USBDEVFS_RESET
            done = True
        finally:
            os.close(f)
    except Exception as e:
        print("usb_reset %s err %r" % (node, e), flush=True)
    if not done:
        # 退路: authorized 0/1 重新枚举
        try:
            open(d + "/authorized", "w").write("0"); time.sleep(1.2)
            open(d + "/authorized", "w").write("1")
            done = True
        except Exception as e:
            print("usb_reenum authorized err %r" % e, flush=True)
    if done:
        print("usb_reenum %s (%s) issued" % (node, name), flush=True)
    time.sleep(4)


def _capture_once(ci):
    # 等摄像头"真的能出帧"再开始(开机/掉线后**持续重试**, 不放弃)
    fails = 0
    while True:
        if _cam_ready(ci):
            break
        fails += 1
        if fails % 5 == 0:
            print("cam%d waiting ready…(fail %d)" % (ci, fails), flush=True)
        if fails % 20 == 0:     # 持续失败 -> 尝试重新枚举该 USB 设备
            _usb_reenum(DEVS[ci])
        time.sleep(2)
    ff = "/root/ff.log" if ci == 0 else "/root/ff%d.log" % ci
    try:
        if os.path.getsize(ff) > 524288:
            open(ff, "w").close()
    except Exception:
        pass
    try:
        _fferr = open(ff, "ab")
        p = subprocess.Popen(ffmpeg_cmd(ci), stdout=subprocess.PIPE,
                             stderr=_fferr, bufsize=0)
        _proc[ci] = p
    except Exception as e:
        print("cam%d ffmpeg start fail: %r" % (ci, e), flush=True); time.sleep(2); return
    buf = bytearray()
    fd = p.stdout.fileno()
    STALL = 8.0          # 连续多久收不到新数据就判定卡死并重启
    last_data = time.time()
    while True:
        # 用 select 带超时读, 避免 ffmpeg 卡住(开流失败/掉线)时永久阻塞
        try:
            r, _, _ = select.select([fd], [], [], 2.0)
        except Exception:
            r = [fd]
        if not r:
            if time.time() - last_data > STALL:
                print("cam%d capture stalled %.0fs, restart…" % (ci, time.time() - last_data), flush=True)
                break
            if p.poll() is not None:
                break
            continue
        try:
            chunk = p.stdout.read(8192)
        except Exception:
            chunk = b""
        if not chunk:
            break
        last_data = time.time()
        with _lock:
            subs = list(_subs[ci])
        for q in subs:
            try: q.put_nowait(chunk)
            except Exception: pass
        buf += chunk
        jj = buf.rfind(b"\xff\xd9")
        if jj >= 0:
            kk = buf.rfind(b"\xff\xd8", 0, jj)
            if kk >= 0:
                _last[ci] = bytes(buf[kk:jj + 2])
                try:
                    open("/root/cam.hb" if ci == 0 else "/root/cam%d.hb" % ci, "w").write(str(int(time.time())))
                except Exception: pass
            del buf[:jj + 2]
        if len(buf) > 4 * 1024 * 1024: buf = bytearray()
    try: p.kill()
    except Exception: pass
    if _proc[ci] is p: _proc[ci] = None
    try: p.stdout.close()
    except Exception: pass
    print("cam%d ffmpeg ended, restart…" % ci, flush=True)
    time.sleep(1.5)


def janitor_loop():
    # 循环覆盖: 保留 MINFREE_GB 空闲; 若设了 RLIMIT_GB 再按总量限制
    while True:
        time.sleep(20)
        rd = _rec_dir["d"]
        # 录像盘热插拔: SD 卡回来了优先切回; 当前盘丢了(拔出)则回退内部存储
        try:
            if _is_mount(SD_MNT) and not (rd or "").startswith(SD_MNT):
                nd = pick_rec_dir()
                if nd:
                    _rec_dir["d"] = nd; rd = nd
                    print("rec dir ->", nd, flush=True)
            elif rd and not _dir_writable(rd):
                nd = pick_rec_dir()
                if nd and nd != rd:
                    _rec_dir["d"] = nd; rd = nd
                    print("rec dir fallback ->", nd, flush=True)
        except Exception:
            pass
        if not rd:
            continue
        try:
            files = sorted(glob.glob(os.path.join(rd, "*.mp4")))
            for f in list(files):
                try:
                    if os.path.getsize(f) < 102400:
                        os.remove(f); files.remove(f)
                except Exception:
                    pass
            total = sum(os.path.getsize(f) for f in files) / 1e9
            _tot, _used, free = rec_dir_space()
            _minfree = min(MINFREE_GB, _tot * 0.10) if _tot > 0 else MINFREE_GB
            while files and (free < _minfree or (RLIMIT_GB > 0 and total > RLIMIT_GB)):
                f = files.pop(0)
                try:
                    sz = os.path.getsize(f) / 1e9
                    os.remove(f); total -= sz; free += sz
                except Exception:
                    break
        except Exception:
            pass


CSS = """body{margin:0;background:#0d1420;color:#dce6f5;font-family:sans-serif;text-align:center}
img{width:100%;max-width:1280px;display:block;margin:0 auto;background:#111}
.bar{padding:9px 10px;font-size:14px}a{color:#7fc4ff;margin:0 7px;text-decoration:none}
.btn{display:inline-block;padding:8px 14px;margin:4px 3px;background:#1b2740;border-radius:8px;color:#9fd0ff}
.lst{max-width:900px;margin:8px auto;text-align:left}
.row{display:block;padding:10px 12px;margin:6px 0;background:#141c2b;border:1px solid #24304a;border-radius:8px;color:#dce6f5;text-decoration:none}
.row small{color:#7d8fa8;float:right}
.st{color:#8fa6c2;font-size:13px;padding:4px}
#wrap{position:relative;max-width:1280px;margin:0 auto}
#recbadge{position:absolute;top:12px;left:12px;background:rgba(0,0,0,.55);color:#fff;padding:5px 12px;border-radius:8px;font-size:15px;-webkit-animation:blink 1.2s infinite;animation:blink 1.2s infinite}
#recbadge b{color:#ff3b30}
#recbadge.off{background:rgba(150,80,0,.72);color:#ffe8c2;-webkit-animation:blink 1.6s infinite;animation:blink 1.6s infinite}
#recbadge.off b{color:#ffcc00}
#clk{position:absolute;top:12px;right:12px;background:rgba(0,0,0,.55);color:#fff;padding:5px 12px;border-radius:8px;font-size:16px}
.warn{position:absolute;background:rgba(150,80,0,.8);color:#ffe8c2;padding:5px 12px;border-radius:8px;font-size:15px;-webkit-animation:blink 1.4s infinite;animation:blink 1.4s infinite}
.warn b{color:#ffcc00}
.warn.big{font-size:26px;padding:12px 26px;background:rgba(165,70,0,.88)}
@-webkit-keyframes blink{0%{opacity:1}50%{opacity:.25}100%{opacity:1}}
@keyframes blink{0%{opacity:1}50%{opacity:.25}100%{opacity:1}}
#ov{position:absolute;left:0;top:0;right:0;bottom:0;pointer-events:none;overflow:hidden}
.bx{position:absolute;border:2px solid #0c0;box-sizing:border-box}
.bx span{position:absolute;left:0;top:0;color:#fff;font-size:12px;padding:0 4px;white-space:nowrap;font-family:sans-serif}
.grid{width:100%;max-width:1280px;margin:0 auto;border-collapse:collapse;table-layout:fixed;background:#000}
.cell{width:50%;background:#05070c;position:relative;vertical-align:middle;border:1px solid #1b2740}
.cell img{width:100%;height:auto;display:block}
.cell .no{color:#54637c;font-size:20px;padding:70px 0}
.cap{position:absolute;top:6px;left:8px;background:rgba(0,0,0,.6);color:#cfe0f5;font-size:13px;padding:2px 8px;border-radius:6px;z-index:2}
.rb{position:absolute;top:6px;right:8px;font-size:12px;padding:2px 8px;border-radius:6px;z-index:3}
.rb.on{background:rgba(200,0,0,.72);color:#fff}
.rb.off{background:rgba(70,80,95,.72);color:#e6edf7}
.tm{position:absolute;bottom:6px;right:8px;background:rgba(0,0,0,.55);color:#fff;font-size:13px;padding:2px 8px;border-radius:6px;z-index:3}
.cap,.rb,.tm{pointer-events:none}
.grp{padding:5px 8px;border-top:1px solid #182236;max-width:1280px;margin:0 auto;text-align:left;font-size:13px;line-height:2.0}
.lbl{color:#7d8fa8;font-size:12px;margin:0 5px 0 2px}
.note{color:#8fa6c2;font-size:12px;padding:3px 8px;max-width:1280px;margin:0 auto;text-align:left}
.btn{padding:5px 11px;margin:2px 3px;font-size:13px;white-space:nowrap}
.btn.on{background:#2f7fd0;color:#fff}
.sp{display:inline-block;width:18px}
.sec{display:inline-block;background:#101b2c;border:1px solid #35507f;border-radius:10px;padding:4px 12px;margin:5px 16px 5px 0;vertical-align:middle}
.grp{padding:4px 10px;line-height:2.1;text-align:left;max-width:1280px;margin:0 auto;border-top:1px solid #1a2333}
.lbl{color:#7fa6d8;font-size:12px;margin:0 6px 0 2px} """


def _dur(h):
    if h <= 0:
        return "-"
    if h >= 48:
        return "约%.0f天" % (h / 24.0)
    if h >= 1:
        return "约%.1f时" % h
    return "约%.0f分" % (h * 60)


def warn_html():
    txt = '<b>&#9888;</b> 请注意 未录像'
    spots = [("top:10px;left:10px", "0s", ""),
             ("top:10px;right:10px", "0.4s", ""),
             ("bottom:10px;left:10px", "0.8s", ""),
             ("bottom:10px;right:10px", "1.2s", ""),
             ("top:50%;left:50%;margin-left:-110px;margin-top:-24px", "0.2s", " big")]
    return "".join('<div class="warn%s" style="%s;-webkit-animation-delay:%s;animation-delay:%s">%s</div>'
                    % (cls, pos, d, d, txt) for pos, d, cls in spots)


FRAMES = "/tmp/rf"


def frame_key(fn):
    return hashlib.md5(fn.encode()).hexdigest()[:12]


def start_frames(fn):
    rd = _rec_dir["d"]
    fp = os.path.join(rd, fn)
    key = frame_key(fn)
    d = os.path.join(FRAMES, key)
    if os.path.isdir(d) and os.listdir(d):
        return key
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d, exist_ok=True)
    subprocess.Popen(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", fp,
                      "-vf", "fps=5,scale=640:-1", "-q:v", "6", os.path.join(d, "%05d.jpg")],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return key


def rec_duration(fn):
    fp = os.path.join(_rec_dir["d"], fn)
    try:
        out = subprocess.run(["ffprobe", "-hide_banner", "-loglevel", "error",
                              "-show_entries", "format=duration", "-of", "default=nk=1:nw=1", fp],
                             stdout=subprocess.PIPE, timeout=8).stdout.decode().strip()
        return float(out)
    except Exception:
        return 0.0


def page_frames(fn, key):
    fps = 5
    dur = rec_duration(fn)
    total = int(dur * fps) if dur > 0 else 100000
    return ("""<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>回放</title><style>%s
#v{width:100%%;max-width:960px;background:#000;display:block;margin:8px auto}
#sb{width:70%%;vertical-align:middle}
#pb{font-size:18px;padding:6px 14px}
</style>
<div class="bar"><b>&#9654; %s</b> <a class="btn" href="/rec">返回</a> <span class="st" id="tm"></span></div>
<img id="v">
<div class="bar"><button id="pb" onclick="tog()">Pause</button>
<input id="sb" type="range" min="1" max="%d" value="1" oninput="seek(this.value)" onchange="seek(this.value)"></div>
<div class="st">网页逐帧回放 · 可暂停/拖进度</div>
<script>
var n=1,total=%d,f='%s',playing=true,err=0,dur=%.1f;
var v=document.getElementById('v'),tm=document.getElementById('tm'),sb=document.getElementById('sb'),pb=document.getElementById('pb');
function upd(){sb.value=n;tm.textContent=(n/5).toFixed(1)+' / '+dur.toFixed(0)+'s';}
function show(){v.src='/recframe?f='+f+'&n='+n+'&_='+Date.now();}
v.onload=function(){err=0;if(playing){n++;upd();setTimeout(show,250);}};
v.onerror=function(){err++;if(playing&&n<total&&err<20){setTimeout(show,400);}else{playing=false;pb.textContent='Play';}};
function tog(){playing=!playing;pb.textContent=playing?'Pause':'Play';if(playing)show();}
function seek(x){n=parseInt(x,10);if(n<1)n=1;if(n>total)n=total;upd();show();}
upd();show();
</script>""") % (CSS, fn, total, total, fn, dur)


def dev_name(dev):
    try:
        return open("/sys/class/video4linux/%s/name" % os.path.basename(dev)).read().strip()
    except Exception:
        return dev


def page_grid():
    js = ("function p2(n){return (n<10?'0':'')+n;}"
          "function clk(){var d=new Date();var s=d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate())+' '+p2(d.getHours())+':'+p2(d.getMinutes())+':'+p2(d.getSeconds());"
          "for(var i=0;i<4;i++){var e=document.getElementById('t'+i);if(e)e.textContent=s;}}"
          "setInterval(clk,1000);clk();"
          "function rf(){for(var i=0;i<4;i++){var e=document.getElementById('g'+i);"
          "if(e){e.src='/snap.jpg?cam='+i+'&t='+Date.now();}}}setInterval(rf,1000);"
          "document.addEventListener('click',function(e){var n=e.target;while(n&&n.nodeType==1&&n!==document.body){"
          "if(n.getAttribute&&n.getAttribute('data-cam')!=null){location.href='/view?cam='+n.getAttribute('data-cam');return;}n=n.parentNode;}},true);")
    cells = []
    for i in range(4):
        if i < _N:
            rb = ("<div class='rb on'>&#9679; 录像中</div>" if _rec[i]
                  else "<div class='rb off'>&#9675; 未录</div>")
            cells.append("<td class='cell' data-cam='" + str(i) + "'><a href='/view?cam=" + str(i) + "'>"
                         "<div class='cap'>" + html.escape(dev_name(DEVS[i])) + "</div>" + rb +
                         "<img id='g" + str(i) + "' src='/snap.jpg?cam=" + str(i) + "'>"
                         "<div class='tm' id='t" + str(i) + "'></div></a></td>")
        else:
            cells.append("<td class='cell'><div class='no'>无信号</div><div class='cap'>摄像头" + str(i + 1) +
                         "</div><div class='tm' id='t" + str(i) + "'></div></td>")
    rows = "<tr>" + "".join(cells[0:2]) + "</tr><tr>" + "".join(cells[2:4]) + "</tr>"
    return ("<!doctype html><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>监控</title><style>" + CSS + "</style>"
            "<div class=\"bar\"><b>&#128249; 监控（4 宫格）</b> <span class=\"st\">" + time.strftime("%H:%M:%S") + "</span></div>"
            "<table class='grid'>" + rows + "</table>"
            "<div class=\"bar\"><small>点画面进入单路全屏与设置 · " + str(_N) + " 路在线</small></div>"
            "<div class=\"bar\"><small id=\"stbar\">" + storage_html() + "</small></div>"
            "<div class=\"bar\" id=\"lkbar\"><small>&#128065; 画面检测: 启动中…</small></div>"
            "<script>" + js + _LOOK_JS + _STORAGE_JS + "</script>")


def page_live(mode, cam=0):
    try:
        cam = int(cam)
    except Exception:
        cam = 0
    cam = max(0, min(_N - 1, cam))
    snap = (mode != "mjpeg")
    src = ("/snap.jpg?cam=%d" % cam) if snap else ("/live?cam=%d" % cam)
    js = ("var v=document.getElementById('v');setInterval(function(){v.src='/snap.jpg?cam=%d&t='+new Date().getTime();},500);" % cam
          if snap else "")
    js += ("var c=document.getElementById('clk');function p2(n){return (n<10?'0':'')+n;}"
           "function tick(){var d=new Date();c.textContent=d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate())"
           "+' '+p2(d.getHours())+':'+p2(d.getMinutes())+':'+p2(d.getSeconds());}setInterval(tick,1000);tick();")
    on = _rec[cam]
    name = html.escape(dev_name(DEVS[cam]))
    st = (("&#128308; 录像中" if on else "&#9899; 未录")
          + " &middot; &#128190;%s 空闲 %s &middot; 已录 %.2fG ≈ %s &middot; 可再录 %s" % (
              rec_mount_label(), fmt_gb(disk_free_gb()), rec_dir_size(),
              _dur(rec_clip_count() * RECSEG / 3600.0), _dur(gb_to_hours(disk_free_gb()))))
    # 区块1: 画面
    sec_tab = ""
    if _N > 1:
        _tab = "".join('<a class="btn%s" href="/view?cam=%d">%d %s</a>' % (
            " on" if i == cam else "", i, i + 1, html.escape(dev_name(DEVS[i]))) for i in range(_N))
        sec_tab = '<span class="sec"><span class="lbl">画面</span>' + _tab + '</span> '
    # 区块2: 导航
    sec_nav = ('<span class="sec"><span class="lbl">导航</span>'
               '<a class="btn" href="/">&#8592; 九宫格</a>'
               '<a class="btn" href="/rec">录像回看</a>'
               '<a class="btn" href="/qr">手机扫码</a>'
               '<a class="btn" href="/alerts?cam=' + str(cam) + '">告警截图</a></span>')
    row1 = '<div class="grp">' + sec_tab + sec_nav + '</div>'
    # 区块3: 本路录像
    sec_ctl = ('<span class="sec"><span class="lbl">本路</span>'
               '<a class="btn" href="/recctl?on=' + str(0 if on else 1) + '&cam=' + str(cam) + '">' + ("停止录像" if on else "开始录像") + '</a>'
               '<a class="btn" href="/shot?cam=' + str(cam) + '">抓拍</a>'
               '<a class="btn" href="/view?m=' + ("snap" if not snap else "mjpeg") + '&cam=' + str(cam) + '">' + ("兼容" if not snap else "流畅") + '</a></span>')
    # 区块4: 清晰度
    free = disk_free_gb()
    _q = []
    for nm, rs, fp, b in PRESETS:
        cur = (rs == _state["res"] and fp == _state["fps"])
        try: kbps = float(b.rstrip("k") or 800)
        except Exception: kbps = 800.0
        _q.append('<a class="btn%s" href="/recset?res=%s&fps=%d&cam=%d" title="%s">%s</a>' % (
            " on" if cur else "", rs, fp, cam, _dur(free / (kbps * 0.00045)), nm))
    sec_qual = '<span class="sec"><span class="lbl">清晰度</span>' + "".join(_q) + '</span>'
    # 区块5: 识别
    don = det_on(); ds = det_state()
    _dcam = det_cam(); _rot = det_rotate()
    if not (_rot or (cam == _dcam)):
        sec_det = ('<span class="sec"><span class="lbl">识别</span>在第%d路 '
                   '<a class="btn" href="/detcam?cam=%d">切到本路</a></span>' % (_dcam + 1, cam))
    else:
        _items = ds.get("items") or {}
        itxt = "、".join("%s×%d" % (k, v) for k, v in _items.items()) or "—"
        _sb = []
        for _sz, _nm in ((320, "快"), (416, "标准"), (480, "准"), (640, "高清")):
            _sb.append('<a class="btn%s" href="/detset?sz=%d&cam=%d">%s</a>' % (
                " on" if _sz == det_imgsz() else "", _sz, cam, _nm))
        if len(DEVS) > 1:
            _sb.append('<a class="btn%s" href="/detrotate?on=%d&cam=%d">轮流</a>' % (
                " on" if _rot else "", 0 if _rot else 1, cam))
        sec_det = ('<span class="sec"><span class="lbl">识别%s</span>%s'
                   '<a class="btn" href="/detctl?on=%d&cam=%d">%s</a>'
                   '<a class="btn" href="/alerts?cam=%d">事件</a>'
                   '<span class="lbl">精度</span>%s</span>') % (
            ("(轮流)" if _rot else ""), ("开" if don else "关"),
            0 if don else 1, cam, "关" if don else "开", cam, "".join(_sb))
    row2 = '<div class="grp">' + sec_ctl + sec_qual + sec_det + '</div>'
    badge = ('<div id="recbadge"><b>&#9679;</b> 录像中</div>' if on else warn_html())
    dimg = ""
    if (_rot or (cam == _dcam)):
        if os.path.exists(DET_JPG):
            dimg = '<div class="note">&#129504; 识别画面（本地 YOLO）</div><div id="wrap"><img id="d" src="/det.jpg"></div>'
            js += ("var dd=document.getElementById('d');if(dd){setInterval(function(){"
                   "dd.src='/det.jpg?t='+Date.now();},5000);}")
        if don:
            js += ("var TGT={'person':1,'car':1,'bus':1,'truck':1,'motorcycle':1,'bicycle':1,'dog':1,'cat':1};"
                   "function drawDet(){var x=new XMLHttpRequest();x.onload=function(){"
                   "var ov=document.getElementById('ov');if(!ov)return;var d={};try{d=JSON.parse(x.responseText||'{}');}catch(e){}"
                   "var now=Date.now()/1000;if(!d.ts||now-d.ts>30){ov.innerHTML='';return;}"
                   "var ow=(d.scale&&d.scale[0])||1280,oh=(d.scale&&d.scale[1])||720,s='';"
                   "(d.dets||[]).forEach(function(o){var b=o.box,c=TGT[o.cls]?'#ff3b30':'#22cc22';"
                   "s+='<div class=\"bx\" style=\"left:'+(b[0]/ow*100)+'%;top:'+(b[1]/oh*100)+'%;width:'+(b[2]/ow*100)+'%;height:'+(b[3]/oh*100)+'%;border-color:'+c+'\"><span style=\"background:'+c+'\">'+o.cls+' '+o.conf.toFixed(2)+'</span></div>';});"
                   "ov.innerHTML=s;};x.open('GET','/det.json?t='+Date.now(),true);x.send();}"
                   "setInterval(drawDet,2000);drawDet();")
    info = ("自动录制" if on else "仅直播") + ((" &middot; " + tunnel_url()) if tunnel_url() else "")
    return ("""<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>摄像头</title><style>%s</style>
<div class="bar"><b>&#128249; %s</b> <span class="st">%s</span></div>
%s
%s
<div class="note">&#128257; 循环录制：空间不足时自动覆盖最旧的录像（保留约 %.1f GB 空闲）</div>
<div id="wrap"><img id="v" src="%s">%s<div id="ov"></div><div id="clk"></div></div>
%s
<div class="bar"><small>%s &middot; 直播 %dx%d &middot; %s</small></div>
<script>%s</script>""" % (
        CSS, name, st, row1, row2, MINFREE_GB, src, badge, dimg,
        name, W, H, info, js))

def _complete(fp):
    # mp4 写完时 moov 在文件末尾; 没写完的段没有 -> 判定为不完整
    try:
        sz = os.path.getsize(fp)
        if sz < 102400:
            return False
        with open(fp, "rb") as f:
            f.seek(max(0, sz - 262144))
            return b"moov" in f.read()
    except Exception:
        return False


def page_rec(query=""):
    rd = _rec_dir["d"]
    form = ("<form action='/rec' method='get' style='padding:6px'>"
            "&#128338; 时间检索 <input name='q' value='%s' placeholder='时:分 如 0907 / 日期 20260930' "
            "style='font-size:15px;padding:4px;width:230px'> <button>查找</button> "
            "<a class='btn' href='/rec'>全部</a></form>") % html.escape(query or "")
    if not rd:
        return "<!doctype html><meta charset=utf-8><style>%s</style><p class=st>无录像目录</p><p><a href='/'>返回</a></p>" % CSS
    files = sorted(glob.glob(os.path.join(rd, "*.mp4")), reverse=True)
    rows = []
    now = time.time()
    inprog = None
    qd = "".join(ch for ch in (query or "") if ch.isdigit())
    if any(_rec) and files:          # 只有录像中, 最新那段才可能未写完
        try:
            if now - os.path.getmtime(files[0]) < RECSEG + 5:
                inprog = files[0]
        except Exception:
            pass
    for f in files[:2000]:
        n = os.path.basename(f)
        try: sz = os.path.getsize(f)
        except Exception: sz = 0
        if sz < 102400:            # <100KB = 重启残片, 不显示
            continue
        dig = n.replace("cam_", "").replace(".mp4", "")
        if qd:
            ymd, hhmm = dig[:8], (dig[9:13] if len(dig) >= 13 else "")
            if len(qd) == 4:
                if qd != hhmm:
                    continue
            elif len(qd) == 8:
                if qd != ymd:
                    continue
            elif qd not in dig:
                continue
        szm = sz / 1e6
        t = n.replace("cam_", "").replace(".mp4", "")
        if len(t) == 15:
            t = "%s-%s-%s %s:%s:%s" % (t[0:4], t[4:6], t[6:8], t[8:10], t[10:12], t[12:14])
        if f == inprog:
            rows.append("<div class='row'>⏺ %s <small>录制中… 稍后</small></div>" % t)
        elif not _complete(f):
            continue                       # 没写完/残片, 不显示
        else:
            rows.append("<a class='row' href='/recplay?f=%s'>&#9654; %s<small>%.1f MB</small></a>" % (n, t, szm))
    return ("""<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>录像</title><style>%s</style>
<div class="bar"><b>&#127909; 录像回看</b> <a class="btn" href="/">返回直播</a>
 <span class="st">%s &middot; %d 段 &middot; %.2f GB</span></div>
%s
<div class="lst">%s</div>""" % (CSS, rd, len(files), rec_dir_size(), form, "".join(rows) or "<p class=st>没找到录像</p>"))


_qrpng = {}


def _png_gray(rows, w, h):
    """纯标准库写 8-bit 灰度 PNG(不依赖 PIL)"""
    import struct, zlib
    raw = bytearray()
    for r in rows:
        raw.append(0); raw.extend(r)
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))


def qr_png(text, scale=6, border=4):
    """二维码 PNG (这台盒子的旧 WebView 渲染不了内联 SVG, 但能显示 PNG 图片)"""
    if not QrCode:
        return None, 0
    key = (text, scale, border)
    if key not in _qrpng:
        qr = QrCode.encode_text(text, QrCode.Ecc.MEDIUM)
        n = qr.get_size(); dim = (n + border * 2) * scale
        rows = []
        for y in range(n + border * 2):
            line = bytearray()
            for x in range(n + border * 2):
                inr = (border <= x < border + n) and (border <= y < border + n)
                dark = qr.get_module(x - border, y - border) if inr else False
                line.extend((b"\x00" * scale) if dark else (b"\xff" * scale))
            rows.extend([line] * scale)
        _qrpng[key] = (_png_gray(rows, dim, dim), dim)
    return _qrpng[key]


def qr_svg(text, scale=6, border=2):
    if not QrCode:
        return "<p>无 qrcodegen 库</p>"
    qr = QrCode.encode_text(text, QrCode.Ecc.MEDIUM)
    n = qr.get_size(); dim = (n + border * 2) * scale
    d = []
    for y in range(n):
        for x in range(n):
            if qr.get_module(x, y):
                d.append("M%d %dh%dv%dhz" % ((x + border) * scale, (y + border) * scale, scale, scale))
    return ("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 %d %d' width='%d' height='%d'>"
            "<rect width='%d' height='%d' fill='#fff'/><path d='%s' fill='#000'/></svg>") % (
        dim, dim, dim, dim, dim, dim, "".join(d))


def tunnel_url():
    try:
        return open(URLFILE).read().strip()
    except Exception:
        return ""


def _qrbox(url, extra=""):
    png, dim = qr_png(url)
    if not png:
        return "<p>无 qrcodegen 库</p>"
    return ("<div style='margin:6px 0'><div style='background:#fff;display:inline-block;padding:8px;border-radius:10px'>"
            "<img src='/qr.png?u=%s' width='%d' height='%d' alt='QR' style='display:block'></div>"
            "<div style='font-size:14px;word-break:break-all'>%s</div>%s</div>") % (url, dim, dim, url, extra)


def page_qr():
    ip = local_ip(); url = "http://%s:%d/" % (ip, PORT)
    t = tunnel_url()
    blocks = "<div style='display:inline-block;vertical-align:top;margin:4px 16px'><h4 style='margin:6px 0 2px'>&#127968; 家里</h4>" + _qrbox(url) + "</div>"
    if t:
        cred = (("<div style='font-size:15px;margin-top:4px'>用户名 <b>%s</b> &nbsp; 密码 <b>%s</b></div>"
                 % (AUTH["user"], AUTH["pass"])) if AUTH["pass"] else "")
        blocks += "<div style='display:inline-block;vertical-align:top;margin:4px 16px'><h4 style='margin:6px 0 2px'>&#127760; 互联网</h4>" + _qrbox(t, cred) + "</div>"
    return ("""<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>扫码看</title><style>%s</style>
<div style="padding:14px"><h3>&#128241; 手机扫码看画面</h3>
%s
<p style="font-size:17px;margin:2px 0 8px">用<b>微信</b>或<b>浏览器</b>「扫一扫」，即可观看</p>
<p class="st">家里: 手机连同一 WiFi 即可；互联网: 不在家也能看(需密码)</p>
<p><a class="btn" href="/">返回</a></p></div>""" % (CSS, blocks))


def page_play(fn):
    fn = os.path.basename(fn)
    return ("""<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>播放</title><style>%s
video{width:100%%;max-width:1000px;background:#000;display:block;margin:8px auto}</style>
<div class="bar"><b>&#9654; %s</b></div>
<video src="/recfile?f=%s" controls autoplay playsinline></video>
<div class="bar"><a class="btn" href="/sysplay?f=%s">&#128252; 用系统播放器打开</a>
<a class="btn" href="/recfile?f=%s">下载</a><a class="btn" href="/rec">返回</a></div>
<div class="st">若上方黑屏无画面，请点「用系统播放器打开」</div>""") % (CSS, fn, fn, fn, fn)


def sysplay(fn):
    rd = _rec_dir["d"] or ""
    apath = os.path.join(rd, fn).replace("/mnt/sdcard", "/storage/emulated/0").replace("/mnt/usb", "/storage/usb")
    try:
        import urllib.request as _u
        _u.urlopen("http://127.0.0.1:8899/cgi-bin/run?app=play&f=" + _u.quote(apath), timeout=6).read()
    except Exception:
        pass


from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _authed(self):
        # 本机直连(盒子自己的 WebView / 抽帧)且不来自隧道 -> 免密; 其余(局域网/公网)要密码
        xff = self.headers.get("CF-Connecting-IP") or self.headers.get("X-Forwarded-For")
        if self.client_address[0] in ("127.0.0.1", "::1") and not xff:
            return True
        if not AUTH["pass"]:
            return True
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            try:
                u, _, p = base64.b64decode(h[6:]).decode("utf-8", "ignore").partition(":")
                return u == AUTH["user"] and p == AUTH["pass"]
            except Exception:
                return False
        return False

    def _need_auth(self):
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="cam"')
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _hdr(self, code, ctype, extra=None):
        self.send_response(code); self.send_header("Content-Type", ctype)
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.end_headers()
    def _html(self, s):
        b = s.encode("utf-8")
        self._hdr(200, "text/html; charset=utf-8", {"Content-Length": str(len(b)), "Cache-Control": "no-store"})
        self.wfile.write(b)
    def _redir(self, to):
        self.send_response(303); self.send_header("Location", to); self.end_headers()
    def _stream_file(self, fp):
        if not os.path.isfile(fp):
            self._hdr(404, "text/plain"); self.wfile.write(b"not found"); return
        size = os.path.getsize(fp); start, end, code = 0, size - 1, 200
        extra = {"Accept-Ranges": "bytes", "Content-Type": "video/mp4", "Cache-Control": "no-cache"}
        rng = self.headers.get("Range")
        if rng and rng.startswith("bytes="):
            try:
                a, _, b = rng[6:].split(",")[0].partition("-")
                if a: start = int(a)
                if b: end = int(b)
                if start > end or start >= size: raise ValueError
                code = 206; extra["Content-Range"] = "bytes %d-%d/%d" % (start, end, size)
            except Exception:
                start, end, code = 0, size - 1, 200
        length = end - start + 1
        self.send_response(code); self.send_header("Content-Length", str(length))
        for k, v in extra.items(): self.send_header(k, v)
        self.end_headers()
        remain = length
        with open(fp, "rb") as fh:
            fh.seek(start)
            while remain > 0:
                c = fh.read(min(262144, remain))
                if not c: break
                try: self.wfile.write(c)
                except Exception: break
                remain -= len(c)
    def do_GET(self):
        path, _, qs = self.path.partition("?")
        q = dict(kv.split("=", 1) for kv in qs.split("&") if "=" in kv) if qs else {}
        authed = self._authed()
        # 告警图片允许用 alert.cfg 里的 secret token 直接看(便于手机推送里直接显示)
        if not authed and path.startswith("/alert/") and q.get("k") and q.get("k") == alert_token() and alert_token():
            authed = True
        if not authed:
            self._need_auth(); return
        if path in ("/", "/index.html"):
            self._html(page_grid())
        elif path == "/view":
            self._html(page_live(q.get("m", "snap"), q.get("cam", "0")))
        elif path == "/recctl":
            try: ci = int(q.get("cam", "0"))
            except Exception: ci = 0
            if not (0 <= ci < _N): ci = 0
            _rec[ci] = (q.get("on") == "1")
            save_state()
            restart_capture(ci)
            self._redir("/view?cam=%d" % ci)
        elif path == "/recset":
            rs = q.get("res", "")
            try: fp = int(q.get("fps", "0"))
            except Exception: fp = 0
            try: rc = int(q.get("cam", "0"))
            except Exception: rc = 0
            for nm, r, f, b in PRESETS:
                if r == rs and f == fp:
                    _state["res"] = r; _state["fps"] = f; save_state()
                    for _i in range(_N): restart_capture(_i)
                    break
            self._redir("/view?cam=%d" % max(0, min(_N - 1, rc)))
        elif path == "/qr":
            self._html(page_qr())
        elif path == "/qr.png":
            u = q.get("u", "") or ("http://%s:%d/" % (local_ip(), PORT))
            if not u.startswith("http"):
                u = "http://%s:%d/" % (local_ip(), PORT)
            png, _d = qr_png(u)
            if png:
                self._hdr(200, "image/png", {"Content-Length": str(len(png)), "Cache-Control": "no-store"})
                self.wfile.write(png)
            else:
                self._hdr(404, "text/plain"); self.wfile.write(b"no qrcodegen")
        elif path == "/shot":
            try: ci = int(q.get("cam", "0"))
            except Exception: ci = 0
            self._html(page_shot(max(0, min(_N - 1, ci))))
        elif path == "/det.jpg":
            try:
                with open(DET_JPG, "rb") as fh: d = fh.read()
            except Exception:
                self._hdr(404, "text/plain"); self.wfile.write(b"no det image"); return
            self._hdr(200, "image/jpeg", {"Content-Length": str(len(d)), "Cache-Control": "no-store"})
            self.wfile.write(d)
        elif path == "/det.json":
            try:
                with open(DET_JSON, "rb") as fh: d = fh.read()
            except Exception:
                d = b"{}"
            self._hdr(200, "application/json", {"Content-Length": str(len(d)), "Cache-Control": "no-store"})
            self.wfile.write(d)
        elif path == "/detctl":
            if q.get("on") == "1":
                det_start()
            else:
                det_stop()
            self._redir("/view?cam=%d" % det_cam())
        elif path == "/look.json":
            try:
                with open("/root/look.json", "rb") as fh: d = fh.read()
            except Exception:
                d = b"{}"
            self._hdr(200, "application/json", {"Content-Length": str(len(d)), "Cache-Control": "no-store"})
            self.wfile.write(d)
        elif path == "/cams.json":
            d = json.dumps({"n": _N, "names": [dev_name(x) for x in DEVS], "rec": [bool(x) for x in _rec]}).encode()
            self._hdr(200, "application/json", {"Content-Length": str(len(d)), "Cache-Control": "no-store"})
            self.wfile.write(d)
        elif path == "/storage.json":
            d = json.dumps(storage_info()).encode()
            self._hdr(200, "application/json", {"Content-Length": str(len(d)), "Cache-Control": "no-store"})
            self.wfile.write(d)
        elif path == "/detrotate":
            on = "1" if q.get("on") == "1" else "0"
            try:
                cur = {}
                for ln in open("/root/det.set"):
                    k, _, v = ln.strip().partition("=")
                    if k: cur[k] = v
                cur["rotate"] = on
                open("/root/det.set", "w").write("".join("%s=%s\n" % (k, v) for k, v in cur.items()))
            except Exception:
                pass
            try: c3 = int(q.get("cam", "0"))
            except Exception: c3 = 0
            self._redir("/view?cam=%d" % c3)
        elif path == "/detcam":
            try: c2 = int(q.get("cam", "0"))
            except Exception: c2 = 0
            try:
                cur = {}
                for ln in open("/root/det.set"):
                    k, _, v = ln.strip().partition("=")
                    if k: cur[k] = v
                cur["cam"] = str(c2)
                cur["rotate"] = "0"      # 手动指定某路 -> 关闭轮流
                open("/root/det.set", "w").write("".join("%s=%s\n" % (k, v) for k, v in cur.items()))
            except Exception:
                pass
            self._redir("/view?cam=%d" % c2)
        elif path == "/detset":
            sz = q.get("sz", "")
            if sz in ("320", "416", "480", "640"):
                try:
                    cur = {}
                    for ln in open("/root/det.set"):
                        k, _, v = ln.strip().partition("=")
                        if k: cur[k] = v
                    cur["imgsz"] = sz
                    open("/root/det.set", "w").write("".join("%s=%s\n" % (k, v) for k, v in cur.items()))
                except Exception:
                    pass
            self._redir("/view?cam=%d" % det_cam())
        elif path == "/det_events":
            self._html(page_events())
        elif path == "/alerts":
            _cm = int(q["cam"]) if q.get("cam", "").isdigit() else None
            self._html(page_alerts(q.get("all") == "1", _cm))
        elif path.startswith("/alert/"):
            fn = os.path.basename(path[len("/alert/"):])
            fp = os.path.join(ALERT_DIR, fn)
            try:
                with open(fp, "rb") as fh: d = fh.read()
            except Exception:
                self._hdr(404, "text/plain"); self.wfile.write(b"no"); return
            self._hdr(200, "image/jpeg", {"Content-Length": str(len(d)), "Cache-Control": "no-store"})
            self.wfile.write(d)
        elif path == "/rec":
            self._html(page_rec(q.get("q", "")))
        elif path == "/recplay":
            fn = os.path.basename(q.get("f", ""))
            host = self.headers.get("Host", "")
            try:
                key = start_frames(fn)
                self._html(page_frames(fn, key))     # 网页逐帧回放(盒子上也能看)
            except Exception:
                sysplay(fn); self._redir("/rec")
        elif path == "/recframe":
            fn = os.path.basename(q.get("f", ""))
            try: n = int(q.get("n", "0"))
            except Exception: n = 0
            p = os.path.join(FRAMES, frame_key(fn), "%05d.jpg" % n)
            if os.path.isfile(p):
                with open(p, "rb") as fh: d = fh.read()
                self._hdr(200, "image/jpeg", {"Content-Length": str(len(d)), "Cache-Control": "no-store"})
                self.wfile.write(d)
            else:
                self._hdr(404, "text/plain"); self.wfile.write(b"no")
        elif path == "/recfile":
            n = os.path.basename(q.get("f", "")); rd = _rec_dir["d"]
            self._stream_file(os.path.join(rd, n) if rd else "")
        elif path == "/sysplay":
            sysplay(os.path.basename(q.get("f", "")))
            self._redir("/rec")
        elif path == "/snap.jpg":
            try: ci = int(q.get("cam", "0"))
            except Exception: ci = 0
            ci = max(0, min(_N - 1, ci))
            d = _last[ci]
            if not d: self._hdr(503, "text/plain"); self.wfile.write(b"no frame"); return
            self._hdr(200, "image/jpeg", {"Content-Length": str(len(d)), "Cache-Control": "no-store"}); self.wfile.write(d)
        elif path == "/live":
            try: ci = int(q.get("cam", "0"))
            except Exception: ci = 0
            ci = max(0, min(_N - 1, ci))
            self._hdr(200, "multipart/x-mixed-replace; boundary=ffmpeg", {"Cache-Control": "no-store"})
            qq = queue.Queue(maxsize=200)
            with _lock: _subs[ci].add(qq)
            try:
                while True:
                    try: c = qq.get(timeout=10)
                    except queue.Empty: break
                    self.wfile.write(c)
            except Exception: pass
            finally:
                with _lock: _subs[ci].discard(qq)
        else:
            self._hdr(404, "text/plain"); self.wfile.write(b"?")


if __name__ == "__main__":
    import fcntl as _f
    _lk = open("/run/cam.lock", "w")
    try:
        _f.flock(_lk, _f.LOCK_EX | _f.LOCK_NB)
    except OSError:
        print("another cam running; exit", flush=True); os._exit(0)
    load_state()
    _rec_dir["d"] = pick_rec_dir()
    print("rec dir =", _rec_dir["d"], "devs=", DEVS, "rec=", _rec, flush=True)
    for _ci in range(_N):
        threading.Thread(target=capture_loop, args=(_ci,), daemon=True).start()
    threading.Thread(target=_watch_devs, daemon=True).start()
    threading.Thread(target=janitor_loop, daemon=True).start()
    time.sleep(0.3)
    print("cam on 0.0.0.0:%d devs=%s %dx%d" % (PORT, ",".join(DEVS), W, H), flush=True)
    try:
        ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
    except OSError as e:
        print("bind %d failed (%s) - another cam.py running?" % (PORT, e), flush=True)
