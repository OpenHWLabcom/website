#!/usr/bin/env python3
# 监控 Agent (盒子本地自洽运行, 不依赖主机)
#   1) 服务守护: cam / det / transfer / boxctl / sshd / 公网隧道 —— 挂了自动拉起
#   2) 感知守护: cam.hb(直播帧) / det.json(识别) 过期 -> 重启对应服务
#   3) 资源巡检: 磁盘/内存/负载 超阈值 -> 告警
#   4) 异常上报: 推送手机 (复用 /root/alert.cfg 的 provider)
#   5) 日报: 每天 SUMMARY_HH:MM 推一条状态 + 当日告警统计
# 日志: /root/monitor.log
import os, time, socket, subprocess, glob, json, re, urllib.request, urllib.parse

CAM_HB   = "/root/cam.hb"
DET_JSON = "/root/det.json"
TUN_URL  = "/root/tunnel.url"
EVENTS   = "/mnt/sdcard/alerts/events.log"
CFG      = "/root/alert.cfg"
LOG      = "/root/monitor.log"

CHECK     = 30            # 巡检间隔(秒)
CAM_STALE = 180           # 直播无帧多久判死
DET_STALE = 90            # 识别多久没更新判死
ALERT_CD  = 1800          # 同类告警推送冷却(秒)
SUMMARY_HH = int(os.environ.get("SUMMARY_HH", "12"))   # 每天几点推日报(盒子时钟=UTC; 12=北京/新加坡20:00)
DISK_MIN_GB = 0.20        # 磁盘少于该值告警
MEM_MIN_MB  = 30          # 可用内存少于该值告警

PY = "/usr/bin/python3"
SSD = "/sbin/start-stop-daemon"

SERVICES = [
    ("cam",      "/run/cam.pid",      8891, [SSD, "--start", "--background", "--make-pidfile", "--pidfile", "/run/cam.pid",      "--exec", PY, "--", "/root/cam.py"]),
    ("det",      "/run/det.pid",      0,    [SSD, "--start", "--background", "--make-pidfile", "--pidfile", "/run/det.pid",      "--exec", PY, "--", "/root/det.py"]),
    ("transfer", "/run/transfer.pid", 8890, [SSD, "--start", "--background", "--make-pidfile", "--pidfile", "/run/transfer.pid", "--exec", PY, "--", "/root/transfer.py"]),
    ("look",     "/run/look.pid",      0,    [SSD, "--start", "--background", "--make-pidfile", "--pidfile", "/run/look.pid",      "--exec", PY, "--", "/root/look.py"]),
    ("boxctl",   "/run/boxctl.pid",   8899, [SSD, "--start", "--background", "--make-pidfile", "--pidfile", "/run/boxctl.pid",   "--exec", PY, "--", "/root/boxctl.py"]),
]

_last_push = {}


def log(msg):
    line = "%s  %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        with open(LOG, "a") as f:
            f.write(line + "\n")
        if os.path.getsize(LOG) > 512 * 1024:
            os.replace(LOG, LOG + ".1")
    except Exception:
        pass
    print(line, flush=True)


def cfg():
    d = {}
    try:
        for ln in open(CFG):
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, _, v = ln.partition("=")
                d[k.strip()] = v.strip()
    except Exception:
        pass
    return d


def notify(title, msg):
    c = cfg()
    prov = (c.get("provider") or "").lower()
    try:
        if prov == "ntfy":
            base = (c.get("ntfy_url") or "https://ntfy.sh").rstrip("/")
            body = json.dumps({"topic": c.get("ntfy_topic", ""), "title": title, "message": msg,
                               "tags": ["warning"]}, ensure_ascii=False).encode("utf-8")
            return urllib.request.urlopen(urllib.request.Request(base, body, {"Content-Type": "application/json; charset=utf-8"}), timeout=10).read()[:120]
        if prov == "serverchan":
            u = "https://sctapi.ftqq.com/%s.send?title=%s&desp=%s" % (c.get("serverchan_key", ""), urllib.parse.quote(title), urllib.parse.quote(msg))
            return urllib.request.urlopen(u, timeout=10).read()[:120]
        if prov == "bark":
            u = "%s/%s/%s/%s?group=cam" % ((c.get("bark_url") or "https://api.day.app").rstrip("/"), c.get("bark_key", ""), urllib.parse.quote(title), urllib.parse.quote(msg))
            return urllib.request.urlopen(u, timeout=10).read()[:120]
        if prov == "pushplus":
            return urllib.request.urlopen(urllib.request.Request("http://www.pushplus.plus/send", json.dumps({"token": c.get("pushplus_token", ""), "title": title, "content": msg}).encode(), {"Content-Type": "application/json"}), timeout=10).read()[:120]
        if prov == "webhook":
            return urllib.request.urlopen(urllib.request.Request(c.get("webhook_url", ""), json.dumps({"title": title, "message": msg, "ts": int(time.time())}).encode(), {"Content-Type": "application/json"}), timeout=10).read()[:120]
    except Exception as e:
        return ("err %r" % e)
    return "no provider"


def alert(key, title, msg):
    # 带冷却的推送
    now = time.time()
    if now - _last_push.get(key, 0) < ALERT_CD:
        return
    _last_push[key] = now
    r = notify(title, msg)
    log("ALERT %s | %s -> %r" % (key, title, r))


def port_open(p):
    s = socket.socket(); s.settimeout(2)
    try:
        s.connect(("127.0.0.1", p)); return True
    except Exception:
        return False
    finally:
        try: s.close()
        except Exception: pass


def pid_alive(pf):
    try:
        os.kill(int(open(pf).read().strip()), 0); return True
    except Exception:
        return False


def start(cmd):
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def mem_avail_mb():
    try:
        for ln in open("/proc/meminfo"):
            if ln.startswith("MemAvailable:"):
                return int(ln.split()[1]) / 1024.0
    except Exception:
        pass
    return 9999


def disk_free_gb(p):
    try:
        st = os.statvfs(p)
        return st.f_bavail * st.f_frsize / 1e9
    except Exception:
        return 99


SD_DEV = "/dev/block/mmcblk1p1"
SD_MNT = "/mnt/sdext"


def rec_disk():
    # 优先用外置 SD/TF 卡, 其次 U 盘, 最后内部存储
    try:
        mnts = set(ln.split()[1] for ln in open("/proc/mounts") if len(ln.split()) > 1)
    except Exception:
        mnts = set()
    for p in (SD_MNT, "/mnt/usb", "/mnt/sdcard"):
        if p in mnts:
            return p
    return "/mnt/sdcard"


def ensure_sd():
    # SD 卡在但没挂载 -> 自动挂上(热插拔/掉挂兜底)
    # 默认不启用; 确认卡可靠后 touch /data/use_sd 开启(避免坏卡挂死录像系统)
    if not os.path.exists("/proc/1/root/data/use_sd"):
        return
    if not os.path.exists(SD_DEV):
        return
    if rec_disk() == SD_MNT:
        return
    try:
        os.makedirs(SD_MNT, exist_ok=True)
    except Exception:
        pass
    try:
        subprocess.run(["mount", "-o", "rw", SD_DEV, SD_MNT],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
        if rec_disk() == SD_MNT:
            log("SD card mounted at %s" % SD_MNT)
    except Exception as e:
        log("ensure_sd err %r" % e)


def _and_env():
    bp = ""
    try:
        bp = re.search(r'"BOOTCLASSPATH": "([^"]+)"', open("/root/boxctl.py").read()).group(1)
    except Exception:
        pass
    e = dict(os.environ)
    e.update({"ANDROID_ROOT": "/system", "ANDROID_DATA": "/data",
              "LD_LIBRARY_PATH": "/vendor/lib:/system/lib",
              "PATH": "/system/bin:/system/xbin:/sbin:/vendor/bin", "BOOTCLASSPATH": bp})
    return e


def and_sh(c):
    try:
        return subprocess.run(["/usr/sbin/chroot", "/proc/1/root", "/system/bin/sh", "-c", c],
                              env=_and_env(), stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                              timeout=20).stdout.decode("utf8", "ignore")
    except Exception:
        return ""


def check_ui():
    # 屏幕黑屏/桌面丢焦点 -> 重拉桌面 + 监控页
    out = and_sh("dumpsys window 2>/dev/null | grep mCurrentFocus")
    if "mCurrentFocus=null" in out:
        log("桌面 focus lost -> relaunch")
        and_sh("am start -a android.intent.action.MAIN -c android.intent.category.HOME")
        time.sleep(2)
        and_sh("am start -n com.openhardwarelab.desktop/.WebActivity --es url 'http://127.0.0.1:8891/'")


def uptime_s():
    try:
        return float(open("/proc/uptime").read().split()[0])
    except Exception:
        return 99999


def load1():
    try:
        return float(open("/proc/loadavg").read().split()[0])
    except Exception:
        return 0.0


def today_alerts():
    try:
        d = time.strftime("%Y-%m-%d")
        n = sum(1 for ln in open(EVENTS, errors="ignore") if ln.startswith(d))
        return n
    except Exception:
        return 0


def check_camera():
    try:
        hb = int(open(CAM_HB).read().strip())
    except Exception:
        hb = 0
    if not hb:
        return True          # 还没有心跳(刚启动/未采集), 不判定为异常
    age = time.time() - hb
    if age > CAM_STALE:
        log("camera stale %.0fs -> restart cam" % age)
        subprocess.run(["pkill", "-9", "-f", "^/usr/bin/python3 /root/cam.py"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["pkill", "-9", "-f", "^ffmpeg -hide_banner"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(2)
        start([SSD, "--start", "--background", "--make-pidfile", "--pidfile", "/run/cam.pid", "--exec", PY, "--", "/root/cam.py"])
        alert("cam", "监控异常: 摄像头无画面", "摄像头 %ds 无新帧，已自动重启采集。若持续请检查 USB 口/供电。" % age)
        return False
    return True


def check_detect():
    try:
        ts = int(json.load(open(DET_JSON)).get("ts", 0))
    except Exception:
        ts = 0
    if time.time() - ts > DET_STALE:
        log("det stale -> restart det")
        subprocess.run(["pkill", "-9", "-f", "^/usr/bin/python3 /root/det.py"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(2)
        start([SSD, "--start", "--background", "--make-pidfile", "--pidfile", "/run/det.pid", "--exec", PY, "--", "/root/det.py"])
        return False
    return True


def tunnel_running():
    for d in glob.glob("/proc/[0-9]*"):
        try:
            c = open(d + "/cmdline", "rb").read().replace(b"\0", b" ").decode("utf8", "ignore")
        except Exception:
            continue
        if "cloudflared" in c and "tunnel" in c:
            return True
    return False


def check_tunnel():
    try:
        ok = os.path.getsize(TUN_URL) > 5
    except Exception:
        ok = False
    if tunnel_running() and ok:
        return True
    log("tunnel down/url missing -> restart tunnel.sh")
    for d in glob.glob("/proc/[0-9]*"):
        try:
            c = open(d + "/cmdline", "rb").read().replace(b"\0", b" ").decode("utf8", "ignore")
        except Exception:
            continue
        if "/root/tunnel.sh" in c or ("cloudflared" in c and "tunnel" in c):
            try: os.kill(int(d.split("/")[-1]), 9)
            except Exception: pass
    time.sleep(2)
    start([SSD, "--start", "--background", "--make-pidfile", "--pidfile", "/run/tunnel.pid", "--exec", "/root/tunnel.sh"])
    return False


def daily_summary(t):
    d = time.strftime("%Y-%m-%d", t)
    if time.strftime("%H", t) == "%02d" % SUMMARY_HH and _last_push.get("daily") != d:
        _last_push["daily"] = d
        cam_ok = "OK" if (time.time() - (int(open(CAM_HB).read().strip() or 0) if os.path.exists(CAM_HB) else 0)) < CAM_STALE else "无画面"
        det_ok = "开" if os.path.exists("/root/det.json") else "?"
        msg = ("%s 日报\n今日告警: %d 次\n摄像头: %s · 识别: %s\n录像盘 %s 剩余 %.2f GB · 可用内存 %.0f MB · 负载 %.1f"
               % (d, today_alerts(), cam_ok, det_ok, rec_disk(), disk_free_gb(rec_disk()), mem_avail_mb(), load1()))
        notify("监控日报 " + d, msg)
        log("daily summary sent")


def main():
    log("monitor agent start (check=%ds)" % CHECK)
    last = {}
    while True:
        try:
            now = time.time()
            # 服务守护(按端口判断, 避免 pidfile 陈旧导致重复拉起)
            for name, pf, port, cmd in SERVICES:
                alive = port_open(port) if port else pid_alive(pf)
                if not alive:
                    log("%s down -> start" % name)
                    start(cmd)
                    time.sleep(3)
                    alive2 = port_open(port) if port else pid_alive(pf)
                    if not alive2:
                        alert("svc_" + name, "监控异常: %s 服务未运行" % name, "%s 重启失败，请检查。日志 /root/monitor.log" % name)
            if not port_open(22):
                start(["/usr/sbin/sshd"])
            # 感知守护（开机 5 分钟内不判定，避免拿上一次的旧心跳误杀刚启动的采集）
            if uptime_s() > 300:
                check_camera()
                check_detect()
            check_tunnel()
            # 资源巡检
            ensure_sd()
            _rd = rec_disk()
            if disk_free_gb(_rd) < DISK_MIN_GB:
                alert("disk", "监控异常: 录像盘将满", "录像盘 %s 剩余不足 %.2f GB，已启用循环覆盖删除最旧录像。" % (_rd, disk_free_gb(_rd)))
            if mem_avail_mb() < MEM_MIN_MB:
                alert("mem", "监控异常: 内存不足", "可用内存仅 %.0f MB，可能影响录像/识别。" % mem_avail_mb())
            daily_summary(time.localtime())
            _n = _last_push.get("ui", 0) + 1
            _last_push["ui"] = _n
            if _n % 2 == 0:          # 约每 60s 查一次界面
                check_ui()
        except Exception as e:
            log("loop err %r" % e)
        time.sleep(CHECK)


if __name__ == "__main__":
    import fcntl as _f
    _lk = open("/run/monitor.lock", "w")
    try:
        _f.flock(_lk, _f.LOCK_EX | _f.LOCK_NB)
    except OSError:
        print("another monitor running; exit", flush=True); os._exit(0)
    main()
