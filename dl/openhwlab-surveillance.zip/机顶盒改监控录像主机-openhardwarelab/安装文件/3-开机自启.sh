#!/system/bin/sh
# ============================================================
#  openhardwarelab · 机顶盒改监控录像主机
#  开机自启链（放到盒子 /data/startlinux.sh）
#  由 init 脚本调用：/system/etc/init.*.sh 里加一行  sh /data/startlinux.sh &
#  作用：挂载 Linux 子系统 + 拉起 摄像机/守护/画面检测/互传/系统工具 服务。
#  幂等：重复执行不会起两份（各服务用 start-stop-daemon 的 pidfile 去重）。
#
#  ⚠️ 关键：chroot 里的服务必须带 **chroot 的 PATH**（CPATH），
#     否则子进程(如摄像机服务调 ffmpeg)沿用的是安卓 PATH，找不到 /usr/bin/ffmpeg。
# ============================================================
R=/data/linux
CPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
log -t startlinux "begin"

# USB 稳定：关自动省电（摄像头/U盘 容易因省电掉线）
echo -1 > /sys/module/usbcore/parameters/autosuspend 2>/dev/null
for d in /sys/bus/usb/devices/*/; do echo on > "$d/power/control" 2>/dev/null; done

# 内存扩容（见 2-内存扩容.sh）
[ -f /data/swapfile ] && swapon /data/swapfile 2>/dev/null
[ -f /data/swap2 ]    && swapon /data/swap2    2>/dev/null

# 挂载 Linux 子系统(chroot)所需的内核文件系统
mount -t proc  proc  $R/proc 2>/dev/null
mount -t sysfs sysfs $R/sys  2>/dev/null
mount -o bind /dev   $R/dev  2>/dev/null
mkdir -p $R/mnt/sdcard 2>/dev/null
mount -o bind /storage/emulated/0 $R/mnt/sdcard 2>/dev/null
mkdir -p $R/run/sshd $R/var/run/sshd 2>/dev/null
chmod 755 $R/run/sshd $R/var/run/sshd 2>/dev/null

# SSH（远程登录到子系统）
chroot $R /usr/sbin/sshd 2>/dev/null

# 局域网互传 :8890（手机浏览器 http://<盒子IP>:8890/）
chroot $R /usr/bin/env PATH=$CPATH /sbin/start-stop-daemon --start --background \
  --make-pidfile --pidfile /run/transfer.pid --exec /usr/bin/python3 -- /root/transfer.py 2>/dev/null

# 系统工具服务 :8899（桌面「关机/重启/任务切换/显示设置」用）
chroot $R /usr/bin/env PATH=$CPATH /sbin/start-stop-daemon --start --background \
  --make-pidfile --pidfile /run/boxctl.pid --exec /usr/bin/python3 -- /root/boxctl.py 2>/dev/null

# 摄像机服务 :8891（直播 + 循环录像；摄像头 UVC MJPEG 直传）
[ -f $R/root/cam.py ] && chroot $R /usr/bin/env PATH=$CPATH /sbin/start-stop-daemon --start --background \
  --make-pidfile --pidfile /run/cam.pid --exec /usr/bin/python3 -- /root/cam.py 2>/dev/null

# 画面检测（移动侦测 + 无画面/黑屏/卡住）
[ -f $R/root/look.py ] && chroot $R /usr/bin/env PATH=$CPATH /sbin/start-stop-daemon --start --background \
  --make-pidfile --pidfile /run/look.pid --exec /usr/bin/python3 -- /root/look.py 2>/dev/null

# 监控守护 Agent（守护各服务 + 感知自愈 + 资源巡检 + 异常推送）
[ -f $R/root/monitor.py ] && chroot $R /usr/bin/env PATH=$CPATH /sbin/start-stop-daemon --start --background \
  --make-pidfile --pidfile /run/monitor.pid --exec /usr/bin/python3 -- /root/monitor.py 2>/dev/null

# 开机兜底：关系统弹窗 + 确保桌面在前台
[ -f /data/bootfix.sh ] && /system/xbin/busybox nohup /system/bin/sh /data/bootfix.sh >/dev/null 2>&1 &

# ADB over TCP 常驻（远程救急；无授权公钥连不上）
setprop service.adb.tcp.port 5555
setprop ctl.restart adbd

log -t startlinux "done"
