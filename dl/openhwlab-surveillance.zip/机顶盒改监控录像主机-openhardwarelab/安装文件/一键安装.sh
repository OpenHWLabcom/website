#!/bin/bash
# ============================================================
#  openhardwarelab · 机顶盒改监控录像主机 —— 一键安装（在电脑上跑）
#  用法：  ./一键安装.sh <盒子IP>
#  前提：  盒子已 root、已开 ADB 调试、电脑装了 adb、同一局域网；
#          盒子已建好 Linux 子系统 /data/linux（见教程「搭建 Linux 子系统」）。
#  作用：  推服务脚本进子系统、装桌面、瘦身、扩容、配置开机自启与兜底。
#          可重复执行（幂等）。
# ============================================================
set -e
IP="$1"
[ -z "$IP" ] && { echo "用法: $0 <盒子IP>"; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"
R=/data/linux
say(){ echo -e "\n\033[1;36m==> $*\033[0m"; }

say "连接盒子 $IP:5555"
adb connect "${IP}:5555"
adb wait-for-device

say "准备目录"
adb shell "mkdir -p $R/root /data"

say "推服务脚本到 Linux 子系统（chroot 的 /root）"
adb push "$HERE/摄像机服务.py"   $R/root/cam.py
adb push "$HERE/监控守护.py"     $R/root/monitor.py
adb push "$HERE/物体识别.py"     $R/root/det.py
adb push "$HERE/画面检测.py"     $R/root/look.py
adb push "$HERE/局域网互传.py"   $R/root/transfer.py
adb push "$HERE/系统工具服务.py" $R/root/boxctl.py
say "（可选）物体识别模型"
adb push "$HERE/识别模型-yolov8n_416.onnx" $R/root/yolov8n_416.onnx

say "推开机脚本到 /data"
adb push "$HERE/3-开机自启.sh" /data/startlinux.sh
adb push "$HERE/4-开机兜底.sh" /data/bootfix.sh
adb push "$HERE/1-系统瘦身.sh" /data/瘦身.sh
adb push "$HERE/2-内存扩容.sh" /data/扩容.sh
adb shell 'chmod 755 /data/startlinux.sh /data/bootfix.sh'

say "装桌面 App"
adb push "$HERE/桌面.apk" /data/桌面.apk
adb shell 'pm install -r /data/桌面.apk'

say "瘦身 + 内存扩容"
adb shell 'sh /data/瘦身.sh' || true
adb shell 'sh /data/扩容.sh' || true

say "子系统里装依赖（首次）"
echo "  在子系统里(ssh 或 adb shell chroot)："
echo "     apt-get update && apt-get install -y python3 ffmpeg openssh-server ntfs-3g"
echo "     pip3 install onnxruntime            # 只在要用「物体识别」时装"

say "配置开机自启（init 钩子文件名按你 ROM 来）"
echo "      echo 'sh /data/startlinux.sh &' >> /system/etc/<init脚本>"

say "启动一次 + 打开监控页"
adb shell 'sh /data/startlinux.sh' || true
adb shell "am start -n com.openhardwarelab.desktop/.MainActivity"

say "完成！手机/电脑浏览器打开： http://$IP:8891/   （默认账号见教程）"
