各服务源码（与 安装文件/ 里同名）：
  cam.py      摄像机服务(:8891)：直播/循环录像/回看/告警截图
  monitor.py  监控守护：服务守护/感知自愈/巡检/推送
  det.py      物体识别(本地 YOLO)
  look.py     画面检测(移动/无画面/黑屏/卡住)
  transfer.py 局域网互传(:8890) + U盘可视化
  boxctl.py   系统工具服务(:8899)
  startlinux.sh / bootfix.sh  开机自启 / 兜底
改完 → 推到盒子子系统 /root/ 下对应文件名，重启对应服务即可。
—— openhardwarelab
