# 魔百和 CM201-2 改打印机服务器 · China Mobile CM201-2 → Print Server

> 把吃灰的 **魔百和 CM201-2** 盒子变成一台**局域网网络打印机**：手机/电脑打开网页就能打印。
> Turn an idle **China Mobile CM201-2** box into a **LAN network printer**: print straight from a phone/PC browser.

支持 **IPP 直连** + **网页打印**；内置驱动库**多品牌自适应**，HP LaserJet 1018/1020/1022/1022n **插上即用**。
Direct **IPP** + **web printing**; built-in driver library, **multi-brand self-adapting**; HP LaserJet 1018/1020/1022/1022n are **plug-and-play**.

> 与 [CM201-1 版](https://github.com/OpenHWLabcom/cm201-1-print-server) 同一产品思路，但**机型不同**：
> CM201-1 是 **Amlogic S905L**；本机是 **海思 Hi3798MV300**，子系统与开机自启方式不同（见下）。

---

## 🇨🇳 中文

### 实测机型（本机）
| 项 | 值 |
|---|---|
| 型号 | **CM201-2**（中国移动魔百盒，`ro.product.model=CM201-2`） |
| 主控 | **海思 Hi3798MV300**（4×Cortex-A7，32 位 armv7 / armeabi-v7a） |
| 内存/存储 | 1GB DDR3 / 8GB eMMC（`/data` ≈4.1G） |
| 系统 | Android **4.4.2**（SDK19，`HiSTBAndroidV600R003C01SPC031_patch5`） |
| 串口 | console = **ttyAMA0, 115200 8N1**（TTL 可进 root shell） |
| 网络 | 有线 eth0 100M；WiFi RTL8822BS |

### 功能
- **网页打印门户**：手机/电脑浏览器打开即可**拖拽 / 选文件 → 打印**
- **IPP 直连**：电脑「添加打印机」用 `ipp://<盒子IP>:631/printers/<队列>`
- **驱动向导 · 多品牌自适应**：插上 USB 打印机 → **自动识别型号** → 从**内置驱动库**匹配（HP / 兄弟 / 联想 / 爱普生 / 佳能 / 三星 等；含 brlaser / foo2zjs / gutenprint / cups-filters）；认不出的可**上传 .ppd**
- **主机型即插即用**：HP LaserJet 1018/1020/1022/1022n（ZJS）插上**自动灌固件 + 建队列 + 设为默认**
- **管理页**：队列列表、设默认、测试页、删除、换驱动
- **二维码**：扫码传件打印；还能**打印「A4 一版 6 张」二维码贴纸**
- **打印桌面**：盒子开机**直接进**打印页（左网页 + 右菜单），并设为**默认 HOME**
- **中文打印**：内置中文字体

> ⚠ 本盒子 chroot 里 **avahi（AirPrint 自动发现）起不来**（socket 受限）→ 用 **IPP 直连 + 网页**，**不支持 AirPrint 自动发现**。

### 环境要求
- **魔百和 CM201-2**（海思 Hi3798MV300 / armv7 / Android 4.4.2 / 1GB / eMMC）**已 root**，有 **串口(TTL)** 或 **ADB**
- 盒子里的 **Linux 子系统**：chroot 一个 **Ubuntu 20.04（armhf）** 到 `/data/linux`
- 一台 **USB 打印机**（HP 1018/1020/1022/1022n 即插即用；联想/兄弟主机型走 brlaser）

### 安装
```bash
cd install
./一键安装.sh <盒子IP>
```
详细图文：**[`docs/安装教程.md`](docs/安装教程.md)**

> ✅ **本机（Hi3798MV300）的 chroot 里 `apt` 可用**（CM201-1 会 `socket: Permission denied`），
> 所以子系统依赖**可以直接联网 `apt install`**，比 CM201-1 省事。

### 操作说明
- **打印门户**：`http://<盒子IP>:8080/` → 拖拽/选文件 → 打印
- **管理**：`http://<盒子IP>:8080/admin`（队列 / 默认 / 测试页 / 删除 / 换驱动）
- **设置向导**：`http://<盒子IP>:8080/setup`（打开即自动带出 USB 型号 + 列出匹配驱动）
- **电视页**：`http://<盒子IP>:8080/tv`（全屏二维码）
- **电脑添加打印机**：`ipp://<盒子IP>:631/printers/<队列>`
- **盒子屏幕**：打印桌面（默认 HOME，开机即进）

### 目录
```
install/   安装文件（一键安装.sh + 打印服务.py + printerwatch.py + 二维码贴纸.py
           + 桌面.apk + 开机自启脚本 + firmware/  HP 原厂固件）
src/       源码（printd 打印服务 + Android 打印桌面 App + 构建 / 开机脚本）
docs/      教程与开发者文档（含 Hi3798MV300 特有步骤）
```

---

## 🇬🇧 English

### Tested hardware
China Mobile **CM201-2** box — SoC **HiSilicon Hi3798MV300** (4×Cortex-A7, 32-bit armv7),
1GB RAM / 8GB eMMC, Android **4.4.2** (SDK19), console **ttyAMA0 @115200**, eth0 100M + RTL8822BS Wi-Fi.

### Features
- **Web print portal**: open in a phone/PC browser, **drag & drop / choose a file → print**
- **Direct IPP**: add via `ipp://<box-ip>:631/printers/<queue>`
- **Driver wizard · multi-brand**: plug in a USB printer → **model auto-detected** → matched against the **built-in driver library** (HP / Brother / Lenovo / Epson / Canon / Samsung …; brlaser / foo2zjs / gutenprint / cups-filters); unknown models via **.ppd upload**
- **Host-based plug-and-play**: HP LaserJet 1018/1020/1022/1022n **auto-flashed + queue created + set default** on plug-in
- **Admin page**: queues, set default, test page, delete, change driver
- **QR codes**: scan to upload & print; **6-per-A4 QR sticker sheet**
- **Print desktop**: boots straight into the print page; set as the **default HOME**
- **CJK printing**: bundled Chinese font

> ⚠ **avahi (AirPrint discovery) cannot start in this box's chroot** → use **direct IPP + web**.

### Requirements
- A **rooted** **China Mobile CM201-2** box (HiSilicon Hi3798MV300 / armv7 / Android 4.4.2) with **serial(TTL)** or **ADB**
- An **Ubuntu 20.04 (armhf)** chroot at `/data/linux`
- A **USB printer** (HP 1018/1020/1022/1022n plug-and-play; Lenovo/Brother host-based via brlaser)

### Install
```bash
cd install
./一键安装.sh <box-ip>
```
Guide: **[`docs/安装教程.md`](docs/安装教程.md)**

> ✅ On this SoC the chroot **can use `apt`** (unlike CM201-1), so subsystem deps install online directly.

### Usage
- **Portal**: `http://<box-ip>:8080/` · **Admin**: `/admin` · **Wizard**: `/setup` · **TV**: `/tv`
- **Add printer on a PC**: `ipp://<box-ip>:631/printers/<queue>`
- **On the box screen**: the print desktop (default HOME)

---

## 与 CM201-1 版的关键差异 · Key differences vs CM201-1

| | CM201-1 | **CM201-2（本机）** |
|---|---|---|
| 主控 SoC | Amlogic S905L | **海思 HiSilicon Hi3798MV300** |
| chroot 里 `apt` | ❌ `socket: Permission denied`（须离线 deb） | ✅ **可用**（在线装） |
| 开机自启 | 改 boot.img 的 `init.rc` 加 oneshot 服务 | 改 **`/system/etc/init.bigfish.sh`**（on boot 钩子，**不用动 boot.img**） |
| 控制通道 | ADB（+ 串口救急） | **串口 root shell** + ADB over TCP(:5555) |

---

## License · 许可
[MIT](docs/LICENSE) · 仅供学习与个人使用 / For learning and personal use only.

---

## 🔗 相关链接 · Links

- 官网 **OpenHW Lab**：https://www.openhwlab.com/
- 本项目仓库：https://github.com/OpenHWLabcom/cm201-2-print-server
- 同系列机顶盒改造项目：
  - CM201-1 改打印机服务器 — https://github.com/OpenHWLabcom/cm201-1-print-server
  - 机顶盒改游戏机 — https://github.com/OpenHWLabcom/tvbox-game-console
  - 机顶盒改电脑主机 — https://github.com/OpenHWLabcom/tvbox-desktop-pc
  - 机顶盒改监控录像主机 — https://github.com/OpenHWLabcom/tvbox-surveillance
- 官网源码：https://github.com/OpenHWLabcom/website

联系 · Contact：hi@openhwlab.com
