#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 开放 CUPS 到局域网（IPP 直连；AirPrint 用不了但 IPP 可）
# 关键：只保留 "Listen 0.0.0.0:631"，删掉 "Listen localhost:631"（否则第二个 address already in use → 只绑 127.0.0.1）
import shutil, os

p = "/etc/cups/cupsd.conf"
if not os.path.exists(p + ".bak"):
    shutil.copy(p, p + ".bak")

s = open(p).read()

# 1) 去掉 localhost-only 的 Listen 行
lines = [ln for ln in s.splitlines() if ln.strip() != "Listen localhost:631"]
s = "\n".join(lines) + "\n"

# 2) 确保有 0.0.0.0:631
if "Listen 0.0.0.0:631" not in s:
    if "Listen /run/cups/cups.sock" in s:
        s = s.replace("Listen /run/cups/cups.sock", "Listen 0.0.0.0:631\nListen /run/cups/cups.sock", 1)
    else:
        s = "Listen 0.0.0.0:631\n" + s

# 3) 允许局域网
blk_old = "<Location />\n  Order allow,deny\n</Location>"
blk_new = "<Location />\n  Order allow,deny\n  Allow @LOCAL\n  Allow localhost\n</Location>"
if "Allow @LOCAL" not in s and blk_old in s:
    s = s.replace(blk_old, blk_new, 1)

open(p, "w").write(s)
print("patched. Listen/Allow lines:")
for ln in open(p):
    t = ln.strip()
    if t.startswith(("Listen", "Allow")):
        print("   " + t)
