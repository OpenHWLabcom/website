#!/bin/bash
# ============================================================
#  OpenHW Lab · 魔百和 CM201-2 改打印机服务器 —— 一键安装（在电脑上跑）
#  用法：  ./一键安装.sh <盒子IP>
#  前提：  盒子已 root、已开 ADB（串口里: setprop service.adb.tcp.port 5555; start adbd）；
#          已按教程搭好 Linux 子系统 /data/linux（Ubuntu 20.04 armhf）；
#          电脑装了 adb，与盒子同一局域网。
#  作用：  推打印服务/驱动守护/固件 进子系统、装打印服务器桌面(设为默认 HOME)、装开机自启。
#          幂等，可重复执行。
# ============================================================
set -e
IP="$1"
[ -z "$IP" ] && { echo "用法: $0 <盒子IP>"; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"
R=/data/linux
say(){ echo -e "\n\033[1;36m==> $*\033[0m"; }

say "连接盒子 $IP:5555"
adb connect "${IP}:5555"
adb wait-for-device

say "检查 Linux 子系统 $R"
adb shell "[ -d $R/root ] || { echo '未找到 $R（先按教程搭好子系统）'; exit 1; }"

say "推 网页门户 + 驱动守护 + CUPS 补丁 到子系统 /root"
adb push "$HERE/打印服务.py"    $R/root/printd.py
adb push "$HERE/printerwatch.py" $R/root/printerwatch.py
adb push "$HERE/二维码贴纸.py"   $R/root/qrsheet.py
adb push "$HERE/patch_cups.py"   $R/root/patch_cups.py
adb push "$HERE/cr.sh"           /data/local/tmp/cr.sh

say "放 HP 原厂固件 到子系统 /lib/firmware/hp"
adb shell "mkdir -p $R/lib/firmware/hp"
for m in 1018 1020 1022 1022n; do
  adb push "$HERE/firmware/hp$m.img" $R/lib/firmware/hp/sihp$m.img
  adb shell "cp -f $R/lib/firmware/hp/sihp$m.img $R/lib/firmware/hp/sihp$m.dl"
done

say "装子系统启动脚本 /root/printstart.sh"
adb push "$HERE/开机自启-子系统.sh" $R/root/printstart.sh
adb shell "chmod 755 $R/root/printstart.sh"

say "装「打印服务器桌面」App（开机即进: 内嵌打印页 + 菜单 + 二维码）"
adb push "$HERE/桌面.apk" /data/local/tmp/printsrv.apk
adb shell 'pm install -r /data/local/tmp/printsrv.apk'

say "设打印桌面为默认 HOME（禁用旧 IPTV 桌面的 HOME 活动；可用 pm enable 回滚）"
adb shell 'pm disable com.zte.iptvclient.android.launcher_ah/com.chinamobile.launcherjs.main' || true

say "装盒子开机脚本 /data/printstart.sh + 挂到 init.bigfish.sh 钩子"
adb push "$HERE/开机自启-盒子.sh" /data/printstart.sh
adb shell "chmod 755 /data/printstart.sh"
adb shell 'mount -o remount,rw /system 2>/dev/null || true'
adb shell '[ -f /system/etc/init.bigfish.sh.bak-orig ] || /system/bin/busybox cp /system/etc/init.bigfish.sh /system/etc/init.bigfish.sh.bak-orig'
adb push "$HERE/开机钩子.txt" /data/local/tmp/ps_hook.txt
adb shell '/system/bin/busybox grep -q "OpenHW Lab print server (CM201-2)" /system/etc/init.bigfish.sh || /system/bin/cat /data/local/tmp/ps_hook.txt >> /system/etc/init.bigfish.sh'

say "立即启动服务（无需重启）"
adb shell 'sh /data/local/tmp/cr.sh "bash /root/printstart.sh"' || true

cat <<'TIP'

  完成。手机/电脑打开：  http://<盒子IP>:8080/     （未配打印机会自动进设置向导）
  电脑当网络打印机：      ipp://<盒子IP>:631/printers/<队列>
  HP LaserJet 1018/1020/1022/1022n 插上后约 10 秒自动配好；联想/兄弟主机型走 brlaser。
  重启后应自动进打印桌面；自检：/data/printstart.log 里有 printstart done: cupsd=1 printd=1 printerwatch=1

  —— OpenHW Lab · 智能硬件开放实验室 · hi@openhwlab.com
TIP
