#!/system/bin/sh
# ============================================================
#  OpenHW Lab · CM201-2 打印机服务器 开机自启（Android 根上下文）
#  挂子系统 /data/linux -> chroot 跑 /root/printstart.sh
#  -> 延时拉起「打印服务器桌面」覆盖运营商桌面
#  由 /system/etc/init.bigfish.sh 在 on boot 时后台调用。
# ============================================================
R=/data/linux
# 保留网络调试通道（adb over TCP :5555）
setprop service.adb.tcp.port 5555
start adbd 2>/dev/null

# 等子系统就绪
for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
  [ -d $R/usr ] && break
  /system/bin/busybox sleep 1
done

/system/bin/busybox mount -t proc  proc  $R/proc   2>/dev/null
/system/bin/busybox mount -t sysfs sysfs $R/sys    2>/dev/null
/system/bin/busybox mount -o bind  /dev  $R/dev    2>/dev/null
/system/bin/busybox mount -t devpts devpts $R/dev/pts 2>/dev/null

# 起 CUPS + 门户 + 打印机守护
/system/bin/busybox chroot $R /usr/bin/env -i \
  PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  HOME=/root LANG=C.UTF-8 \
  /bin/bash /root/printstart.sh

# 延时起「打印服务器桌面」（盖掉运营商桌面）
/system/bin/busybox setsid sh -c '/system/bin/busybox sleep 25; am start -n com.openhardwarelab.printsrv/.MainActivity' >/dev/null 2>&1 &
