#!/bin/bash
# ============================================================
#  OpenHW Lab · CM201-2 打印机服务器
#  子系统(/data/linux) 启动脚本 -> /root/printstart.sh
#  拉起 CUPS + 网页打印门户(printd) + 打印机守护(printerwatch)
#  由盒子侧 /data/printstart.sh chroot 进来执行（开机自启）。
# ============================================================
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export LANG=C.UTF-8
mkdir -p /run/dbus /var/run/dbus /run/cups /var/run/cups \
         /var/spool/cups /var/cache/cups /var/spool/printd /var/log /var/log/cups 2>/dev/null

# 首次：开放 CUPS 到局域网 (Listen 0.0.0.0:631 + Allow @LOCAL)
if ! grep -q "Listen 0.0.0.0:631" /etc/cups/cupsd.conf 2>/dev/null; then
  python3 /root/patch_cups.py 2>/dev/null || true
fi

# dbus（chroot 里可能起不来，不影响 CUPS/printd）
pgrep -x dbus-daemon >/dev/null 2>&1 || dbus-daemon --system --fork 2>/dev/null

# CUPS
pgrep -x cupsd >/dev/null 2>&1 || /usr/sbin/cupsd 2>/dev/null
sleep 1

# 网页打印门户 :8080
pgrep -f '[p]rintd.py' >/dev/null 2>&1 || setsid python3 /root/printd.py >/var/log/printd.log 2>&1 </dev/null &

# 打印机守护：插上打印机自动识别/灌固件/建队列/设默认
pgrep -f '[p]rinterwatch.py' >/dev/null 2>&1 || setsid python3 /root/printerwatch.py >/var/log/printerwatch.log 2>&1 </dev/null &

sleep 1
echo "printstart done: cupsd=$(pgrep -c -x cupsd) printd=$(pgrep -c -f printd.py) printerwatch=$(pgrep -c -f printerwatch.py) $(date)"
