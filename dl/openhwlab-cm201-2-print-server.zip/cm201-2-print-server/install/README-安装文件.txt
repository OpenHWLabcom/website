========================================
  安装文件 · 说明
  OpenHW Lab · 魔百和 CM201-2 改打印机服务器
========================================

先读「安装教程」（docs/安装教程.md，另有 .txt/.html），照着做即可。

本目录文件：

  一键安装.sh            ← 电脑上跑：./一键安装.sh <盒子IP>
                            （推服务脚本/固件 + 装桌面 + 设为默认 HOME + 装开机自启，一步到位）
  桌面.apk               ← 打印服务器桌面（com.openhardwarelab.printsrv）
                            开机即进：内嵌网页打印界面 + 菜单 + 二维码 → pm install -r 后设为盒子 HOME
  打印服务.py            ← 网页打印门户/管理/驱动向导/二维码 → 子系统 /root/printd.py（:8080）
                            （已含「开机早期 IP=127.0.0.1」修正 refresh_ip）
  printerwatch.py        ← 打印机守护：插上打印机自动识别型号 + 建队列 + 设为默认
                            （HP 1018/1020/1022/1022n 自动灌固件；联想/兄弟主机型走 brlaser）→ /root/printerwatch.py
  二维码贴纸.py          ← A4 一版 6 张二维码贴纸生成 → /root/qrsheet.py
  patch_cups.py          ← CUPS 开局域网补丁：只留 Listen 0.0.0.0:631（删 localhost 行）+ Allow @LOCAL → /root/patch_cups.py
  cr.sh                  ← 便捷脚本：在子系统 chroot 里跑命令 → /data/local/tmp/cr.sh
  开机自启-子系统.sh     ← 子系统启动脚本（dbus/cupsd/printd/printerwatch）→ /data/linux/root/printstart.sh
  开机自启-盒子.sh       ← 盒子开机脚本（挂子系统/起服务/起打印桌面）→ /data/printstart.sh
  开机钩子.txt           ← 追加到 /system/etc/init.bigfish.sh 的开机钩子（on boot 触发）
  firmware/              ← HP 原厂固件 hp1018/1020/1022/1022n.img → 子系统 /lib/firmware/hp/sihp<型号>.img(+.dl)

端口一览：
  8080  网页打印门户（手机扫码传文件打印 / 管理 / 驱动向导）
  631   CUPS 打印服务（电脑按 IPP 加打印机 ipp://<盒子IP>:631/printers/<队列>）

怎么用：
  A) 省事：连好 adb，跑  ./一键安装.sh <盒子IP>
  B) 手动：按「安装教程」一步步复制文件、执行命令（可照抄）

依赖（在 Linux 子系统里装）：
  ✅ 本机（海思 Hi3798MV300）chroot 里 apt 可用 → 直接联网装：
  cups cups-daemon cups-filters cups-client
  printer-driver-foo2zjs printer-driver-brlaser printer-driver-gutenprint printer-driver-cups-pdf
  python3 python3-pil python3-usb python3-distutils libusb-1.0-0 usbutils qrencode fonts-droid-fallback
  （CM201-1 的 ROM 禁 chroot 内 apt，需离线 dpkg -i；本机不需要，见教程）

支持机型（即插即用）：HP LaserJet 1018 / 1020 / 1022 / 1022n
（其它打印机也能用网页「设置向导」自动识别型号并装驱动；联想 M7206W 等主机型走 brlaser，本机实测通过）

—— OpenHW Lab · 智能硬件开放实验室 · hi@openhwlab.com
